import {
  DashboardOutlined,
  UnorderedListOutlined,
  OrderedListOutlined,
  FormOutlined,
  FileImageOutlined,
  FileTextOutlined,
  BankOutlined,
  DollarOutlined,
  SettingOutlined,
} from "@ant-design/icons";
import { APP_PREFIX_PATH } from "configs/AppConfig";
import { menu_items } from "mock/data/authData";

const dashBoardNavTree = [
  {
    key: "dashboards",
    path: `${APP_PREFIX_PATH}/dashboards`,
    title: "sidenav.dashboard",
    icon: DashboardOutlined,
    breadcrumb: false,
    isGroupTitle: true,
    submenu: menu_items,
  },
];

const navigationConfig = [...dashBoardNavTree];

export default navigationConfig;
