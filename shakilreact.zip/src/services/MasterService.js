import fetch from 'auth/FetchMasterInterceptor'
import axios from 'axios'
import { API_BASE_URL } from 'configs/AppConfig'
import { AUTH_TOKEN } from 'constants/AuthConstant';

const masterService = {}
const jwtToken = localStorage.getItem(AUTH_TOKEN) || null;
masterService.getCourseType = function (params) {
  return fetch({
    url: '/course-type/list',
    method: 'post',
    params
  })
}

masterService.addCourseType = function (params) {
    return fetch({
      url: '/course-type/create',
      method: 'post',
      params
    })
  }
masterService.editCourseType = function (params) {
    return fetch({
      url: '/course-type/edit',
      method: 'post',
      params
    })
  }
masterService.deleteCourseType = function (params) {
    return fetch({
      url: '/course-type/delete',
      method: 'post',
      params
    })
  }
  masterService.getCourse = function (params) {
    return fetch({
      url: '/course/list',
      method: 'post',
      params
    })
  }
  
  masterService.addCourse = function (params) {
      return fetch({
        url: '/course/create',
        method: 'post',
        params
      })
    }
  masterService.editCourse = function (params) {
      return fetch({
        url: '/course/edit',
        method: 'post',
        params
      })
    }
  masterService.deleteCourse = function (params) {
      return fetch({
        url: '/course/delete',
        method: 'post',
        params
      })
    }
	masterService.getDocuments = function (params) {
    return fetch({
      url: '/documents/list',
      method: 'post',
      data:params
    })
  }
  
  masterService.addDocuments = function (params) {
      return fetch({
        url: '/documents/create',
        method: 'post',
        params
      })
    }
  masterService.editDocuments = function (params) {
      return fetch({
        url: '/documents/edit',
        method: 'post',
        params
      })
    }
  masterService.deleteDocuments = function (params) {
      return fetch({
        url: '/documents/delete',
        method: 'post',
        params
      })
    }
	masterService.getStatus = function (params) {
    return fetch({
      url: '/status/list',
      method: 'post',
      params
    })
  }
  
  masterService.addStatus = function (params) {
      return fetch({
        url: '/status/create',
        method: 'post',
        params
      })
    }
  masterService.editStatus = function (params) {
      return fetch({
        url: '/status/edit',
        method: 'post',
        params
      })
    }
  masterService.deleteStatus = function (params) {
      return fetch({
        url: '/status/delete',
        method: 'post',
        params
      })
    }
	masterService.getGETStatus = function (params) {
    return fetch({
      url: '/get-status/list',
      method: 'post',
      params
    })
  }
  
  masterService.addGETStatus = function (params) {
      return fetch({
        url: '/get-status/create',
        method: 'post',
        params
      })
    }
  masterService.editGETStatus = function (params) {
      return fetch({
        url: '/get-status/edit',
        method: 'post',
        params
      })
    }
  masterService.deleteGETStatus = function (params) {
      return fetch({
        url: '/get-status/delete',
        method: 'post',
        params
      })
    }

    masterService.partnerGetName = function (params) {
      return fetch({
        url: '/application/university/partner',
        method: 'post',
        params
      })
    }


     masterService.getPartners =function(params){
      return fetch({
        url:'university/partner/list',
        method:'post',
        params
      })
     }
     masterService.addPartners =function(params){
      return fetch({
        url:'university/partner/create',
        method:'post',
        params
      })
     }

     masterService.editPartners =function(params){
      return fetch({
        url:'university/partner/edit',
        method:'post',
        params
      })
     }

     
     masterService.deletePartners =function(params){
      return fetch({
        url:'university/partner/delete',
        method:'post',
        params
      })
     }

	masterService.getQuestion = function (params) {
    return fetch({
      url: '/course-forms/list',
      method: 'post',
      params
    })
  }
  
  masterService.addQuestion = function (params) {
    //console.log(params)  
    return fetch({
        url: '/course-forms/create',
        method: 'post',
        params
      })
    }
  masterService.editQuestion = function (params) {
      return fetch({
        url: '/course-forms/edit',
        method: 'post',
        params
      })
    }
  masterService.deleteQuestion = function (params) {
      return fetch({
        url: '/course-forms/delete',
        method: 'post',
        params
      })
    }
    masterService.getCountry = function (params) {
      return fetch({
        url: '/countries',
        method: 'post',
        params
      })
    }
    masterService.getState = function (params) {
      return fetch({
        url: '/states',
        method: 'post',
        params
      })
    }
    masterService.getCity = function (params) {
      return fetch({
        url: '/cities',
        method: 'post',
        params
      })
    }

    masterService.getRole = function (params) {
      return fetch({
        url: "/roles/list",
        method: "post",
        params,
      });
    };
    
    masterService.addRole = function (params) {
      return fetch({
        url: "/roles/create",
        method: "post",
        params,
      });
    };
    masterService.editRole = function (params) {
      return fetch({
        url: "/roles/edit",
        method: "post",
        params,
      });
    };
    masterService.deleteRole = function (params) {
      return fetch({
        url: "/roles/delete",
        method: "post",
        params,
      });
    };
    
    masterService.getPermission = function (params) {
      return fetch({
        url: "/permissions/list",
        method: "post",
        params,
      });
    };
    
    masterService.assignPermission = function (params) {
      return fetch({
        url: "/roles/permission/assign",
        method: "post",
        data: params,
      });
    };

    masterService.changePassword = function (params) {
      return fetch({
        url: "/changePassword",
        method: "post",
        data: params,
      });
    };

    masterService.getDashboard = function (data) {
      return fetch({
        url: '/dashboard',
        method: 'post',
        data: data
      })
    };

    masterService.getDashboardFilter = function (data) {
      return fetch({
        url: '/dashboard/dashboardFilter',
        method: 'post',
        data: data
      })
    }

    masterService.getExportFilter = function (data) {
      return fetch({
        url: '/export',
        method: 'post',
        data: data
      })
    }
    masterService.getUpdates = function (params) {
      return fetch({
        url: "/get-updates/list",
        method: "post",
        params,
      });
    };
    
    masterService.addUpdates = function (params) {
      return fetch({
        url: "/get-updates/create",
        method: "post",
        params,
      });
    };
    masterService.editUpdates = function (params) {
      return fetch({
        url: "/get-updates/edit",
        method: "post",
        params,
      });
    };
    masterService.deleteUpdates = function (params) {
      return fetch({
        url: "/get-updates/delete",
        method: "post",
        params,
      });
    };
    masterService.getTestimonials = function (params) {
      return fetch({
        url: "/testimonials/list",
        method: "post",
        params,
      });
    };
    masterService.editTestimonialsStatus = function (params) {
      return fetch({
        url: "/testimonials/status",
        method: "post",
        params,
      });
    };
    masterService.deleteTestimonials = function (params) {
      return fetch({
        url: "/testimonials/delete",
        method: "post",
        params,
      });
    };

    masterService.addTestimonials = function (params) {
      const config = {
        headers: {
          "content-type": "multipart/form-data",
          "Authorization": `Bearer ${jwtToken}`,
        },
      };
      return axios
        .post(`${API_BASE_URL}/testimonials/create`, params, config);
      
    };

    masterService.editTestimonials = function (params) {
      const config = {
        headers: {
          "content-type": "multipart/form-data",
          "Authorization": `Bearer ${jwtToken}`,
        },
      };
      return axios
        .post(`${API_BASE_URL}/testimonials/edit`, params, config);
     
    };

    masterService.getCategory = function (params) {
      return fetch({
        url: "/category",
        method: "post",
        params,
      });
    };
    
    masterService.addCategory = function (params) {
      return fetch({
        url: "/category/create",
        method: "post",
        params,
      });
    };
    masterService.editCategory = function (params) {
      return fetch({
        url: "/category/create",
        method: "post",
        params,
      });
    };
    masterService.deleteCategory = function (params) {
      return fetch({
        url: "/category/delete",
        method: "post",
        params,
      });
    };
    

    
    
export default masterService