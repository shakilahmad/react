import React, { useState, useEffect } from "react";
import {
  Row,
  Col,
  Card,
  Table,
  Input,
  Button,
  Tooltip,
  Tag,
  Modal,
  Form,
  Switch,
  notification,
} from "antd";
import {
  DeleteOutlined,
  SearchOutlined,
  PlusCircleOutlined,
  EditOutlined,
} from "@ant-design/icons";
import Flex from "components/shared-components/Flex";
import {} from "react-router-dom";
import utils from "utils";
//import { getCourseType } from '../../../../services/MasterService';
import masterService from "../../../../services/MasterService";
import { useSelector } from "react-redux";
import TextArea from "antd/es/input/TextArea";

const AddNewCardForm = ({
  visible,
  onCreate,
  onCancel,
  statusOnChange,
  statusShow,
  initialVal,
  inputChange,
}) => {
  const [form] = Form.useForm();

  form.setFieldsValue({
    name: initialVal.name,
    course: initialVal.course,
    description: initialVal.description,
    statusName: statusShow,
  });
  return (
    <Modal
      destroyOnClose={true}
      title={
        initialVal.testimonial_id > 0 ? "Edit Tastimonial" : "Add Tastimonials"
      }
      open={visible}
      okText="Submit"
      onCancel={onCancel}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
          })
          .catch((info) => {
            console.log("Validate Failed:", info);
          });
      }}
    >
      <Form
        preserve={false}
        form={form}
        name="addCourseType"
        layout="vertical"
        initialValues={{
          testimonial_id: initialVal.id,
          name: initialVal.name,
          course: initialVal.course,
          description: initialVal.description,
          statusName: statusShow,
        }}
      >
        <Form.Item
          label="Name"
          name="name"
          rules={[
            {
              required: true,
              message: "Please enter name!",
            },
          ]}
        >
          <Input
            placeholder="Name"
            onChange={inputChange("name", initialVal.id)}
          />
        </Form.Item>
        <Form.Item
          label="Course Name"
          name="course"
          rules={[
            {
              required: true,
              message: "Please enter course type!",
            },
          ]}
        >
          <Input
            placeholder="Course Name"
            onChange={inputChange("course", initialVal.id)}
          />
        </Form.Item>
        <Form.Item
          label="Description"
          name="description"
          rules={[
            {
              required: true,
              message: "Please enter course type!",
            },
          ]}
        >
          <TextArea
            placeholder="Description"
            onChange={inputChange("description", initialVal.id)}
          />
        </Form.Item>
        <Form.Item
          name="image"
          label="Image"
        >
          <Input
            placeholder="Image"
            onChange={inputChange("image")}
            type="file"
          />
          
        <img src={initialVal.img} width="100px" />
        </Form.Item>
        
        <Form.Item label="Status" name="statusName">
          <Switch onChange={statusOnChange} checked={statusShow} />
        </Form.Item>
      </Form>
    </Modal>
  );
};
const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
  return (
    <Modal
      destroyOnClose={true}
      title="Testimonials"
      open={visible}
      okText="OK"
      onCancel={onCancelConfirm}
      onOk={() => {
        onOKConfirm();
      }}
    >
      Are you sure want to delete this item?
    </Modal>
  );
};
const ConfirmationBoxStatus = ({
  id,
  visible,
  onOKConfirm,
  onCancelConfirm,
}) => {
  return (
    <Modal
      destroyOnClose={true}
      title="Testimonials"
      open={visible}
      okText="OK"
      onCancel={onCancelConfirm}
      onOk={() => {
        onOKConfirm();
      }}
    >
      Are you sure want to change status this item?
    </Modal>
  );
};

const TestimonialList = () => {
  const [list, setList] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [statusShow, setStatusShow] = useState(false);
  const [initialVal, setInitialVal] = useState({ id: "", name: "" });
  const [modalVisibleConfirmation, setModalVisibleConfirmation] =
    useState(false);
  const [modalVisibleConfirmationStatus, setModalVisibleConfirmationStatus] =
    useState(false);
  const [initialId, setInitialId] = useState(0);
  const [listAll, setListAll] = useState([]);
  const [btnShowHide, setBtnShowHide] = useState({
    add: 0,
    edit: 0,
    delete: 0,
  });
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );

  const listData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getTestimonials(reqeustParam);
      resp
        .then((res) => {
          setList(res.data);
          setListAll(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    listData();
    //console.log(auth_details?.role_permissions)
    const addPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 5
    );
    const editPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 113
    );
    const delPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 114
    );
    setBtnShowHide({
      add: addPermission.length,
      edit: editPermission.length,
      delete: delPermission.length,
    });
  }, []);

  const tableColumns = [
    {
      title: "Sr. No.",
      render: (_, elm, index) => index + 1,
    },
    {
      title: "Name",
      dataIndex: "",
      render: (_, elm) => <>{elm.name}</>,
      sorter: (a, b) => utils.antdTableSorter(a, b, "name"),
    },
    {
      title: "Course",
      dataIndex: "",
      render: (_, elm) => <>{elm.course}</>,

      sorter: (a, b) => utils.antdTableSorter(a, b, "email"),
    },

    {
      title: "Description",
      dataIndex: "description",

      dataIndex: "",
      render: (_, elm) => <>{elm.description}</>,
      sorter: (a, b) => utils.antdTableSorter(a, b, "description"),
    },
    {
      title: "Status",
      dataIndex: "is_active",
      render: (status) => (
        <Tag className="text-capitalize" color={status === 1 ? "cyan" : "red"}>
          {status === 1 ? "Active" : "Inactive"}
        </Tag>
      ),
      sorter: (a, b) => utils.antdTableSorter(a, b, "is_active"),
    },

    {
      title: "Action",
      dataIndex: "actions",
      render: (_, elm) => (
        <Flex>
          {btnShowHide.edit > 0 && (
            <Tooltip title="Edit">
              <Button
                type="primary"
                className="mr-2"
                icon={<EditOutlined />}
                onClick={() => {
                  showEditVaue(elm);
                }}
                size="small"
              />
            </Tooltip>
          )}
          {btnShowHide.delete > 0 && (
            <Tooltip title="Delete">
              <Button
                danger
                icon={<DeleteOutlined />}
                onClick={() => {
                  deleteCourse(elm.id);
                }}
                size="small"
              />
            </Tooltip>
          )}
        </Flex>
      ),
    },
  ];

  const onSearch = (e) => {
    //console.log(e.currentTarget.value);
    const value = e.currentTarget.value;
    const searchArray = e.currentTarget.value ? listAll : listAll;
    const data = utils.wildCardSearch(searchArray, value);
    setList(data);
  };

  const showModal = () => {
    setModalVisible(true);
  };

  const closeModal = () => {
    setInitialVal({ id: "", name: "" });
    setModalVisible(false);
    setStatusShow(false);
  };

  const statusOnChange = (show) => {
    //console.log(show)

    setStatusShow(show);
  };

  //

  const addEditTestimonial = (values) => {
    try {
      // Create a new FormData object
      const formData = new FormData();
      // Append the necessary fields to the FormData object
      formData.append("image", initialVal.image || "");
      formData.append("name", values.name);
      formData.append("course", values.course);
      formData.append("description", values.description);
      formData.append("is_active",  statusShow === true ? 1 : 0);
      formData.append("rating", 0);

      if (initialVal.testimonial_id) {
        formData.append("testimonial_id", initialVal.testimonial_id);
      } else {
        //console.log("Adding new testimonial");
      }
      masterService
        .addTestimonials(formData)
        .then((res) => {
          if (res.status === 200) {
            listData();

            notification.success({
              message: res.data.message,
            });

            setInitialVal([]);
            setModalVisible(false);
          } else {
            console.error("Unexpected response status:", res.status);
            notification.error({
              message: "Unexpected response from the server.",
            });
          }
        })
        .catch((err) => {
          console.error("API Error:", err);
          notification.error({
            message: "There was an error processing your request.",
          });
        });
    } catch (error) {
      console.error("Function Error:", error);
      notification.error({
        message: "An unexpected error occurred.",
      });
    }
  };

  const showEditVaue = (elm) => {
    let statustype = elm.is_active === 1 ? true : false;
    setInitialVal({
      testimonial_id: elm.id,
      name: elm.name,
      course: elm.course,
      description: elm.description,
      img: elm.image,
    });
    setStatusShow(statustype);

    showModal();
  };
  const deleteCourse = (elm) => {
    //console.log(elm)
    setInitialId(elm);
    setModalVisibleConfirmation(true);
  };
  const onCancelConfirm = () => {
    setInitialId(0);
    setModalVisibleConfirmation(false);
  };

  const onOKConfirm = () => {
    const reqeustParam = { testimonial_id: initialId };
    //console.log(initialId)
    const resp = masterService.deleteTestimonials(reqeustParam);
    resp
      .then((res) => {
        if (res.status === 200) {
          setModalVisibleConfirmation(false);
          listData();
          notification.success({
            message: "Testimonials deleted successfully.",
          });
        }
      })
      .catch((err) => {});
  };

  const statusChangeTestimonials = (elm) => {
    //console.log(elm)
    setInitialVal(elm);
    setModalVisibleConfirmationStatus(true);
  };
  const onCancelConfirmStatus = () => {
    setInitialVal({});
    setModalVisibleConfirmationStatus(false);
  };

  const onOKConfirmStatus = () => {
    const reqeustParam = {
      is_active: initialVal.status,
      testimonial_id: initialVal.id,
    };
    //console.log(initialId)
    const resp = masterService.editTestimonialsStatus(reqeustParam);
    resp
      .then((res) => {
        if (res.status === 200) {
          setModalVisibleConfirmationStatus(false);
          listData();
          notification.success({
            message: "Testimonials status change successfully.",
          });
        }
      })
      .catch((err) => {});
  };

  const inputChange = (name) => (e) => {
    let value;
    if (name == "image") {
      value = e.target.files[0];
    } else {
      value = e.target.value;
    }

    setInitialVal({ ...initialVal, [name]: value });
  };

  var i = 1;
  return (
    <Card>
      <Row gutter={16} className="justify-content-between my-4">
        <Col
          className="text-end mb-2 ant-card-head-title pt-0"
          xs={24}
          sm={24}
          md={18}
        >
          {btnShowHide.add > 0 && (
            <Button
              onClick={showModal}
              type="primary"
              icon={<PlusCircleOutlined />}
            >
              Add Testimonial
            </Button>
          )}
        </Col>
        <Col className="text-end mb-2" xs={24} sm={24} md={6}>
          <Input
            placeholder="Search"
            prefix={<SearchOutlined />}
            onChange={(e) => onSearch(e)}
          />
        </Col>
      </Row>
      <AddNewCardForm
        visible={modalVisible}
        onCreate={addEditTestimonial}
        onCancel={closeModal}
        statusOnChange={statusOnChange}
        statusShow={statusShow}
        initialVal={initialVal}
        inputChange={inputChange}
      />
      <ConfirmationBox
        id={initialId}
        visible={modalVisibleConfirmation}
        onOKConfirm={onOKConfirm}
        onCancelConfirm={onCancelConfirm}
      />
      <ConfirmationBoxStatus
        id={initialVal.id}
        visible={modalVisibleConfirmationStatus}
        onOKConfirm={onOKConfirmStatus}
        onCancelConfirm={onCancelConfirmStatus}
      />
      <div className="table-responsive">
        <Table key={i++} columns={tableColumns} dataSource={list} rowKey="id" />
      </div>
    </Card>
  );
};

export default TestimonialList;
