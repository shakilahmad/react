import React, { useState, useEffect } from "react";
import {
  Row,
  Col,
  Card,
  Table,
  Input,
  Button,
  Tooltip,
  Tag,
  Modal,
  Form,
  Switch,
  notification,
  Select,
  Pagination,
} from "antd";
import {
  DeleteOutlined,
  SearchOutlined,
  PlusCircleOutlined,
  EditOutlined,
} from "@ant-design/icons";
import Flex from "components/shared-components/Flex";
import {} from "react-router-dom";
import utils from "utils";
//import { getCourseType } from '../../../../services/MasterService';
import masterService from "../../../../services/MasterService";
import { useSelector } from "react-redux";
const { Search } = Input;

const AddNewCardForm = ({
  visible,
  onCreate,
  onCancel,
  statusOnChange,
  statusShow,
  initialVal,
  listCourseAll,
  inputChange,
  listCategoryAll,
  statusOnChangeFeature,
  statusOnChangeRecom,
  statusShowFeature,
  statusShowRecom
}) => {
  const [form] = Form.useForm();
  const { Option } = Select;
  //console.log(listCourseAll)
  form.setFieldsValue({
    course: initialVal.name,
    coursetype: initialVal.course_type_id,
    level: initialVal.level,
    stream: initialVal.stream,
    statusName: statusShow,
    category_id:initialVal.category_id,
    is_feature:statusShowFeature,
    is_recommondation:statusShowRecom

  });
  return (
    <Modal
      destroyOnClose={true}
      title="Add New Course"
      open={visible}
      okText="Submit"
      onCancel={onCancel}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
          })
          .catch((info) => {
            console.log("Validate Failed:", info);
          });
      }}
    >
      <Form
        preserve={false}
        form={form}
        name="addCourseType"
        layout="vertical"
        initialValues={{
          id: initialVal.id,
          course: initialVal.name,
          coursetype: initialVal.course_type_id,
          level: initialVal.level,
          stream: initialVal.stream,
          statusName: statusShow,
          category_id:initialVal.category_id,
          is_recommondation:statusShowRecom,
          is_feature:statusShowFeature
        }}
      >
        <Form.Item
          label="Course"
          name="course"
          rules={[
            {
              required: true,
              message: "Please enter course!",
            },
          ]}
        >
          <Input placeholder="Course" onChange={inputChange("name")} />
        </Form.Item>

        <Form.Item
          label="Course Type"
          name="coursetype"
          rules={[
            {
              required: true,
              message: "Please enter course type!",
            },
          ]}
        >
          <Select
            onChange={inputChange("course_type_id")}
            showSearch
            placeholder="Select Course Type"
            optionFilterProp="children"
            filterOption={(input, option) =>
              option.props.children
                .toLowerCase()
                .indexOf(input.toLowerCase()) >= 0
            }
          >
            {listCourseAll &&
              listCourseAll.map((listCType) => {
                return <Option value={listCType.id}>{listCType.name}</Option>;
              })}
          </Select>
        </Form.Item>
        <Form.Item
          label="Category"
          name="category_id"
          rules={[
            {
              required: true,
              message: "Please enter category!",
            },
          ]}
        >
          <Select
            onChange={inputChange("category_id")}
            showSearch
            placeholder="Select Category"
            optionFilterProp="children"
            filterOption={(input, option) =>
              option.props.children
                .toLowerCase()
                .indexOf(input.toLowerCase()) >= 0
            }
          >
            {listCategoryAll &&
              listCategoryAll.map((listCType) => {
                return <Option value={listCType.id}>{listCType.name}</Option>;
              })}
          </Select>
        </Form.Item>
        <Form.Item label="Level" name="level">
          <Input placeholder="Lavel" onChange={inputChange("level")} />
        </Form.Item>
        <Form.Item label="Stream" name="stream">
          <Input placeholder="Stream" onChange={inputChange("stream")} />
        </Form.Item>
        <Row gutter={16}>
                            <Col xs={24} sm={24} md={8}>     
        <Form.Item label="Status" name="statusName">
          <Switch onChange={statusOnChange} checked={statusShow} />
        </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={8}> 
        <Form.Item label="Feature" name="is_feature">
          <Switch onChange={statusOnChangeFeature} checked={statusShowFeature} />
        </Form.Item>
</Col>
<Col xs={24} sm={24} md={8}> 
        <Form.Item label="Recommendation" name="is_recommondation">
          <Switch onChange={statusOnChangeRecom} checked={statusShowRecom} />
        </Form.Item>      
        </Col>
        </Row>


      </Form>
    </Modal>
  );
};
const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
  return (
    <Modal
      destroyOnClose={true}
      title="Course Type"
      open={visible}
      okText="OK"
      onCancel={onCancelConfirm}
      onOk={() => {
        onOKConfirm();
      }}
    >
      Are you sure want to delete this item?
    </Modal>
  );
};

const CourseList = () => {
  const [list, setList] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [statusShow, setStatusShow] = useState(false);
  const [statusShowFeature, setStatusShowFeature] = useState(false);
  const [statusShowRecom, setStatusShowRecom] = useState(false);
  const [initialVal, setInitialVal] = useState({
    id: "",
    name: "",
    level: "",
    stream: "",
    course_type_id: "",
  });
  const [modalVisibleConfirmation, setModalVisibleConfirmation] =
    useState(false);
  const [initialId, setInitialId] = useState(0);
  const [listAll, setListAll] = useState([]);
  const [listCourseAll, setListCourseAll] = useState([]);
  const [record, setrecord] = useState(1);
  const [listCategoryAll, setListCategoryAll] = useState([])
  const [btnShowHide, setBtnShowHide] = useState({
    add: 0,
    edit: 0,
    delete: 0,
  });
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );

  const listData = (page, pageSize, search=null) => {
    const reqeustParam = { page: page, pageSize: pageSize, search:search };
    try {
      const resp = masterService.getCourse(reqeustParam);
      resp
        .then((res) => {
          setrecord(res.data.total);
          setList(res.data.data);
          setListAll(res.data.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  const nexPageData = (page, pageSize) => {
    listData(page, pageSize);
  };

  const listCourseTypeData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getCourseType(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setListCourseAll(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };
  const listCategoryData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getCategory(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setListCategoryAll(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    listData(1, 50);
    listCourseTypeData();
    listCategoryData()
    const addPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 10
    );
    const editPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 11
    );
    const delPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 12
    );
    setBtnShowHide({
      add: addPermission.length,
      edit: editPermission.length,
      delete: delPermission.length,
    });
  }, []);

  const tableColumns = [
    {
      title: "Sr. No.",
      render: (_, elm, index) => index + 1,
    },
    {
      title: "Course",
      dataIndex: "name",

      sorter: (a, b) => utils.antdTableSorter(a, b, "name"),
    },
    {
      title: "Course Type",
      dataIndex: "course_type",

      sorter: (a, b) => utils.antdTableSorter(a, b, "course_type"),
    },
    {
      title: "Status",
      dataIndex: "is_active",
      render: (status) => (
        <Tag className="text-capitalize" color={status === 1 ? "cyan" : "red"}>
          {status === 1 ? "Active" : "Inactive"}
        </Tag>
      ),
      sorter: (a, b) => utils.antdTableSorter(a, b, "is_active"),
    },

    {
      title: "Action",
      dataIndex: "actions",
      render: (_, elm) => (
        <Flex>
          {btnShowHide.edit > 0 && (
            <Tooltip title="Edit">
              <Button
                type="primary"
                className="mr-2"
                icon={<EditOutlined />}
                onClick={() => {
                  showEditVaue(elm);
                }}
                size="small"
              />
            </Tooltip>
          )}
          {btnShowHide.delete > 0 && (
            <Tooltip title="Delete">
              <Button
                danger
                icon={<DeleteOutlined />}
                onClick={() => {
                  deleteCourse(elm.id);
                }}
                size="small"
              />
            </Tooltip>
          )}
        </Flex>
      ),
    },
  ];

  const onSearch = (e) => {
    //console.log(e.currentTarget.value);
    /* const value = e.currentTarget.value;
    const searchArray = e.currentTarget.value ? listAll : listAll;
    const data = utils.wildCardSearch(searchArray, value);
    setList(data);
    */
    listData(1, 50,e);
  };

  const showModal = () => {
    setModalVisible(true);
  };

  const closeModal = () => {
    setInitialVal({
      id: "",
      name: "",
      level: "",
      stream: "",
      course_type_id: "",
      category_id:""
    });
    setModalVisible(false);
    setStatusShow(false);
    setStatusShowFeature(false)
    setStatusShowRecom(false)
  };

  const statusOnChange = (show) => {
    setStatusShow(show);
  };
  const statusOnChangeFeature = (show) => {
    setStatusShowFeature(show);
  };
  const statusOnChangeRecom = (show) => {
    setStatusShowRecom(show);
  };


  const addCourseType = (values) => {
    //console.log(values)
    let coursetype = values.statusName === true ? 1 : 0;
    let coursetypefet = values.is_feature === true ? 1 : 0;
    let coursetyperec = values.is_recommondation === true ? 1 : 0;

    //console.log(initialVal);
    if (initialVal.id > 0) {
      const reqeustParam = {
        course_id: initialVal.id,
        name: values.course,
        course_type_id: values.coursetype,
        level: values.level,
        stream: values.stream,
        category_id:values.category_id,
        is_active: coursetype,
        is_feature:coursetypefet,
        is_recommondation:coursetyperec
      };
      const resp = masterService.editCourse(reqeustParam);
      resp
        .then((res) => {
          if (res.status === 200) {
            listData(1, 50);
          }
          notification.success({ message: "Course updated successfully." });
          setInitialVal({
            id: "",
            name: "",
            level: "",
            stream: "",
            course_type_id: "",
            category_id:""
          });
          setStatusShow(false);
          setStatusShowFeature(false)
          setStatusShowRecom(false)
          setModalVisible(false);
        })
        .catch((err) => {});
    } else {
      const reqeustParam = {
        name: values.course,
        course_type_id: values.coursetype,
        level: values.level,
        stream: values.stream,
        is_active: coursetype,
        category_id:values.category_id,
        is_feature:coursetypefet,
        is_recommondation:coursetyperec
      };
      const resp = masterService.addCourse(reqeustParam);
      resp
        .then((res) => {
          if (res.status === 200) {
            setList([...list, res.data]);
          }

          notification.success({ message: "Course added successfully." });
          setInitialVal({
            id: "",
            name: "",
            lavel: "",
            stream: "",
            course_type_id: "",
            category_id:""
          });
          setStatusShow(false);
          setStatusShowFeature(false)
          setStatusShowRecom(false)
          setModalVisible(false);
        })
        .catch((err) => {});
    }
    
  };
  const showEditVaue = (elm) => {
    //console.log(elm)

    let statustype = elm.is_active === 1 ? true : false;
    let statustypefet = elm.is_feature === 1 ? true : false;
    let statustyperec = elm.is_recommondation === 1 ? true : false;
    setInitialVal({
      id: elm.id,
      name: elm.name,
      level: elm.level,
      stream: elm.stream,
      course_type_id: elm.course_type_id,
      category_id:elm.category_id
    });
    setStatusShow(statustype);
    setStatusShowFeature(statustypefet)
    setStatusShowRecom(statustyperec)
    showModal();
  };
  const deleteCourse = (elm) => {
    //console.log(elm)
    setInitialId(elm);
    setModalVisibleConfirmation(true);
  };
  const onCancelConfirm = () => {
    setInitialId(0);
    setModalVisibleConfirmation(false);
  };

  const onOKConfirm = () => {
    const reqeustParam = { course_id: initialId };
    //console.log(initialId)
    const resp = masterService.deleteCourse(reqeustParam);
    resp
      .then((res) => {
        if (res.status === 200) {
          setModalVisibleConfirmation(false);
          listData();
          notification.success({ message: "Course deleted successfully." });
        }
      })
      .catch((err) => {});
  };

  const inputChange = (name) => (e) => {
    let value;
    name === "name" || name === "level" || name === "stream"
      ? (value = e.target.value)
      : (value = e);

    setInitialVal({ ...initialVal, [name]: value });
  };

  return (
    <Card>
      <Row gutter={16} className="justify-content-between my-4">
        <Col className="text-end mb-2" xs={24} sm={24} md={18}>
          {btnShowHide.add > 0 && (
            <Button
              onClick={showModal}
              type="primary"
              icon={<PlusCircleOutlined />}
            >
              Add Course
            </Button>
          )}
        </Col>
        <Col className="text-end mb-2" xs={24} sm={24} md={6}>
        <Search
              placeholder="Search"
              enterButton={<SearchOutlined />}
              onSearch={(e) => onSearch(e)}
              allowClear
            />
        </Col>
      </Row>
      <AddNewCardForm
        visible={modalVisible}
        onCreate={addCourseType}
        onCancel={closeModal}
        statusOnChange={statusOnChange}
        statusShow={statusShow}
        initialVal={initialVal}
        listCourseAll={listCourseAll}
        inputChange={inputChange}
        listCategoryAll={listCategoryAll}
        statusOnChangeFeature={statusOnChangeFeature}
        statusOnChangeRecom={statusOnChangeRecom}
        statusShowFeature={statusShowFeature}
        statusShowRecom={statusShowRecom}
      />
      <ConfirmationBox
        id={initialId}
        visible={modalVisibleConfirmation}
        onOKConfirm={onOKConfirm}
        onCancelConfirm={onCancelConfirm}
      />
      <div className="table-responsive">
        <Table
          columns={tableColumns}
          dataSource={list}
          rowKey="id"
          pagination={false}
        />
        <div className="text-right mt-3">
          <Pagination
            defaultCurrent={1}
            total={record}
            onChange={nexPageData}
            defaultPageSize={50}
            hideOnSinglePage
            pageSizeOptions={[10, 50, 100, 500]}
          />
        </div>
      </div>
    </Card>
  );
};

export default CourseList;
