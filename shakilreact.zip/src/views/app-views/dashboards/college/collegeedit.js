import React from 'react';
import CollegeForm from './CollegeForm';
import { useParams } from 'react-router-dom';

const EditCollege = () => {
	const params = useParams();
    //console.log(params)
    
    return (
		<CollegeForm mode="EDIT" param={params} />
	)
}

export default EditCollege;
