import React, { useState, useEffect } from "react";
import {
  Button,
  message,
  Input,
  Row,
  Col,
  Card,
  Form,
  Select,
  Switch,
} from "antd";
import masterService from "../../../../../services/MasterService";
import universityService from "../../../../../services/UniversityService";
import { useNavigate } from "react-router-dom";
const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const CollegeCourseForm = (props) => {
  const { mode = ADD, param } = props;
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [courseList, setCourseList] = useState([]);
  const [statusShow, setStatusShow] = useState(false);

  const listCountryData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getCourse(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setCourseList(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };
  useEffect(() => {
    listCountryData();
    if (mode === EDIT) {
      // console.log('is edit')
      // console.log('props', props)
      const { id } = param;
      const courseId = parseInt(id);

      const reqeustParam = { college_course_id: courseId };
      const resp = universityService.listCollegeCourse(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          //listStateData(res.data.country_id)
          //listCityData(res.data.state_id)
          statusOnChange(res.data.is_active);
          //setShowImage(res.data.logo)
          form.setFieldsValue({
            course_id:
              res.data.course_id === "undefined" ? "" : res.data.course_id,
            duration:
              res.data.duration === "undefined" ? "" : res.data.duration,
            application_fee:
              res.data.application_fee === "undefined"
                ? ""
                : res.data.application_fee,
            estimate_fee:
              res.data.estimate_fee === "undefined"
                ? ""
                : res.data.estimate_fee,
            english_req:
              res.data.english_req === "undefined" ? "" : res.data.english_req,
            other_req:
              res.data.other_req === "undefined" ? "" : res.data.other_req,
            academices:
              res.data.academices === "undefined" ? "" : res.data.academices,
            intakes: res.data.intakes === "undefined" ? "" : res.data.intakes,
            offer_tat:
              res.data.offer_tat === "undefined" ? "" : res.data.offer_tat,
            course_link:
              res.data.course_link === "undefined" ? "" : res.data.course_link,
            is_active:
              res.data.is_active === "undefined" ? "" : res.data.is_active,
          });
        })
        .catch((err) => {});
    }
  }, [form, mode, param, props]);

  const onFinish = () => {
    setSubmitLoading(true);
    form
      .validateFields()
      .then((values) => {
        setTimeout(() => {
          setSubmitLoading(false);
          if (mode === ADD) {
            //console.log(values)
            let statusname =
              values.is_active === true ? 1 : values.is_active === 1 ? 1 : 0;
            const { id } = param;
            const collegeId = parseInt(id);

            const data = {
              ...values,
              is_active: statusname,
              college_id: collegeId,
            };
            universityService.addCollegeCourse(data);

            message.success(`Course successfully added.`);
            navigate(`/dashboards/college/course/${collegeId}`);
          }
          if (mode === EDIT) {
            //console.log(values)

            const { cid } = param;
            const collegeId = parseInt(cid);
            //const courseId = parseInt(id)
            //console.log(collegeId)
            let statusname =
              values.is_active === true ? 1 : values.is_active === 1 ? 1 : 0;
            //console.log(statusname,values)
            const data = {
              ...values,
              is_active: statusname,
              college_id: collegeId,
            };
            universityService.addCollegeCourse(data);
            message.success(`Course successfully updated.`);
            navigate(`/dashboards/college/course/${collegeId}`);
          }
        }, 1500);
      })
      .catch((info) => {
        setSubmitLoading(false);
        console.log("info", info);
        message.error("Please enter all required field ");
      });
  };
  const statusOnChange = (show) => {
    setStatusShow(show);
  };

  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
        initialValues={{
          id: "",
          name: "",
        }}
      >
        <div className="container123">
          <Card title={`COURSE ${mode}`}>
            <Row gutter={16}>
              <Col xs={24} sm={24} md={24}>
                <Form.Item
                  label="Course"
                  name="course_id"
                  rules={[
                    {
                      required: true,
                      message: "Please enter course!",
                    },
                  ]}
                >
                  <Select
                    showSearch
                    placeholder="Select Course"
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                      option.props.children
                        .toLowerCase()
                        .indexOf(input.toLowerCase()) >= 0
                    }
                  >
                    {courseList &&
                      courseList.map((courseList, index) => {
                        return (
                          <Option
                            key={`country${index}`}
                            value={courseList.id}
                          >
                            {courseList.name}
                          </Option>
                        );
                      })}
                  </Select>
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="duration" label="Duration">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="application_fee" label="Application Fee">
                  <Input />
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={12}>
                <Form.Item name="estimate_fee" label="Estimate Fee">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="english_req" label="English Requirement">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="other_req" label="Other Requirement">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="academices" label="Academics">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="intakes" label="Intakes">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="offer_tat" label="Offer TAT">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="course_link" label="Course Link">
                  <Input />
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={12}>
                <Form.Item name="is_active" label="Status">
                  <Switch onChange={statusOnChange} checked={statusShow} />
                </Form.Item>
              </Col>
            </Row>

            <Row>
              <Col xs={24} sm={24} md={12}>
                <Button
                  type="primary"
                  onClick={() => onFinish()}
                  htmlType="submit"
                  loading={submitLoading}
                >
                  {mode === "ADD" ? "Submit" : `Save`}
                </Button>
              </Col>
            </Row>
          </Card>
        </div>
      </Form>
    </>
  );
};
export default CollegeCourseForm;
