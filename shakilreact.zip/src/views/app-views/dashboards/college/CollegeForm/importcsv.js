import React, { useState } from "react";
import { Button, message, Input, Row, Col, Card, Form } from "antd";
import universityService from "../../../../../services/UniversityService";

import { Link, useNavigate } from "react-router-dom";
import { BASE_URL_IMAGE } from "configs/AppConfig";

const ADD = "ADD";

const CollegeFormImport = () => {
  const mode = ADD;
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [fileChanges, setFilechanges] = useState("");

  const onFinish = () => {
    setSubmitLoading(true);
    form
      .validateFields()
      .then((values) => {
        setTimeout(() => {
          if (mode === ADD) {
            const data = new FormData();
            data.append("file", fileChanges);
            try {
              const resp = universityService.addCollegeImport(data);
              resp
                .then((res) => {
                  setSubmitLoading(false);
                  message.success(`College successfully added.`);
                  navigate(`/dashboards/college`);
                })
                .catch((err) => {
                  message.error(err.response.data.message);
                });
            } catch (errors) {
              console.log(errors);
            }
          }
        }, 1500);
      })
      .catch((info) => {
        setSubmitLoading(false);
        console.log("info", info);
        message.error("Please enter all required field ");
      });
  };

  const handleFileChange = (event) => {
    setFilechanges(event.target.files[0]);
  };
  const downloadlink = `${BASE_URL_IMAGE}/Course-Details-Template.csv`;
  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
        initialValues={{
          id: "",
          name: "",
          course_link: "",
        }}
      >
        <div className="container123">
          <Card title={`COLLEGE ${mode} with CSV`}>
            <Row gutter={16}>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="logo" label="Upload CSV">
                  <Input type="file" onChange={handleFileChange} />
                </Form.Item>
              </Col>
            </Row>

            <Row>
              <Col xs={24} sm={24} md={12}>
                <Button
                  type="primary"
                  onClick={() => onFinish()}
                  htmlType="submit"
                  loading={submitLoading}
                >
                  {mode === "ADD" ? "Submit" : `Save`}
                </Button>
                &nbsp;&nbsp;
                <Link
                  to="/Course-Details-Template.csv"
                  target="_blank"
                  download
                >
                  Sample Download
                </Link>
              </Col>
            </Row>
          </Card>
        </div>
      </Form>
    </>
  );
};

export default CollegeFormImport;
