import React from 'react';
import CollegeCourseForm from '../CollegeForm/collegecourseform';
import { useParams } from 'react-router-dom';
const AddCollege = () => {
    const params = useParams();
	return (
		<CollegeCourseForm mode="ADD"  param={params} />
	)
}

export default AddCollege;
