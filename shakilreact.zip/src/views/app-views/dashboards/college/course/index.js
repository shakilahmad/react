import React, { useState, useEffect } from "react";
import {
  Card,
  Table,
  Input,
  Button,
  Tooltip,
  Tag,
  Modal,
  notification,
} from "antd";
import {
  DeleteOutlined,
  SearchOutlined,
  PlusCircleOutlined,
  EditOutlined,
} from "@ant-design/icons";
import Flex from "components/shared-components/Flex";
import { useNavigate, useParams } from "react-router-dom";
import utils from "utils";
//import { getCourseType } from '../../../../services/MasterService';
import universityService from "../../../../../services/UniversityService";
import { useSelector } from "react-redux";

const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
  return (
    <Modal
      destroyOnClose={true}
      title="College"
      open={visible}
      okText="OK"
      onCancel={onCancelConfirm}
      onOk={() => {
        onOKConfirm();
      }}
    >
      Are you sure want to delete this item?
    </Modal>
  );
};

const CollegeList = () => {
  const navigate = useNavigate();
  const params = useParams();
  const [list, setList] = useState([]);
  const [modalVisibleConfirmation, setModalVisibleConfirmation] =
    useState(false);
  const [initialId, setInitialId] = useState(0);
  const [listAll, setListAll] = useState([]);
  const { id } = params;
  const collegeId = parseInt(id);
  const [btnShowHide, setBtnShowHide] = useState({
    add: 0,
    edit: 0,
    delete: 0,
  });
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );

  const listData = () => {
    try {
      //console.log(collegeId)

      const reqeustParam = { college_id: collegeId };
      const resp = universityService.collegeCourseList(reqeustParam);

      resp
        .then((res) => {
          setList(res.data.courses);
          setListAll(res.data.courses);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    listData();
    const addPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 40
    );
    const editPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 41
    );
    const delPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 42
    );
    setBtnShowHide({
      add: addPermission.length,
      edit: editPermission.length,
      delete: delPermission.length,
    });
  }, []);

  const tableColumns = [
    {
      title: "Sr. No.",
      render: (_, elm, index) => index + 1,
    },
    {
      title: "Course Name",
      dataIndex: "name",
      render: (_, elm) => <div className="text-left">{elm.course.name}</div>,
      sorter: (a, b) => utils.antdTableSorter(a, b, "name"),
    },
    {
      title: "Duration",
      dataIndex: "duration",

      sorter: (a, b) => utils.antdTableSorter(a, b, "establish_year"),
    },
    {
      title: "App. Fee",
      dataIndex: "application_fee",

      sorter: (a, b) => utils.antdTableSorter(a, b, "establish_year"),
    },
    {
      title: "Est. Fee",
      dataIndex: "estimate_fee",

      sorter: (a, b) => utils.antdTableSorter(a, b, "establish_year"),
    },

    {
      title: "Status",
      dataIndex: "is_active",
      render: (status) => (
        <Tag className="text-capitalize" color={status === 1 ? "cyan" : "red"}>
          {status === 1 ? "Active" : "Inactive"}
        </Tag>
      ),
      sorter: (a, b) => utils.antdTableSorter(a, b, "is_active"),
    },

    {
      title: "Action",
      dataIndex: "actions",
      render: (_, elm) => (
        <div className="d-flex">
          {btnShowHide.edit > 0 && (
            <Tooltip title="Edit">
              <Button
                type="primary"
                className="mr-2"
                icon={<EditOutlined />}
                onClick={() => {
                  editCollege(elm.id);
                }}
                size="small"
              />
            </Tooltip>
          )}
          {btnShowHide.delete > 0 && (
            <Tooltip title="Delete">
              <Button
                danger
                icon={<DeleteOutlined />}
                onClick={() => {
                  deleteCollegeCourse(elm.id);
                }}
                size="small"
              />
            </Tooltip>
          )}
        </div>
      ),
    },
  ];

  const onSearch = (e) => {
    //console.log(e.currentTarget.value);
    const value = e.currentTarget.value;
    const searchArray = e.currentTarget.value ? listAll : listAll;
    const data = utils.wildCardSearch(searchArray, value);
    setList(data);
  };

  const deleteCollegeCourse = (elm) => {
    //console.log(elm)
    setInitialId(elm);
    setModalVisibleConfirmation(true);
  };
  const onCancelConfirm = () => {
    setInitialId(0);
    setModalVisibleConfirmation(false);
  };

  const onOKConfirm = () => {
    const reqeustParam = { college_course_id: initialId };
    //console.log(initialId)
    const resp = universityService.deleteCollegeCourse(reqeustParam);
    resp
      .then((res) => {
        if (res.status === 200) {
          setModalVisibleConfirmation(false);
          listData();
          notification.success({ message: "Course deleted successfully." });
        }
      })
      .catch((err) => {});
  };

  const addCollege = () => {
    navigate(`/dashboards/college/course-add/${collegeId}`);
  };
  const editCollege = (id) => {
    navigate(`/dashboards/college/course-edit/${collegeId}/${id}`);
  };

  var i = 1;
  return (
    <Card>
      <Flex
        alignItems="center"
        justifyContent="space-between"
        mobileFlex={false}
      >
        <Flex className="mb-1" mobileFlex={false}>
          <div className="mr-md-3 mb-3">
            <Input
              placeholder="Search"
              prefix={<SearchOutlined />}
              onChange={(e) => onSearch(e)}
            />
          </div>
        </Flex>
        <div>
          {btnShowHide.add > 0 && (
            <Button
              onClick={addCollege}
              type="primary"
              icon={<PlusCircleOutlined />}
              block
            >
              Add Course
            </Button>
          )}

          <ConfirmationBox
            id={initialId}
            visible={modalVisibleConfirmation}
            onOKConfirm={onOKConfirm}
            onCancelConfirm={onCancelConfirm}
          />
        </div>
      </Flex>
      <div className="table-responsive">
        <Table key={i++} columns={tableColumns} dataSource={list} rowKey="id" />
      </div>
    </Card>
  );
};

export default CollegeList;
