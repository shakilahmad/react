import React from 'react';
import CollegeCourseForm from '../CollegeForm/collegecourseform';
import { useParams } from 'react-router-dom';

const EditCollege = () => {
	const params = useParams();
    //console.log(params)
    
    return (
		<CollegeCourseForm mode="EDIT" param={params} />
	)
}

export default EditCollege;
