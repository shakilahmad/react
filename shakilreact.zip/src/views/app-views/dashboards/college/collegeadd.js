import React from 'react';
import CollegeForm from './CollegeForm';

const AddCollege = () => {
	return (
		<CollegeForm mode="ADD"/>
	)
}

export default AddCollege;
