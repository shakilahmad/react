import React from 'react';
import StudentForm from './StudentForm';
import { useParams } from 'react-router-dom';

const EditStudent = () => {
	const params = useParams();
    //console.log(params)
    
    return (
		<StudentForm mode="EDIT" param={params} />
	)
}

export default EditStudent;
