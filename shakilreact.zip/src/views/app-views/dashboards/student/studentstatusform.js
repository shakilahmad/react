import React, { useState, useEffect } from "react";
import {
    Button,
    message,
    Form,
    Select,
    Input
} from "antd";
import masterService from "../../../../services/MasterService";
import leadsService from "../../../../services/LeadsServices";
import { STUDENT_STATUS_LIST } from "constants/AuthConstant";




const { Option } = Select;

const StudentStatusForm = (props) => {
    //console.log(props)
    const [form] = Form.useForm();
    const [showStaus, setShowStatus] = useState([])
    const [submitLoading, setSubmitLoading] = useState(false);
    const shortlistData = () => {
        //const reqeustParam = { is_active: 1 }
        try {

            //const studentId = parseInt(userDetail.id)
            const reqeustParam = { is_active: 1 }
            const resp = masterService.getGETStatus(reqeustParam);


            resp.then(res => {
                //console.log(res)
                setShowStatus(res.data)



            })
                .catch(err => {

                })

        } catch (errors) {
            console.log(errors)
        }
    }


    useEffect(() => {

        shortlistData();

    }, [props, form])

    const onFinish = () => {
        setSubmitLoading(true);
        form
            .validateFields()
            .then((values) => {
                setTimeout(() => {
                    setSubmitLoading(false);

                    //console.log(values)
                    const data = { student_id: props.appid, status: values.status, comment: values.comment }
                    const resp = leadsService.StudentStatus(data);
                    resp.then(res => {
                        //console.log(res);
                        props.updateReload();

                    })



                }, 1500);
            })
            .catch((info) => {
                setSubmitLoading(false);
                console.log("info", info);
                message.error("Please enter all required field ");
            });
    };



    return (
        <>
            <Form
                layout="vertical"
                form={form}
                name="advanced_search"
                className="ant-advanced-search-form"
            >

                <Form.Item
                    label=""
                    name="status"
                    rules={[
                        {
                            required: false,
                            message: "Please select status!",
                        },
                    ]}
                >
                    <Select
                        showSearch
                        placeholder="Select Status"
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                            option.props.children
                                .toLowerCase()
                                .indexOf(input.toLowerCase()) >= 0
                        }
                    >

                        {STUDENT_STATUS_LIST &&
                            STUDENT_STATUS_LIST.map((listDoc, index) => {
                                return (
                                    <Option
                                        key={`country${index}`}
                                        value={listDoc}
                                    >
                                        {listDoc}
                                    </Option>
                                );
                            })}

                    </Select>
                </Form.Item>
                <Form.Item
                    label=""
                    name="comment"
                    rules={[
                        {
                            required: false,
                            message: "Please enter comment!",
                        },
                    ]}
                >
                    <Input placeholder="Comments" />
                </Form.Item>

                <Button
                    className=""
                    type="primary"
                    htmlType="submit"
                    loading={submitLoading}
                    onClick={() => onFinish()}
                >
                    {`Save`}
                </Button>

            </Form>


        </>

    )

}
export default StudentStatusForm;