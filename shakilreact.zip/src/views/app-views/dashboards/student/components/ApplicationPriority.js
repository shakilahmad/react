import React, { useState, useEffect } from "react";
import {
    Button,
    message,
    Form,
    Select,
    Input
} from "antd";
import leadsService from "services/LeadsServices";





const { Option } = Select;

const ApplicationPriority = (props) => {
    //console.log(props)
    const [form] = Form.useForm();
    const [showStaus, setShowStatus] = useState([])
    const [submitLoading, setSubmitLoading] = useState(false);
    


    useEffect(() => {

        

    }, [props, form])

    const onFinish = () => {
        setSubmitLoading(true);
        form
            .validateFields()
            .then((values) => {
                setTimeout(() => {
                    setSubmitLoading(false);

                    //console.log(values)
                    const data = { application_id:props.appid.id, priority: values.priority }
                    const resp = leadsService.applicationPriority(data);
                    resp.then(res => {
                        //console.log(res);
                        props.updateReload();

                    })
                    



                }, 1500);
            })
            .catch((info) => {
                setSubmitLoading(false);
                console.log("info", info);
                message.error("Please enter all required field ");
            });
    };



    return (
        <>
            <Form
                layout="vertical"
                form={form}
                name="advanced_search"
                className="ant-advanced-search-form"
            >

                
                <Form.Item
                    label=""
                    name="priority"
                    rules={[
                        {
                            required: false,
                            message: "Please enter comment!",
                        },
                    ]}
                >
                    <Input placeholder="Priority" />
                </Form.Item>

                <Button
                    className=""
                    type="primary"
                    htmlType="submit"
                    loading={submitLoading}
                    onClick={() => onFinish()}
                >
                    {`Save`}
                </Button>

            </Form>


        </>

    )

}
export default ApplicationPriority;