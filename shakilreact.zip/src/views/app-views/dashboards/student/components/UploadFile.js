import React, { useState, useEffect } from "react";
import {
    Button,
    message,
    Form,
    Select,
    Input
} from "antd";
import masterService from "../../../../../services/MasterService";
import leadsService from "../../../../../services/LeadsServices";




const { Option } = Select;

const UploadFile = (props) => {
    const [form] = Form.useForm();
        const [showStaus, setShowStatus] = useState([])
        const [submitLoading, setSubmitLoading] = useState(false);
        const [initialVal, setInitialVal] = useState({image:""});

    const shortlistData = () => {
        //const reqeustParam = { is_active: 1 }
        try {

            //const studentId = parseInt(userDetail.id)
            const reqeustParam = { is_active: 1 }
            const resp = masterService.getGETStatus(reqeustParam);
            
            
            resp.then(res => {
                //console.log(res)
                setShowStatus(res.data)



            })
                .catch(err => {

                })

        } catch (errors) {
            console.log(errors)
        }
    }


    useEffect(() => {

        shortlistData();

    },[props, form])
    const inputChange = (e, name) => {
        
        let value = name=="image" ? e.target.files[0] : e.target.value;
        setInitialVal({...initialVal, [name]:value})
        //console.log(initialVal);
	}
    const onFinish = () => {
        console.log('okkkk')
        props.listDataOther()
      };
    
    
    
    return (
        <>
                 <Form
                    layout="vertical"
                    form={form}
                    name="advanced_search"
                    className="ant-advanced-search-form"
                >
                       
                        <Form.Item
                            label="Upload File"
                            name="image"
                            rules={[
                                {
                                    required: false,
                                    message: "Please select status!",
                                },
                            ]}
                        >
                            <Input type='file' onChange={(e) => inputChange(e, 'image')} />
                        </Form.Item>

                        <Button
                            className=""
                            type="primary"
                            htmlType="submit"
                            loading={submitLoading}
                            onClick={() => onFinish()}
                            >
                            {`Save`}
                            </Button>
                   
                        </Form>


        </>

    )

}
export default UploadFile;