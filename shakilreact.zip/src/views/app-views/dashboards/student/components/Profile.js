import React, { useState, useEffect } from "react";
//import leadsService from "../../../../services/LeadsServices";
import {
  Button,
  message,
  Input,
  Row,
  Col,
  Card,
  Form,
  Select,
  Switch,
  Radio,
  DatePicker,
  Steps,
} from "antd";

//import masterService from "../../../../services/MasterService";
import { useNavigate } from 'react-router-dom';
import GeneralForm from './GeneralForm'
import EducationForm from "./EducationForm";
import TestScores from "./TestScores";
import BackgroundForm from "./BackgroundForm";
import OtherInformation from "./OtherInformation";


const { Step } = Steps;

const Profile = (props) => {
 const [current, setCurrent] = useState(0)
 //console.log(props)

 const onChange = (current) => {
    //console.log(current)
    setCurrent(current)
 }

  return (
    <>
      
        <div className="container123 mt-5">
        <Steps current={current} onChange={onChange}>
          <Step title="General Information"  />
          {/* <Step title="Other Information"  />  */}
          <Step title="Education History"  />
          <Step title="Test Scores"  />
          <Step title="Background Information"  />
        </Steps>
        </div>
        <div className="container123 mt-5">
        { current === 0 ?
            <GeneralForm mode={props.mode} userDetail={props.userDetail} showProfile={props.showProfile} loaderShow={props.loaderShow} />
        :
         /* current === 1 ?
            <OtherInformation mode={props.mode} userDetail={props.userDetail} />

            : */
             current === 1 ? 
            <EducationForm mode={props.mode} userDetail={props.userDetail} />
            :
            
            current === 2 ? 
            <TestScores  mode={props.mode} userDetail={props.userDetail} />
            :
            current === 3 ?
            <BackgroundForm mode={props.mode} userDetail={props.userDetail} />
            :
            ''
        
        }
           
        
        </div>
      
    </>
  );
};

export default Profile;
