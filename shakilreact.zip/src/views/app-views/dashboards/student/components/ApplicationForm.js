import React, { useState, useEffect } from "react";
import {
    Button,
    message,
    Input,
    Row,
    Col,
    Card,
    Form,
    Select,
    Switch,
    Radio,
    DatePicker,
    Tag,
    Table,
    Avatar,
    Tooltip,
    Popconfirm,
    Popover
} from "antd";
import utils from 'utils'
import { DeleteOutlined, CompressOutlined, EyeOutlined, EditOutlined } from '@ant-design/icons';

import masterService from "../../../../../services/MasterService";
import leadsService from "../../../../../services/LeadsServices";
import { useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';
import DataDisplayWidget from "components/shared-components/DataDisplayWidget";
import { BASE_URL_IMAGE } from "configs/AppConfig";
import style from "react-syntax-highlighter/dist/esm/styles/hljs/a11y-dark";
import ApplicationView from "./ApplicationView";
import Flex from "components/shared-components/Flex";
import { useSelector } from "react-redux";
import { YEARS, MONTHS } from "constants/AuthConstant";
import ApplicationPriority from "./ApplicationPriority";



const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const ApplicationForm = (props) => {
    const dateFormat = 'DD/MM/YYYY';
    const { mode = ADD, userDetail } = props;
    const navigate = useNavigate();
    const [form] = Form.useForm();
    const [submitLoading, setSubmitLoading] = useState(false);
    const [countryList, setCountryList] = useState([]);
    const [statusShow, setStatusShow] = useState(false);
    const [show, setShow] = useState(false)
    const [courseList, setCourseList] = useState([]);
    const [courseTypeList, setCourseTypeList] = useState([]);
    const [showForm, setShowForm] = useState(true)
    const [shortList, setShortlist] = useState([])
    const [shortListApplied, setShortlistApplied] = useState([])
    const [shortListAppliedOther, setShortlistAppliedOther] = useState([])
    const [intakeValue, setIntakeValue] = useState([])
    const [btnShowHide, setBtnShowHide] = useState({ add: 0, view: 0, delete: 0, backshort: 0, priority: 0 });
    const auth_details = JSON.parse(useSelector(state => state.auth.auth_details))

    const shortlistData = () => {
        //const reqeustParam = { is_active: 1 }
        try {

            const studentId = parseInt(userDetail.id)
            if (studentId) {
                const reqeustParam = { student_id: studentId }
                const resp = leadsService.applicationListStudent(reqeustParam);
                resp.then(res => {

                    setShortlist(res.data.shortlist)
                    setShortlistApplied(res.data.applied)
                    setShortlistAppliedOther(res.data.other)


                })
                    .catch(err => {

                    })
            }

        } catch (errors) {
            console.log(errors)
        }
    }


    useEffect(() => {
        //console.log(intakeValue)
        shortlistData();

        const addPermission = auth_details.role_permissions.filter((listPer) => listPer.id === 49)
        const viewPermission = auth_details.role_permissions.filter((listPer) => listPer.id === 52)
        const delPermission = auth_details.role_permissions.filter((listPer) => listPer.id === 51)
        const backPermission = auth_details.role_permissions.filter((listPer) => listPer.id === 105)
        const backPermissionPriority = auth_details.role_permissions.filter((listPer) => listPer.id === 115)
        setBtnShowHide({ add: addPermission.length, view: viewPermission.length, delete: delPermission.length, backshort: backPermission.length, priority: backPermissionPriority.length })


    }, [form, mode, props]);
    const handleFileChange = (event) => {
        // setFilechanges(event.target.files[0]);
    }
    const onFinish = () => {
        setSubmitLoading(true);
        form
            .validateFields()
            .then((values) => {
                setTimeout(() => {
                    setSubmitLoading(false);
                    if (mode === ADD) {
                        //console.log(values)

                        let statusname = values.is_active === true ? 1 : values.is_active === 1 ? 1 : 0
                        const data = { ...values, is_active: statusname }
                        //leadsService.addStudent(data)
                        //message.success(`Student successfully added.`);
                        //navigate(`/dashboards/student`)



                    }
                    if (mode === EDIT) {
                        //console.log(values)

                        const studentId = parseInt(userDetail.id)

                        let statusname = values.is_active === true ? 1 : values.is_active === 1 ? 1 : 0
                        const data = { ...values, is_active: statusname, student_id: studentId }
                        //leadsService.personalInformationStudent(data)
                        //message.success(`Student successfully updated.`);
                        //navigate(`/dashboards/student`)

                    }
                }, 1500);
            })
            .catch((info) => {
                setSubmitLoading(false);
                console.log("info", info);
                message.error("Please enter all required field ");
            });
    };

    const statusOnChange = (show) => {
        setStatusShow(show);
    };

    const showValue = (e) => {

        if (e.target.value === "Yes") {
            setShow(true)
        } else {
            setShow(false)
        }
    }

    const updateReload = () => {
        shortlistData();
    }


    let i = 1;
    const imgsrc = `${BASE_URL_IMAGE}/img/avatars/thumb-1.jpg`;

    const columns = [
        {
            title: 'Status',
            dataIndex: 'status',
            render: (_, elm) => (

                <div className="text-left">
                    {elm.get_status_name}

                </div>

            )
        },
        {
            title: 'App #',
            dataIndex: 'application_no',
        },
        {
            title: 'School',
            dataIndex: 'school',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.college_course.college.name}
                </div>

            )
        },
        {
            title: 'Country',
            dataIndex: 'country',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.college_course.college.country}
                </div>

            )
        },
        {
            title: 'Program',
            dataIndex: 'program',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.college_course.course.name}
                </div>

            )
        },

        /*  {
             title: 'Start Date',
             dataIndex: 'strtdate',
             width: '125px',
             render: (_, elm) => (
                 <div className="text-left">
                     {elm.college_course.intakes}
                 </div>
 
             )
         },
         */
        {
            title: 'Fees',
            dataIndex: 'fees',
            render: (_, elm) => (
                <div className="text-left">
                    Application Fee
                </div>

            )

        },
        {
            title: 'Intake Month',
            dataIndex: 'intakemonth',

            render: (_, elm) => (

                <div className="text-left">


                    {btnShowHide.add > 0 &&


                        <Select style={{ width: '100px' }}
                            showSearch
                            placeholder=""
                            optionFilterProp="children"
                            filterOption={(input, option) =>
                                option.props.children
                                    .toLowerCase()
                                    .indexOf(input.toLowerCase()) >= 0
                            }
                            onChange={(e) => inputChange(e, "intake_month", elm.id)}


                        >
                            {MONTHS &&
                                MONTHS.map((month, index) => {
                                    return (
                                        <Option key={`month${index}`} value={month}>
                                            {month}
                                        </Option>
                                    );
                                })}
                        </Select>




                    }

                </div>

            )
        },
        {
            title: 'Intake Year',
            dataIndex: 'intakemonth',

            render: (_, elm) => (
                <div className="text-left">
                    {btnShowHide.add > 0 &&


                        <Select style={{ width: '100px' }}
                            showSearch
                            placeholder=""
                            optionFilterProp="children"
                            filterOption={(input, option) =>
                                option.props.children
                                    .toLowerCase()
                                    .indexOf(input.toLowerCase()) >= 0
                            }
                            onChange={(e) => inputChange(e, "intake_year", elm.id)}

                        >
                            {YEARS &&
                                YEARS.map((year, index) => {
                                    return (
                                        <Option key={`year${index}`} value={year}>
                                            {year}
                                        </Option>
                                    );
                                })}
                        </Select>




                    }

                </div>

            )
        },
        {
            title: '',
            dataIndex: 'applybutton',
            render: (_, elm) => (
                <div className="text-left">
                    {btnShowHide.add > 0 &&


                        <Button type="primary" onClick={() => showApplied(elm.id)} className="mr-2 px-4" size="small"> Apply </Button>


                    }

                </div>

            )
        },

        {
            title: '',
            dataIndex: 'actionfee',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.college_course.application_fee}
                </div>

            )

        },
        {
            title: '',
            dataIndex: 'action',
            render: (_, elm) => (
                <Flex className="text-left">
                    {btnShowHide.view > 0 &&
                        <Tooltip title="View">

                            <Button type="primary" className="mr-2 px-4" onClick={() => navigate(`/dashboards/application-detail/${elm.id}`)} size="small"> View </Button>

                        </Tooltip>
                    }

                    <span>

                        {btnShowHide.delete > 0 &&
                            <Popconfirm
                                title="Sure to delete?"
                                onConfirm={() => deleteShortList(elm.id)}
                            >
                                <Button type="primary" className="mr-2 px-4" size="small" danger><DeleteOutlined /></Button>
                            </Popconfirm>
                        }
                    </span>

                </Flex>

            )
        },

    ];



    const columnsapp = [
        {
            title: 'Priority',
            dataIndex: 'priority',
            render: (_, elm) => (
                <>
                    <div className="text-left">
                        {elm.priority}

                        {btnShowHide.priority > 0 &&
                            <Popover content={<ApplicationPriority appid={elm} updateReload={updateReload} />} title="Priority" trigger="click">
                                <Button type="link" size="small" icon={<EditOutlined />} />
                            </Popover>
                        }
                    </div>


                </>

            )
        },
        {
            title: 'Status',
            dataIndex: 'status',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.get_status_name}

                </div>

            )
        },
        {
            title: 'App #',
            dataIndex: 'application_no',
        },
        {
            title: 'School',
            dataIndex: 'school',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.college_course.college.name}
                </div>

            )
        },
        {
            title: 'Country',
            dataIndex: 'country',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.college_course.college.country}
                </div>

            )
        },
        {
            title: 'Program',
            dataIndex: 'program',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.college_course.course.name}
                </div>

            )
        },
        /* {
            title: 'Start Date',
            dataIndex: 'strtdate',
            width: '125px',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.college_course.intakes}
                </div>

            )
        },
        {
            title: 'Requirement',
            dataIndex: 'req',
            render: (_, elm) => (
                <div className="text-left">
                    Arrival
                </div>

            )

        },
        */
        {
            title: 'Intake Month',
            dataIndex: 'req',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.intake_month}
                </div>

            )

        },
        {
            title: 'Intake Year',
            dataIndex: 'req',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.intake_year}
                </div>

            )

        },
        {
            title: '',
            dataIndex: 'action',
            render: (_, elm) => (

                <Flex>
                    {btnShowHide.view > 0 &&
                        <Tooltip title="View">
                            <Button type="primary" className="mr-2 px-4" onClick={() => navigate(`/dashboards/application-detail/${elm.id}`)} size="small"> <EyeOutlined /> </Button>
                        </Tooltip>
                    }



                    {btnShowHide.backshort > 0 && elm.is_approved == 0 &&
                        <Popconfirm
                            title="Back to Shortlist"
                            onConfirm={() => backShortList(elm)}
                        >
                            <Button type="primary" className="mr-2 px-4" size="small" danger title="Back"><CompressOutlined /></Button>
                        </Popconfirm>
                    }


                </Flex>


            )
        },

    ];
    const columnsappother = [
        {
            title: 'Priority',
            dataIndex: 'priority',
            render: (_, elm) => (
                <>
                    <div className="text-left">
                        {elm.priority}

                    </div>


                </>

            )
        },
        {
            title: 'Status',
            dataIndex: 'status',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.get_status_name}

                </div>

            )
        },
        {
            title: 'App #',
            dataIndex: 'application_no',
        },
        {
            title: 'School',
            dataIndex: 'school',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.college_course.college.name}
                </div>

            )
        },
        {
            title: 'Country',
            dataIndex: 'country',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.college_course.college.country}
                </div>

            )
        },
        {
            title: 'Program',
            dataIndex: 'program',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.college_course.course.name}
                </div>

            )
        },
        /* {
            title: 'Start Date',
            dataIndex: 'strtdate',
            width: '125px',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.college_course.intakes}
                </div>

            )
        },
        {
            title: 'Requirement',
            dataIndex: 'req',
            render: (_, elm) => (
                <div className="text-left">
                    Arrival
                </div>

            )

        },
        */
        {
            title: 'Intake Month',
            dataIndex: 'req',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.intake_month}
                </div>

            )

        },
        {
            title: 'Intake Year',
            dataIndex: 'req',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.intake_year}
                </div>

            )

        },
        {
            title: '',
            dataIndex: 'action',
            render: (_, elm) => (

                <Flex>
                    {btnShowHide.view > 0 &&
                        <Tooltip title="View">
                            <Button type="primary" className="mr-2 px-4" onClick={() => navigate(`/dashboards/application-detail/${elm.id}`)} size="small"> <EyeOutlined /> </Button>
                        </Tooltip>
                    }



                    {btnShowHide.backshort > 0 &&
                        <Popconfirm
                            title="Back to Shortlist"
                            onConfirm={() => backShortList(elm)}
                        >
                            <Button type="primary" className="mr-2 px-4" size="small" danger title="Back"><CompressOutlined /></Button>
                        </Popconfirm>
                    }


                </Flex>


            )
        },

    ];
    const showApplied = (id) => {

        //console.log(intakeValue)
        let arrValue = []
        const monthValue = intakeValue.filter((listVal, index) => {
            let month = `intake_month-${id}`;
            let year = `intake_year-${id}`;
            //console.log(listVal[month])
            if (Object.keys(listVal) == month) {
                arrValue[0] = listVal[month]
            }
            if (Object.keys(listVal) == year) {
                arrValue[1] = listVal[year]
            }


        })

        //let month = `intake_month-${id}`;
        //console.log(arrValue[0],arrValue[1])
        if (arrValue[0] != '' && arrValue[0] != undefined && arrValue[1] != undefined && arrValue[1] != '') {
            const reqeustParam = { application_id: id, status_id: 2, intake_month: arrValue[0], intake_year: arrValue[1] }
            const resp = leadsService.applicationStatusStudent(reqeustParam);
            resp.then(res => {
                //console.log(res)
                shortlistData();


            })
                .catch(err => {

                })

        } else {
            message.warning(`Please select inake month and year`);
        }


    }

    const deleteShortList = (id) => {
        //console.log(id)
        const reqeustParam = { application_id: id }
        const resp = leadsService.applicationDelete(reqeustParam);
        resp.then(res => {
            //console.log(res)
            shortlistData();


        })
            .catch(err => {

            })

    }
    const backShortList = (values) => {
        //console.log(values)
        const reqeustParam = { application_id: values.id, status_id: 1, intake_month: values.intake_month, intake_year: values.intake_year }
        const resp = leadsService.applicationStatusStudent(reqeustParam);
        resp.then(res => {
            //console.log(res)
            /* let month = `intake_month-${values.id}`;
            let year = `intake_year-${values.id}`;
            setIntakeValue([...intakeValue, { [month]: values.intake_month, [year]: values.intake_year }])
            */
            shortlistData();


        })
            .catch(err => {

            })

        /* const reqeustParam = { application_id: id }
        const resp = leadsService.backShortListApplication(reqeustParam);
        resp.then(res => {
            //console.log(res)
            shortlistData();


        })
            .catch(err => {

            })
            */

    }
    const inputChange = (e, name, id) => {
        //console.log(e, name,id)
        let month = `${name}-${id}`;
        setIntakeValue([...intakeValue, { [month]: e }])
        //console.log(collegeFilter);
    };


    return (
        <>


            <Card title={`Shortlists Applications`}>
                <hr />
                <div className="table-responsive" >
                    <Table
                        key={i++}
                        columns={columns}
                        dataSource={shortList}
                        rowKey='id'
                        pagination={false}
                        /* rowSelection={{
                            type: 'checkbox',

                        }} */
                        summary={(pageData) => {
                            let totalshort = 0;



                            pageData.forEach((list) => {


                                if (isNaN(list.college_course.application_fee)) { } else {
                                    if (list.college_course.application_fee != '') {
                                        totalshort += parseInt(list.college_course.application_fee)
                                    }
                                }


                            });

                            return (
                                <>
                                    <tr>
                                        <td colSpan={7}>&nbsp;</td>
                                        <th>Total</th>
                                        <td>
                                            <div>{totalshort}</div>
                                        </td>
                                        <td>&nbsp;</td>
                                    </tr>

                                </>
                            );
                        }}

                    />
                </div>
            </Card>

            <Card title={`Applications Applied`}>
                <hr />
                <div className="table-responsive">
                    <Table
                        key={i++}
                        columns={columnsapp}
                        dataSource={shortListApplied}
                        rowKey='id'
                        pagination={false}



                    />
                </div>
            </Card>
            <Card title={`Other Apps of VISA Approved Students`}>
                <hr />
                <div className="table-responsive">
                    <Table
                        key={i++}
                        columns={columnsappother}
                        dataSource={shortListAppliedOther}
                        rowKey='id'
                        pagination={false}



                    />
                </div>
            </Card>
        </>
    );
};

export default ApplicationForm;
