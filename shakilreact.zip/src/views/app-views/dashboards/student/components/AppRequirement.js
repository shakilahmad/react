import React, { useState, useEffect } from "react";
import leadsService from "../../../../../services/LeadsServices";
import {
  Button,
  message,
  Input,
  Row,
  Col,
  Card,
  Form,
  Select,
  Switch,
  Radio,
  DatePicker,
  Tag,
  Table,
  Avatar,
  Tooltip,
  notification,
  Modal,
  Popover,
  Upload,
} from "antd";
import utils from "utils";
import masterService from "../../../../../services/MasterService";
import { Link, useNavigate } from "react-router-dom";
import dayjs from "dayjs";
import {
  CheckOutlined,
  UploadOutlined,
  DownloadOutlined,
  EyeOutlined,
  DeleteOutlined,
  PlusCircleOutlined,
  CloseOutlined,
  CloudUploadOutlined,
  PlusOutlined,
  MinusCircleOutlined,
  EditOutlined,
} from "@ant-design/icons";
import DataDisplayWidget from "components/shared-components/DataDisplayWidget";
import UploadFile from "./UploadFile";
import DocumentStatusForm from "./DocumentStatusForm";
import { useSelector } from "react-redux";

const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
  return (
    <Modal
      destroyOnClose={true}
      title="Document"
      open={visible}
      okText="OK"
      onCancel={onCancelConfirm}
      onOk={() => {
        onOKConfirm();
      }}
    >
      Are you sure want to delete this item?
    </Modal>
  );
};

const AppRequirement = (props) => {
  const dateFormat = "DD/MM/YYYY";
  const { mode = ADD, appDetail } = props;
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [listMis, setListMis] = useState([]);
  const [ListMisOther, setListMisOther] = useState([]);
  const [initialVal, setInitialVal] = useState({
    image: "",
    document_name: "",
  });
  const [number, setNumber] = useState(100);
  const [btnShow, setBtnShow] = useState(false);
  const [modalVisibleConfirmation, setModalVisibleConfirmation] =
    useState(false);
  const [initialId, setInitialId] = useState(0);
  const [showPopup, setShowPopup] = useState(0);
  const [btnShowHide, setBtnShowHide] = useState({
    add: 0,
    edit: 0,
    delete: 0,
    upload: 0,
    download: 0,
  });
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );
  const [listMisSelect, setListMisSelect] = useState([]);

  const listData = () => {
    
    try {
      if(appDetail.student_id > 0){
      const reqeustParam = {
        student_id: appDetail.student_id,
        is_active: true,
        is_required: 1,
      };
      const resp = masterService.getDocuments(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setListMis(res.data);
          //setStatusData(res.statusData);
        })
        .catch((err) => {});
      }
    } catch (errors) {
      console.log(errors);
    }
    
    try {
      if(appDetail.student_id > 0){
      const reqeustParamSelect = {
        student_id: appDetail.student_id,
        is_active: true,
      };
      const respp = masterService.getDocuments(reqeustParamSelect);
      respp
        .then((ress) => {
          //console.log(ress.data)
          setListMisSelect(ress.data);
          //setStatusData(res.statusData);
        })
        .catch((err) => {});
      }
    } catch (errors) {
      console.log(errors);
    }
  };

  const listDataOther = () => {
    
    try {
      if(appDetail.student_id > 0){
      const reqeustParam = { student_id: appDetail.student_id, type: "" };
      const respData = leadsService.documentsStudent(reqeustParam);
      respData
        .then((res) => {
          setListMisOther(res.data);
        })
        .catch((err) => {});
      }
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    listData();
    listDataOther();
    const addPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 54
    );
    const editPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 58
    );
    const delPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 56
    );
    const uploadPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 55
    );
    const downloadPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 57
    );
    setBtnShowHide({
      add: addPermission.length,
      edit: editPermission.length,
      delete: delPermission.length,
      upload: uploadPermission.length,
      download: downloadPermission.length,
    });
  }, [form, mode, props]);

  const onFinish = (name, remove) => {
    if (initialVal.document_name != "") {
      const data = new FormData();
      data.append("student_id", appDetail.student_id);
      data.append("document_id", initialVal.document_name);
      data.append("type", "student");
      data.append("other_doc", "Yes");
      //data.append("image", initialVal.image);
      try {
        const resp = leadsService.documentsStudentUpload(data);

        resp
          .then((res) => {
            //console.log(res);
            listData();
            listDataOther();
            remove(name);

            setBtnShow(false);
            message.success("document upload successfully.");
          })
          .catch((err) => {
            message.error(err.response.data.message);
          });
      } catch (errors) {
        //
      }
    }
  };

  let i = 1;

  const inputChange = (e, name) => {
    let value = name == "image" ? e.target.files[0] : e;
    setInitialVal({ ...initialVal, [name]: value });
    //console.log(initialVal);
  };

  const deleteStudentDoc = (elm) => {
    setInitialId(elm);
    setModalVisibleConfirmation(true);
  };

  const onCancelConfirm = () => {
    if (initialId != 0) {
      setInitialId(0);
    }
    setModalVisibleConfirmation(false);
  };

  const onOKConfirm = () => {
    let value = initialId;
    const reqeustParam = {
      student_document_id: value,
      student_id: appDetail.student_id,
    };
    const resp = leadsService.documentsStudentDelete(reqeustParam);
    resp
      .then((res) => {
        if (res.status === 200) {
          setModalVisibleConfirmation(false);
          listData();
          listDataOther();
          notification.success({ message: res.message });
        }
      })
      .catch((err) => {});
  };

  const handleVisibleChange = () => {
    showPopup === true ? setShowPopup(false) : setShowPopup(true);
  };

  const showPopOver = () => {
    setShowPopup(true);
  };

  const handleFileChange = (event, doc_id) => {
    //console.log(doc_id)
    setSubmitLoading(true);

    const data = new FormData();
    data.append("image", event.target.files[0]);
    data.append("student_id", appDetail.student_id);
    data.append("student_document_id", doc_id);
    try {
      const resp = leadsService.documentsStudentUpload(data);

      resp
        .then((res) => {
          listData();
          listDataOther();
          message.success("Document upload successfully.");
        })
        .catch((err) => {
          message.error("Please upload valid data with valid format");
        });
    } catch (errors) {
      //
    }
  };
  const handleFileChangeMain = (event, doc_id) => {
    //console.log(doc_id)
    setSubmitLoading(true);

    const data = new FormData();
    data.append("image", event.target.files[0]);
    data.append("student_id", appDetail.student_id);
    data.append("document_id", doc_id);
    try {
      const resp = leadsService.documentsStudentUpload(data);

      resp
        .then((res) => {
          listData();
          listDataOther();
          message.success("Document upload successfully.");
        })
        .catch((err) => {
          message.error("Please upload valid data with valid format");
        });
    } catch (errors) {
      //
    }
  };
  const updateReload = () => {
    listData();
    listDataOther();
  };

  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
      >
        <div className="container123">
          {listMis &&
            listMis.map((listmis, index) => {
              return (
                <Card>
                  <Row gutter={14}>
                    <Col xs={24} sm={24} md={5}>
                      {listmis.is_upload === 1 &&
                      listmis.document.status === "Approved" ? (
                        <Tag color="cyan" icon={<CheckOutlined />}>
                          {listmis.document.status}
                        </Tag>
                      ) : listmis.is_upload === 1 &&
                        listmis.document.status === "Reupload" ? (
                        <Tag color="orange" icon={<CheckOutlined />}>
                          {listmis.document?.status}
                        </Tag>
                      ) : (
                        <Tag color="red">
                          {listmis.is_upload === 1
                            ? listmis.document.status != ""
                              ? listmis.document.status
                              : "Pending"
                            : "Pending"}
                        </Tag>
                      )}

                      {/* <p style={{ color: `blue`, fontSize: `10px` }}>Required</p> */}
                    </Col>
                    <Col xs={24} sm={24} md={14}>
                      <>
                      <strong>
                        {listmis.is_required === 1 ? (
                          <label style={{ color: "#ff6b72" }}>*</label>
                        ) : (
                          ""
                        )}{" "}
                        {listmis.name}
                      </strong>
                      <br />
                      <p style={{fontSize: `10px` }}>{listmis.is_upload ? listmis.document.updated_at:''}</p>
                      
                    </>
                    </Col>

                    <Col xs={24} sm={24} md={3}>
                      <div className="d-flex justify-content-between">
                        {listmis.is_upload === 1 && [
                          btnShowHide.download > 0 && (
                            <a
                              href={listmis.document.image}
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              <label>
                                <Avatar
                                  className="mr-1"
                                  icon={<EyeOutlined />}
                                  size={25}
                                  style={{ backgroundColor: `orange`, cursor:`pointer` }}
                                />
                              </label>
                            </a>
                          ),
                        ]}
                        {listmis.is_upload === 1 ? (
                          ""
                        ) : (
                          <>
                            {btnShowHide.upload > 0 && (
                              <label htmlFor={`formIdMis${index}`}>
                                <Input
                                  type="file"
                                  id={`formIdMis${index}`}
                                  hidden
                                  onChange={(e) =>
                                    handleFileChangeMain(e, listmis.id)
                                  }
                                />
                                <Avatar
                                  className="mr-1"
                                  icon={<UploadOutlined />}
                                  size={25}
                                  style={{ backgroundColor: `blue`, cursor:`pointer` }}
                                />
                              </label>
                            )}
                          </>
                        )}
                        {listmis.is_upload === 1 &&
                          listmis.document.status === "Reupload" && (
                            <>
                              {btnShowHide.upload > 0 && (
                                <label htmlFor={`rformIdMis${index}`}>
                                  <Input
                                    type="file"
                                    id={`rformIdMis${index}`}
                                    hidden
                                    onChange={(e) =>
                                      handleFileChange(e, listmis.document.id)
                                    }
                                  />
                                  <Avatar
                                    className="mr-1"
                                    icon={<UploadOutlined />}
                                    size={25}
                                    style={{ backgroundColor: `blue`, cursor:`pointer` }}
                                  />
                                </label>
                              )}
                            </>
                          )}

                        {listmis.is_upload === 1
                          ? btnShowHide.edit > 0 && (
                              <Popover
                                content={
                                  <DocumentStatusForm
                                    appid={listmis.document.id}
                                    updateReload={updateReload}
                                    studentId={appDetail.student_id}
                                  />
                                }
                                title="Status"
                                trigger="click"
                              >
                                <label>
                                  <Avatar
                                    className="mr-1"
                                    icon={<EditOutlined />}
                                    size={25}
                                    style={{ backgroundColor: `green`, cursor:`pointer` }}
                                  />
                                </label>
                              </Popover>
                            )
                          : ""}

                        {btnShowHide.delete > 0 &&
                          listmis.is_upload === 1 &&
                          listmis.document.status != "Approved" &&
                          listmis.document.status != "Reupload" && (
                            <label>
                              <Avatar
                                className="mr-1"
                                icon={<DeleteOutlined />}
                                size={25}
                                style={{ backgroundColor: `red`, cursor:`pointer` }}
                                onClick={() => {
                                  deleteStudentDoc(listmis.document.id);
                                }}
                              />
                            </label>
                          )}
                      </div>
                    </Col>
                  </Row>
                </Card>
              );
            })}
          {ListMisOther &&
            ListMisOther.map((ListMisOther, index) => {
              //let name = `pop_${ListMisOther.id}`
              //console.log(ListMisOther)
              //setShowPopuppp([ListMisOther.id])
              //console.log(showPopup)
              return (
                <Card>
                  <Row className="" gutter={16}>
                    <Col xs={24} sm={24} md={5}>
                      {ListMisOther.status === "Approved" ? (
                        <Tag color="cyan" icon={<CheckOutlined />}>
                          {ListMisOther.status}
                        </Tag>
                      ) : ListMisOther.status === "Reupload" ? (
                        <Tag color="orange" icon={<CheckOutlined />}>
                          {ListMisOther.status}
                        </Tag>
                      ) : (
                        <Tag color="red">
                          {ListMisOther.status != ""
                            ? ListMisOther.status
                            : "Pending"}
                        </Tag>
                      )}
                    </Col>
                    <Col xs={24} sm={24} md={14}>
                      <strong>{ListMisOther.document_name}</strong>
                      <br />
                      <p style={{fontSize: `10px` }}>{ListMisOther.updated_at ? ListMisOther.updated_at:''}</p>
                    </Col>

                    <Col xs={24} sm={24} md={3}>
                      <div className="d-flex">
                        {ListMisOther.image != "" && [
                          btnShowHide.download > 0 && (
                            <a
                              href={ListMisOther.image}
                              target="_blank"
                              rel="noopener noreferrer"
                              
                            >
                              <label>
                                <Avatar
                                  className="mr-1"
                                  icon={<EyeOutlined />}
                                  size={25}
                                  style={{ backgroundColor: `orange`, cursor:`pointer` }}
                                />
                              </label>
                            </a>
                          ),
                        ]}
                        {ListMisOther.image != "" ? (
                          ""
                        ) : (
                          <>
                            {btnShowHide.upload > 0 &&
                              ListMisOther.status != "Reupload" && (
                                <label htmlFor={`addRUformIdMis${index}`}>
                                  <Input
                                    type="file"
                                    id={`addRUformIdMis${index}`}
                                    hidden
                                    onChange={(e) =>
                                      handleFileChange(e, ListMisOther.id)
                                    }
                                  />
                                  <Avatar
                                    className="mr-1"
                                    icon={<UploadOutlined />}
                                    size={25}
                                    style={{ backgroundColor: `blue`, cursor:`pointer` }}
                                  />
                                </label>
                              )}
                          </>
                        )}
                        {ListMisOther.status === "Reupload" && (
                          <>
                            {btnShowHide.upload > 0 && (
                              <label htmlFor={`addformIdMis${index}`}>
                                <Input
                                  type="file"
                                  id={`addformIdMis${index}`}
                                  hidden
                                  onChange={(e) =>
                                    handleFileChange(e, ListMisOther.id)
                                  }
                                />
                                <Avatar
                                  className="mr-1"
                                  icon={<UploadOutlined />}
                                  size={25}
                                  style={{ backgroundColor: `blue`, cursor:`pointer` }}
                                />
                              </label>
                            )}
                          </>
                        )}

                        {ListMisOther.image != ""
                          ? btnShowHide.edit > 0 && (
                              <Popover
                                content={
                                  <DocumentStatusForm
                                    appid={ListMisOther.id}
                                    updateReload={updateReload}
                                    studentId={appDetail.student_id}
                                  />
                                }
                                title="Status"
                                trigger="click"
                              >
                                <label>
                                  <Avatar
                                    className="mr-1"
                                    icon={<EditOutlined />}
                                    size={25}
                                    style={{ backgroundColor: `green`, cursor:`pointer` }}
                                  />
                                </label>
                              </Popover>
                            )
                          : ""}

                        {btnShowHide.delete > 0 &&
                          ListMisOther.status != "Approved" &&
                          ListMisOther.status != "Reupload" && (
                            <label>
                              <Avatar
                                className="mr-1"
                                icon={<DeleteOutlined />}
                                size={25}
                                style={{ backgroundColor: `red`, cursor:`pointer` }}
                                onClick={() => {
                                  deleteStudentDoc(ListMisOther.id);
                                }}
                              />
                            </label>
                          )}
                      </div>
                    </Col>
                  </Row>
                </Card>
              );
            })}

          <ConfirmationBox
            id={initialId}
            visible={modalVisibleConfirmation}
            onOKConfirm={onOKConfirm}
            onCancelConfirm={onCancelConfirm}
          />
          <Form.List name="variants">
            {(fields, { add, remove }) => {
              return (
                <div className="mt-3">
                  {fields.map((field, index) => (
                    <Card id={field.name}>
                      <Row key={field.key} gutter={16}>
                        <Col xs={24} sm={24} md={12}>
                          <Form.Item
                            {...field}
                            label=""
                            name={[field.name, "document"]}
                            fieldKey={[field.fieldKey, "document"]}
                            rules={[
                              {
                                required: false,
                                message: "Please select document name",
                              },
                            ]}
                            className="w-100"
                          >
                            {/* <Input placeholder="Document Name" onChange={(e) => inputChange(e, 'document_name')} />
                             */}

                            <Select
                              onChange={(e) => inputChange(e, "document_name")}
                              showSearch
                              placeholder="Select Document"
                              optionFilterProp="children"
                              filterOption={(input, option) =>
                                option.props.children
                                  .toLowerCase()
                                  .indexOf(input.toLowerCase()) >= 0
                              }
                            >
                              {listMisSelect &&
                                listMisSelect.map((listDoc, index) => {
                                  return (
                                    <Option
                                      key={`country${index}`}
                                      value={listDoc.id}
                                    >
                                      {listDoc.name}
                                    </Option>
                                  );
                                })}
                            </Select>
                          </Form.Item>
                        </Col>
                        <Col sm={24} md={4} className="">
                          <Button
                            type="primary"
                            className="mr-2"
                            icon={<PlusCircleOutlined />}
                            size="small"
                            onClick={() => onFinish(field.name, remove)}
                          >
                            Save
                          </Button>
                        </Col>
                        <Col sm={24} md={4}>
                          <Button
                            type="primary"
                            danger
                            className="mr-2"
                            icon={<MinusCircleOutlined />}
                            size="small"
                            onClick={() => {
                              remove(field.name);
                            }}
                          >
                            Cancel
                          </Button>
                        </Col>
                      </Row>
                    </Card>
                  ))}
                  <Form.Item>
                    {btnShowHide.add > 0 && (
                      <Button
                        type="primary"
                        onClick={() => {
                          add();
                        }}
                        className="w-100"
                        ghost
                      >
                        <PlusOutlined /> Add Document
                      </Button>
                    )}
                  </Form.Item>
                </div>
              );
            }}
          </Form.List>
        </div>
      </Form>
    </>
  );
};

export default AppRequirement;
