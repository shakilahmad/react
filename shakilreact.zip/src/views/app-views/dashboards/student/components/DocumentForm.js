import React, { useState, useEffect } from "react";
import {
  Button,
  message,
  Input,
  Row,
  Col,
  Card,
  Form,
  Select,
  Tag,
  Table,
  Tooltip,
  Modal,
  notification,
  Popover,
  Avatar,
} from "antd";
import utils from "utils";
import {
  CloseOutlined,
  CloudUploadOutlined,
  SearchOutlined,
  RightSquareOutlined,
  CheckCircleOutlined,
  CloudDownloadOutlined,
  DeleteOutlined,
  EyeOutlined,
  PlusCircleOutlined,
  EditOutlined,
  UploadOutlined,
} from "@ant-design/icons";
import Flex from "components/shared-components/Flex";
import masterService from "../../../../../services/MasterService";
import leadsService from "../../../../../services/LeadsServices";
import DataDisplayWidget from "components/shared-components/DataDisplayWidget";
import DocumentStatusForm from "./DocumentStatusForm";
import { useSelector } from "react-redux";

const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;
const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
  return (
    <Modal
      destroyOnClose={true}
      title="Course Type"
      open={visible}
      okText="OK"
      onCancel={onCancelConfirm}
      onOk={() => {
        onOKConfirm();
      }}
    >
      Are you sure want to delete this item?
    </Modal>
  );
};

const DocumentForm = (props) => {
  const { mode = ADD, userDetail } = props;
  const student_id = userDetail.id;
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [statusData, setStatusData] = useState({
    uploaded: 0,
    underReview: 0,
    needReupload: 0,
    approved: 0,
  });
  const [docList, setDocList] = useState([]);
  const [listMis, setListMis] = useState([]);
  const [modalVisibleConfirmation, setModalVisibleConfirmation] =
    useState(false);
  const [initialId, setInitialId] = useState(0);
  const [number, setNumber] = useState(100);
  const [btnShow, setBtnShow] = useState(true);
  const [initialVal, setInitialVal] = useState({
    image: "",
    document_name: "",
  });
  const [btnShowHide, setBtnShowHide] = useState({
    add: 0,
    upload: 0,
    delete: 0,
    download: 0,
    status: 0,
  });
  const [docListSelect, setDocListSelect] = useState([]);
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );
  const tableColumns = [
    {
      title: "Sr. No.",
      render: (_, elm, index) => index + 1,
    },
    {
      title: "Document Name",
      dataIndex: "name",
      render: (_, elm) => (
        <>
          {elm.name} {elm.is_required == 1 ? "*" : ""}
        </>
      ),
    },
    {
      title: "Action",
      dataIndex: "",
      render: (_, elm, index) =>
        elm.is_upload ? (
          <Flex>
            {btnShowHide.download > 0 && (
              <Tooltip title="View Document">
                <a href={elm.document.image} target="_blank">
                  <Avatar
                    className="mr-1"
                    icon={<EyeOutlined />}
                    size={25}
                    style={{ backgroundColor: `orange`, cursor: `pointer` }}
                  />
                </a>
              </Tooltip>
            )}
            {btnShowHide.delete > 0 &&
              elm.document.status != "Approved" &&
              elm.document.status != "Reupload" && (
                <Tooltip title="Delete Document">
                  <Avatar
                    className="mr-1"
                    icon={<DeleteOutlined />}
                    size={25}
                    style={{ backgroundColor: `red`, cursor: `pointer` }}
                    onClick={() => {
                        deleteStudentDoc(elm.document.id);
                      }}
                  />
                </Tooltip>
              )}

            {btnShowHide.upload > 0 && elm.document.status == "Reupload" && (
              <Tooltip title="Upload Document">
                <label htmlFor={`MformIdMis${index}`}>
                  <Input
                    type="file"
                    id={`MformIdMis${index}`}
                    hidden
                    onChange={(e) => handleFileChangeReupload(e, elm.document.id)}
                    loading={submitLoading}
                  />
                  <Avatar
                    className="mr-1"
                    icon={<UploadOutlined />}
                    size={25}
                    style={{ backgroundColor: `blue`, cursor: `pointer` }}
                  />
                </label>
              </Tooltip>
            )}
          </Flex>
        ) : (
          <div>
            {btnShowHide.upload > 0 && (
              <Tooltip title="Upload Document">
                <label htmlFor={`NformIdMis${index}`}>
                  <Input
                    type="file"
                    id={`NformIdMis${index}`}
                    hidden
                    onChange={(e) => handleFileChange(e, elm.id)}
                    loading={submitLoading}
                  />
                  <Avatar
                    className="mr-1"
                    icon={<UploadOutlined />}
                    size={25}
                    style={{ backgroundColor: `blue`, cursor: `pointer` }}
                  />
                </label>
              </Tooltip>
            )}
          </div>
        ),
    },
    {
      title: "Date & Time",
      dataIndex: "datetime",
      render: (_, elm) => (elm.is_upload ? elm.document.updated_at : <></>),
    },
    {
      title: "Status",
      dataIndex: "is_active",
      render: (_, elm) =>
        elm.is_upload ? (
          <div className="d-flex">
            {" "}
            <Tag
              className="text-capitalize"
              color={
                elm.document.status === "Reviewing"
                  ? "orange"
                  : elm.document.status === "Approved"
                  ? "green"
                  : "red"
              }
            >
              {elm.document.status}
            </Tag>
            {btnShowHide.status > 0 && (
              <Popover
                content={
                  <DocumentStatusForm
                    appid={elm.document.id}
                    updateReload={updateReload}
                    studentId={userDetail.id}
                  />
                }
                title="Status"
                trigger="click"
              >
                <Tooltip title="Update Document Status">
                    <Avatar
                        className="mr-1"
                        icon={<EditOutlined />}
                        size={25}
                        style={{ backgroundColor: `green`, cursor: `pointer` }}
                    />
                </Tooltip>
              </Popover>
            )}
          </div>
        ) : (
          <Tag className="text-capitalize" color="red">
            {"Pending"}
          </Tag>
        ),
    },
  ];

  const tableColumnsMis = [
    {
      title: "Sr. No.",
      render: (_, elm, index) => index + 1,
    },
    {
      title: "Document Name",
      dataIndex: "",
      render: (_, elm) =>
        elm.student_id ? (
          <>{elm.document_name}</>
        ) : (
          <div>
            <Select
              onChange={(e) => inputChange(e, "document_name")}
              showSearch
              placeholder="Select Document"
              optionFilterProp="children"
              filterOption={(input, option) =>
                option.props.children
                  .toLowerCase()
                  .indexOf(input.toLowerCase()) >= 0
              }
              style={{ width: "350px" }}
            >
              {docListSelect &&
                docListSelect.map((listDocSelect, index) => {
                  return (
                    <Option key={`country${index}`} value={listDocSelect.id}>
                      {listDocSelect.name}
                    </Option>
                  );
                })}
            </Select>
          </div>
        ),
    },
    {
      title: "Action",
      dataIndex: "actions",
      render: (_, elm, index) =>
        elm.student_id ? (
          <Flex>
            {btnShowHide.download > 0 && elm.status != "Pending" && (
              <Tooltip title="View Document">
                <a href={elm.image} target="_blank">
                  <Avatar
                    className="mr-1"
                    icon={<EyeOutlined />}
                    size={25}
                    style={{ backgroundColor: `orange`, cursor: `pointer` }}
                  />
                </a>
              </Tooltip>
            )}
            {btnShowHide.delete > 0 &&
              elm.status != "Approved" &&
              elm.status != "Reupload" && (
                <Tooltip title="Delete Document">
                  <Avatar
                    className="mr-1"
                    icon={<DeleteOutlined />}
                    size={25}
                    style={{ backgroundColor: `red`, cursor: `pointer` }}
                    onClick={() => {
                      deleteStudentDoc(elm.id);
                    }}
                  />
                </Tooltip>
              )}
            {(elm.status == "Reupload" || elm.status == "Pending")  && (
              <Tooltip title="Upload Document">
                <label htmlFor={`RUFormIdMis${index}`}>
                  <Input
                    type="file"
                    id={`RUFormIdMis${index}`}
                    hidden
                    onChange={(e) => handleFileChangeReupload(e, elm.id)}
                    loading={submitLoading}
                  />
                  <Avatar
                    className="mr-1"
                    icon={<UploadOutlined />}
                    size={25}
                    style={{ backgroundColor: `blue`, cursor: `pointer` }}
                  />
                </label>
              </Tooltip>
            )}
          </Flex>
        ) : (
          <>
            <Tooltip title="Upload Document">
              <label htmlFor={`formIdMis${index}`}>
                <Input
                  type="file"
                  id={`formIdMis${index}`}
                  hidden
                  onChange={(e) => inputChange(e, "image")}
                  loading={submitLoading}
                />
                <Avatar
                  className="mr-1"
                  icon={<UploadOutlined />}
                  size={25}
                  style={{ backgroundColor: `blue`, cursor: `pointer` }}
                />
              </label>
            </Tooltip>
          </>
        ),
    },
    {
      title: "Date & Time",
      dataIndex: "datetime",
      render: (_, elm) => elm.updated_at,
    },
    {
      render: (_, elm) =>
        elm.student_id ? (
          <div className="d-flex">
            <Tag
              className="text-capitalize mr-1 py-0"
              color={
                elm.status === "Reviewing"
                  ? "orange"
                  : elm.status === "Approved"
                  ? "green"
                  : "red"
              }
            >
              {elm.status}
            </Tag>
            {btnShowHide.status > 0 && (
              <Popover
                content={
                  <DocumentStatusForm
                    appid={elm.id}
                    updateReload={updateReload}
                    studentId={userDetail.id}
                  />
                }
                title="Status"
                trigger="click"
              >
                <Tooltip title="Edit Document Status">
                  <Avatar
                    className="mr-1"
                    icon={<EditOutlined />}
                    size={25}
                    style={{ backgroundColor: `green`, cursor: `pointer` }}
                  />
                </Tooltip>
              </Popover>
            )}
          </div>
        ) : (
          <div className="d-flex">
            <Tooltip title="Add Document">
              <Avatar
                onClick={() => onFinish()}
                className="mr-1"
                icon={<PlusCircleOutlined />}
                size={25}
                style={{ backgroundColor: `orange`, cursor: `pointer` }}
              />
            </Tooltip>
            <Tooltip title="Remove Document">
              <Avatar
                onClick={(e) => removeMoreDoc(elm.document_id)}
                className="mr-1"
                icon={<CloseOutlined />}
                size={25}
                style={{ backgroundColor: `red`, cursor: `pointer` }}
              />
            </Tooltip>
          </div>
        ),
    },
  ];

  const listData = () => {
    const reqeustParam = {
      student_id: student_id,
      is_active: true,
      is_required: 1,
    };
    try {
      const resp = masterService.getDocuments(reqeustParam);
      resp
        .then((res) => {
          setDocList(res.data);
          setStatusData(res.statusData);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }

    const reqeustParamSelect = { student_id: student_id, is_active: true };
    try {
      const resp = masterService.getDocuments(reqeustParamSelect);
      resp
        .then((res) => {
          setDocListSelect(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  const handleFileChange = (event, doc_id) => {
    setSubmitLoading(true);
    setTimeout(() => {
      const data = new FormData();
      data.append("image", event.target.files[0]);
      data.append("student_id", student_id);
      data.append("document_id", doc_id);
      //console.log(doc_id);
      try {
        const resp = leadsService.documentsStudentUpload(data);
        resp
          .then((res) => {
            listData();
            listOtherData();
            message.success(res.data.message);
          })
          .catch((err) => {
            message.error("Please upload valid data with valid format");
          });
      } catch (errors) {}
    }, 1500);
  };
  const handleFileChangeReupload = (event, doc_id) => {
    setSubmitLoading(true);
    setTimeout(() => {
      const data = new FormData();
      data.append("image", event.target.files[0]);
      data.append("student_id", student_id);
      data.append("student_document_id", doc_id);
      //console.log(doc_id);
      try {
        const resp = leadsService.documentsStudentUpload(data);
        resp
          .then((res) => {
            listData();
            listOtherData();
            message.success(res.data.message);
          })
          .catch((err) => {
            message.error("Please upload valid data with valid format");
          });
      } catch (errors) {}
    }, 1500);
  };

  

  const inputChange = (e, name) => {
    let value =
      name == "image"
        ? e.target.files[0]
        : name == "document_name"
        ? e
        : e.target.value;
    setInitialVal({ ...initialVal, [name]: value });
  };

  const onFinish = () => {
    if (initialVal.document_name != "" && initialVal.image != "") {
      const data = new FormData();
      data.append("student_id", student_id);
      data.append("document_id", initialVal.document_name);
      data.append("image", initialVal.image);
      data.append("other_doc", "Yes");
      try {
        const resp = leadsService.documentsStudentUpload(data);
        resp
          .then((res) => {
            listData()
            listOtherData();
            setBtnShow(false);
            message.success("document upload successfully.");
          })
          .catch((err) => {
            message.error(err.response.data.message);
          });
      } catch (errors) {}
    }
  };
  const listOtherData = () => {
    const reqeustParam = { student_id: student_id, type: "" };
    try {
      const respData = leadsService.documentsStudent(reqeustParam);
      respData
        .then((res) => {
          setListMis(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };
  const removeMoreDoc = (value) => {
    const data = utils.deleteArrayRow(listMis, "document_id", value);
    setListMis(data);
    setBtnShow(false);
  };

  const addMoreField = () => {
    const newElement = {
      id: number,
      student_id: null,
      document_name: null,
      document_id: `${number}_doc`,
      image: "",
      status: "",
    };
    setNumber(number + 1);
    setListMis((listMis) => [...listMis, newElement]);
    setBtnShow(true);
  };

  useEffect(() => {
    listData();
    listOtherData();
    const addPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 54
    );
    const uploadPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 55
    );
    const downloadPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 57
    );
    const delPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 56
    );
    const statusPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 58
    );
    setBtnShowHide({
      add: addPermission.length,
      upload: uploadPermission.length,
      delete: delPermission.length,
      download: downloadPermission.length,
      status: statusPermission.length,
    });
  }, []);

  const deleteStudentDoc = (elm) => {
    setInitialId(elm);
    setModalVisibleConfirmation(true);
  };

  const onCancelConfirm = () => {
    if (initialId != 0) {
      setInitialId(0);
    }
    setModalVisibleConfirmation(false);
  };

  const onOKConfirm = () => {
    let value = initialId;
    const reqeustParam = { student_document_id: value, student_id: student_id };
    const resp = leadsService.documentsStudentDelete(reqeustParam);
    resp
      .then((res) => {
        if (res.status === 200) {
          setModalVisibleConfirmation(false);
          listData();
          listOtherData();
          notification.success({ message: res.message });
        }
      })
      .catch((err) => {});
  };
  const updateReload = () => {
    listData();
    listOtherData();
  };
  let i = 1;
  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
      >
        <div className="container123">
          <Row gutter={16}>
            <Col xs={24} sm={24} md={6}>
              <DataDisplayWidget
                icon={<CloudUploadOutlined />}
                value={statusData.uploaded}
                title="Uploaded"
                color="cyan"
                vertical={true}
                avatarSize={55}
              />
            </Col>
            <Col xs={24} sm={24} md={6}>
              <DataDisplayWidget
                icon={<SearchOutlined />}
                value={statusData.underReview}
                title="Under Review"
                color="cyan"
                vertical={true}
                avatarSize={55}
              />
            </Col>
            <Col xs={24} sm={24} md={6}>
              <DataDisplayWidget
                icon={<RightSquareOutlined />}
                value={statusData.needReupload}
                title="Need Reuploadation"
                color="cyan"
                vertical={true}
                avatarSize={55}
              />
            </Col>
            <Col xs={24} sm={24} md={6}>
              <DataDisplayWidget
                icon={<CheckCircleOutlined />}
                value={statusData.approved}
                title="Approved"
                color="cyan"
                vertical={true}
                avatarSize={55}
              />
            </Col>
          </Row>
          <Card title={`Documents`}>
            <hr />
            <div className="table-responsive">
              <Table
                key={i++}
                columns={tableColumns}
                dataSource={docList}
                rowKey="id"
                pagination={false}
              />
            </div>
          </Card>
          <Card title={`Add More Documents`}>
            <hr />
            <div className="table-responsive">
              <Table
                key={i++}
                columns={tableColumnsMis}
                dataSource={listMis}
                rowKey="id"
                pagination={false}
              />
            </div>
            {btnShowHide.add > 0 && (
              <Button
                className="mt-2"
                hidden1={btnShow}
                type="primary"
                icon={<CloudUploadOutlined />}
                onClick={() => {
                  addMoreField();
                }}
              >
                Upload Other Documents
              </Button>
            )}
            &nbsp;&nbsp;
            {btnShowHide.download > 0 && (
              <Button
                className="mt-2"
                type="primary"
                icon={<CloudDownloadOutlined />}
              >
                Download All Documents
              </Button>
            )}
          </Card>
        </div>
      </Form>
      <ConfirmationBox
        id={initialId}
        visible={modalVisibleConfirmation}
        onOKConfirm={onOKConfirm}
        onCancelConfirm={onCancelConfirm}
      />
    </>
  );
};

export default DocumentForm;
