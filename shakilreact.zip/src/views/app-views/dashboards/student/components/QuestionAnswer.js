import React, { useState, useEffect } from "react";
import leadsService from "../../../../../services/LeadsServices";
import {
  Button,
  message,
  Input,
  Row,
  Col,
  Card,
  Form,
  Select,
  Switch,
  Radio,
  DatePicker,
  Checkbox,
} from "antd";

import masterService from "../../../../../services/MasterService";
import { useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';
import TextArea from "antd/es/input/TextArea";


const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const QuestionAnswer = (props) => {
  //console.log(props)
  const dateFormat = 'DD/MM/YYYY';
  const { mode = ADD, userDetail } = props;
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [countryList, setCountryList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [cityList, setCityList] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [statusShow, setStatusShow] = useState(false);
  const[questionList, setQuestionList] = useState([])


  const listQuestionData = () => {
    const reqeustParam = {is_active:1,course_type_id:props.courseTypeId,student_id:userDetail.id};
    try {
      const resp = masterService.getQuestion(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setQuestionList(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  /* const listStateData = () => {
    const reqeustParam = {country_id:userDetail.country_id};
    try {
      const resp = masterService.getState(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setStateList(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };
  const listCityData = () => {
    const reqeustParam = {state_id:userDetail.state_id};
    try {
      const resp = masterService.getCity(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setCityList(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  const listStatusesData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getStatus(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setStatuses(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };
*/
let onbj = {}
  useEffect(() => {
    
    listQuestionData()
    //listCountryData();
    //listStatusesData();
    //listStateData()
    //listCityData()
    //console.log(props)
	
    if (mode === EDIT) {
           // console.log('is edit')
           // console.log('props', props)
            //const {  id } = userDetail
            //console.log(userDetail)
          
            
                


            
            
            
        }
	
	
	
	
  }, [form, mode, props]);

  const onFinish =  () => {
    //console.log('on finish')
    setSubmitLoading(true);
    form
      .validateFields()
      .then((values) => {
        setTimeout(() => {
          setSubmitLoading(false);
          
          if (mode === EDIT) {
            //console.log(values)
            const studentId = parseInt(userDetail.id)
			
            let arrQuest = []
            questionList.map((list) => {
                let name = `name_${list.id}`
                let nameCheck;
                //console.log(values[name])
                if(Array.isArray(values[name])){
                  //console.log('yes')
                  if(values[name].length > 0){
                  nameCheck=values[name].join(',')
                  }else{
                    nameCheck=''  
                  }
                }else{
                  //console.log('no')
                  nameCheck=values[name]
                }
                
                
                let obj = {
                    question_id:list.id,
                    answer:nameCheck
                }
                
                arrQuest.push(obj)
                //console.log(values[name]);
            })
            let objQuestin = {
                student_id:userDetail.id,
                details:arrQuest
            }
            //console.log(objQuestin)


			//let statusname = values.is_active === true ? 1: values.is_active === 1 ? 1 : 0
             //const data = {...values, is_active:statusname, student_id:studentId}
			 const resp = leadsService.questionAnswerStudent(objQuestin)
			
            //console.log(resp);
            //console.log(resp.data);
       resp.then(res => {
        message.success(`Other information successfully updated.`);
        listQuestionData()
        //props.showProfile();  
       }).catch(err => {

       }) 
           

      
            //navigate(`/dashboards/student`)
			
          }
        }, 1500);
      })
      .catch((info) => {
        setSubmitLoading(false);
        console.log("info", info);
        message.error("Please enter all required field ");
      });
  };

  const statusOnChange = (show) => {
    setStatusShow(show);
  };

  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
        
      >
        <div className="container123">
          <Card title={`Other Information`}>
            <hr />
            <Row className="pt-5 px-lg-5" gutter={16}>
              
              {questionList && questionList.map((list,index) => {
                let arrOpt
                //console.log('dddd')
                if(list.is_type === 'Select' || list.is_type === 'Radio Buttons' || list.is_type === 'Checkbox'){
                    if(list.options !=''){
                        //console.log(list.options)
                        let str = String(list.options)
                        arrOpt = str.split(',');
                        //console.log(arrOpt)
                    }
                }


                
                
                
                !submitLoading &&
                form.setFieldsValue({
                    [`name_${list.id}`]: list.answer,
                    
                            
              })  
              

              return(
              
              <Col xs={24} sm={24} md={24}>
              <Card>  
                <Form.Item name={`name_${list.id}`} label={list.title} style={{fontWeight:`600`,marginBottom:`5px`}} rules={[
                    {
                      required: false,
                      message: "Please enter first name!",
                    },
                    
                  ]}>
                  
                 { list.is_type ==='Textbox' ?
                  <Input />
                  :
                  list.is_type === 'Select' ?
                  <Select
                    showSearch
                    placeholder="Select"
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                      option.props.children
                        .toLowerCase()
                        .indexOf(input.toLowerCase()) >= 0
                    }
                  >
                    {arrOpt &&
                      arrOpt.map((listopt, index) => {
                        return (
                          <Option
                            key={`country${index}`}
                            value={listopt}
                          >
                            {listopt}
                          </Option>
                        );
                      })}
                  </Select>
                  :
                  list.is_type === 'Text Area' ?
                  <TextArea />   
                  :
                  list.is_type === 'Checkbox' ?
                  <Checkbox.Group options={arrOpt}  />
                  :
                  list.is_type === 'Radio Buttons' ?
                  <Radio.Group>
                    {arrOpt &&
                      arrOpt.map((listopt, index) => {
                    return (
                    <Radio value={listopt}>{listopt}</Radio>
                    )
                      })}
                    
                  </Radio.Group>   
                  :
                  ''
                }
                  
                  
                
                

                </Form.Item>
                </Card>
              </Col>
              )
            })
            }
              
            </Row>

            <Row className="px-lg-5">
              <Col xs={24} sm={24} md={12}>
                <Button
                  className="px-5"
                  type="primary"
                  htmlType="submit"
                  loading={submitLoading}
                  onClick={() => onFinish()}
                >
                  {mode === "ADD" ? "Submit" : `Save`}
                </Button>
              </Col>
            </Row>
          </Card>
        </div>
      </Form>
    </>
  );
};

export default QuestionAnswer;
