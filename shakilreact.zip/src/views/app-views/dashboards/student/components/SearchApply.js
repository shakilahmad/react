import React, { useState, useEffect } from "react";
import {
  Button,
  Input,
  Row,
  Col,
  Card,
  Form,
  Select,
  notification,
  Spin,
  Pagination,
  Popconfirm,
  Modal,
} from "antd";
import {
  FileAddOutlined,
  SearchOutlined,
  EnvironmentOutlined,
  ArrowRightOutlined,
  ReloadOutlined,
} from "@ant-design/icons";

import masterService from "../../../../../services/MasterService";
import leadsService from "../../../../../services/LeadsServices";
import { useNavigate } from "react-router-dom";
import universityService from "../../../../../services/UniversityService";
import { YEARS, MONTHS } from "constants/AuthConstant";
const ADD = "ADD";
const { Option } = Select;

const CollegeCard = ({
  collegeCoursesList,
  applyCourse,
  submitLoading,
  studentId,
  showPopup,
  collegeCoursesListApply
}) => {
  return collegeCoursesList.map((item, index) => {
    //console.log(collegeCoursesListApply)
    return (
      <Card key={item.id}>
        <p className="pb-0 mb-0">
          {item.duration} {item.course?.course_type} {item.course?.level}
        </p>
        <h4>{item.course?.name}</h4>
        <p>
          <a>{item.college?.name}</a>
          <span className="pl-lg-5 pl-3">
            <EnvironmentOutlined /> {item.college?.address}
          </span>
        </p>
        <Row gutter={16}>
          <Col xs={24} sm={24} md={24} lg={12}>
            <p className="pb-0 mb-0">Gross Tuition</p>
            <p className="pt-0 mt-0">{item.estimate_fee}</p>
          </Col>
          <Col xs={24} sm={24} md={24} lg={12}>
            <p className="pb-0 mb-0">Application Fee</p>
            <p className="pt-0 mt-0">{item.application_fee}</p>
          </Col>
        </Row>

        <div className="">
          {studentId && (
            <>
              {collegeCoursesListApply && collegeCoursesListApply.includes(item.id) ?

                <Popconfirm
                  title="Course has already been applied."
                  onConfirm={(e) => applyCourse(index, item)}
                >
                  <Button
                    className="px-4 mb-2 mr-2"
                    type="primary"

                  >
                    Create Application <FileAddOutlined />
                  </Button>
                </Popconfirm>
                :
                <Popconfirm
                  title="Sure to Create Application"
                  onConfirm={(e) => applyCourse(index, item)}
                >
                  <Button
                    className="px-4 mb-2 mr-2"
                    type="primary"
                    loading={submitLoading}
                  >
                    Create Application <FileAddOutlined />
                  </Button>
                </Popconfirm>
              }

            </>

          )}
          {item.course_link && (
            <>
              <a
                href={`${item.course_link}`}
                className="mb-2"
                target="_blank"
              >
                Program details <ArrowRightOutlined />
              </a>
            </>
          )}
        </div>
      </Card>
    );
  });
};

const SearchApply = (props) => {
  const { mode = ADD, userDetail = [] } = props;
  const studentId = userDetail.id;
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [countryList, setCountryList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [courseList, setCourseList] = useState([]);
  const [collegeList, setCollegeList] = useState([]);
  const [collegeCoursesList, setCollegeCoursesList] = useState([]);
  const [collegeCoursesListApply, setCollegeCoursesListApply] = useState([]);
  const [courseTypeList, setCourseTypeList] = useState([]);
  const [showLoader, setShowLoader] = useState(true);
  const [record, setrecord] = useState(1);
  const [modalVisibleConfirmation, setModalVisibleConfirmation] =
    useState(false);
    const [categoryList, setCategoryList] = useState([]);
  const [collegeFilter, setCollegeFilter] = useState({
    is_active: true,
    course_name: "",
    college_location: "",
    destination: "",
    college_name: "",
    level: "",
    stream: "",
    intake_month: "",
    intake_year: "",
    student_id: studentId,
    category_id:""
  });

  const listCourse = () => {
    const reqeustParam = { is_active: 1 };
    try {
      const resp = masterService.getCourse(reqeustParam);
      resp
        .then((res) => {
          setCourseList(res.data);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };
  const listCourseType = () => {
    const reqeustParam = { is_active: 1 };
    try {
      const resp = masterService.getCourseType(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setCourseTypeList(res.data);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };
  const listCountryData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getCountry(reqeustParam);
      resp
        .then((res) => {
          setCountryList(res.data);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };

  const listStateData = () => {
    const reqeustParam = { country_id: userDetail.interest_country_id };
    try {
      const resp = masterService.getState(reqeustParam);
      resp
        .then((res) => {
          setStateList(res.data);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };

  const listCollegesData = () => {
    const reqeustParam = { is_active: 1 };
    try {
      const resp = universityService.getCollegeList(reqeustParam);
      resp
        .then((res) => {
          setCollegeList(res.data);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };
  const listCategoryData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getCategory(reqeustParam);
      resp
        .then((res) => {
          setCategoryList(res.data);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };
  const ConfirmationBox = ({ visible, onOKConfirm, onCancelConfirm }) => {
    return (
      <Modal
        destroyOnClose={true}
        title="Create Application"
        open={visible}
        onCancel={onCancelConfirm}
        onOk={() => {
          onOKConfirm();
        }}

      >
        Are you sure want to delete this item?
      </Modal>
    );
  };
  const onCancelConfirm = () => {

    setModalVisibleConfirmation(false);
  };
  const onOKConfirm = () => {
    //console.log('okkkkkk')
  };

  const showPopup = () => {
    setModalVisibleConfirmation(true);
  }

  const listCollegeCoursesData = (page, pageSize) => {
    const reqeustParam = collegeFilter;
    reqeustParam.page = page;
    reqeustParam.pageSize = pageSize;
    try {
      const resp = universityService.getCollegeCoursesList(reqeustParam);
      resp
        .then((res) => {
          setrecord(parseInt(res.data.total));
          setCollegeCoursesList(res.data.data);
          setCollegeCoursesListApply(res.data.apply_course)
          setShowLoader(false);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };

  const nexPageData = (page, pageSize) => {
    listCollegeCoursesData(page, pageSize);
  };

  useEffect(() => {
    listCountryData();
    listCategoryData();
    //listStateData();
    //listCourse();
    //listCourseType();
    //listCollegesData();
    listCollegeCoursesData(1, 10);
  }, []);

  const applyCourse = (index, value) => {
    setSubmitLoading(true);
    const reqeustParam = { student_id: studentId, college_course_id: value.id };
    try {
      const resp = leadsService.applicationApplyStudent(reqeustParam);
      resp
        .then((res) => {
          if (res.status == 200) {
            notification.success({ message: res.message });
            //const newData = [...collegeCoursesList];
            //newData.splice(index, 1);
            //setCollegeCoursesList(newData);
            listCollegeCoursesData(1, 10);
          } else {
            notification.error({ message: res.message });
          }
        })
        .catch((err) => {
          console.log(err);
        });
    } catch (errors) {
      console.log(errors);
    }
    setSubmitLoading(false);
  };

  const inputChange = (e, name) => {
    let value =
      name == "course_name" ||
        name == "college_location" ||
        name == "college_name"
        ? e.target.value
        : e;
    setCollegeFilter({ ...collegeFilter, [name]: value });
    //console.log(collegeFilter);
  };

  const onSearch = () => {
    listCollegeCoursesData();
  };

  const resetFormData = () => {
    form.resetFields();
    setCollegeFilter({
      is_active: true,
      course_name: "",
      college_location: "",
      destination: "",
      college_name: "",
      level: "",
      stream: "",
      intake_month: "",
      intake_year: "",
      student_id: studentId,
      category_id:""
    });
    collegeFilter.is_active=true
    collegeFilter.course_name=""
    collegeFilter.college_location=""
    collegeFilter.destination=""
    collegeFilter.college_name=""
    collegeFilter.level=""
    collegeFilter.stream=""
    collegeFilter.intake_month=""
    collegeFilter.intake_year=""
    collegeFilter.student_id=studentId
    collegeFilter.category_id=""

    listCollegeCoursesData();
  };

  return (
    <>
      <ConfirmationBox

        visible={modalVisibleConfirmation}
        onOKConfirm={onOKConfirm}
        onCancelConfirm={onCancelConfirm}
      />
      <Spin size="large" spinning={showLoader}>
        <Form
          layout="vertical"
          form={form}
          name="advanced_search"
          className="ant-advanced-search-form"
          initialValues={setCollegeFilter}
        >
          <Row className="my-3 text-center" gutter={16}>
            <Col xs={24} sm={24} md={24} lg={24}>
              <Input.Group compact>
                <Form.Item name="course_name">
                  <Input
                    className="mb-2"
                    style={{ width: "270px", borderRadius: 0 }}
                    placeholder="What would you like to study"
                    onChange={(e) => inputChange(e, "course_name")}
                  />
                </Form.Item>
                <Form.Item name="college_location">
                  <Input
                    className="mb-2"
                    style={{ width: "270px", borderRadius: 0 }}
                    placeholder="Where? e.g. school or location"
                    onChange={(e) => inputChange(e, "college_location")}
                  />
                </Form.Item>
                <Button
                  type="primary"
                  style={{ width: "270px", borderRadius: 0, height: "39px" }}
                  icon={<SearchOutlined />}
                  onClick={(e) => onSearch()}
                >
                  Search
                </Button>
              </Input.Group>
            </Col>
          </Row>
          <hr />
          <Row className="mt-4" gutter={16}>
            <Col xs={24} sm={24} md={24} lg={8}>
              <div className="">
                <h4>Eligibility</h4>
                <Card>
                  <Form.Item label="Destination" name="destination">
                    <Select
                      onChange={(e) => inputChange(e, "destination")}
                      showSearch
                      placeholder="Select Country"
                      optionFilterProp="children"
                      filterOption={(input, option) =>
                        option.props.children
                          .toLowerCase()
                          .indexOf(input.toLowerCase()) >= 0
                      }
                    >
                      {countryList &&
                        countryList.map((countrylist, index) => {
                          return (
                            <Option
                              key={`country${index}`}
                              value={countrylist.id}
                            >
                              {countrylist.name}
                            </Option>
                          );
                        })}
                    </Select>
                  </Form.Item>

                  <Form.Item
                    name="college_name"
                    label="Colleges & University name"
                  >
                    <Input
                      placeholder="Colleges/University name"
                      onChange={(e) => inputChange(e, "college_name")}
                    />
                  </Form.Item>
                  <Form.Item label="Category" name="category_id">
                    <Select
                      onChange={(e) => inputChange(e, "category_id")}
                      showSearch
                      placeholder="Select Category"
                      optionFilterProp="children"
                      filterOption={(input, option) =>
                        option.props.children
                          .toLowerCase()
                          .indexOf(input.toLowerCase()) >= 0
                      }
                    >
                      {categoryList &&
                        categoryList.map((countrylist, index) => {
                          return (
                            <Option
                              key={`category${index}`}
                              value={countrylist.id}
                            >
                              {countrylist.name}
                            </Option>
                          );
                        })}
                    </Select>
                  </Form.Item>      
                  <Form.Item label="Level" name="level">
                    <Select
                      showSearch
                      placeholder=""
                      optionFilterProp="children"
                      filterOption={(input, option) =>
                        option.props.children
                          .toLowerCase()
                          .indexOf(input.toLowerCase()) >= 0
                      }
                      onChange={(e) => inputChange(e, "level")}
                    >
                      <Option key={`level1`} value="I don't have this">
                        I don't have this
                      </Option>
                    </Select>
                  </Form.Item>

                  <Form.Item label="Stream" name="stream">
                    <Select
                      showSearch
                      placeholder=""
                      optionFilterProp="children"
                      filterOption={(input, option) =>
                        option.props.children
                          .toLowerCase()
                          .indexOf(input.toLowerCase()) >= 0
                      }
                      onChange={(e) => inputChange(e, "stream")}
                    >
                      <Option key={`stream1`} value="I don't have this">
                        I don't have this
                      </Option>
                    </Select>
                  </Form.Item>

                  <Form.Item label="Intake Month" name="intake_month">
                    <Select
                      showSearch
                      placeholder=""
                      optionFilterProp="children"
                      filterOption={(input, option) =>
                        option.props.children
                          .toLowerCase()
                          .indexOf(input.toLowerCase()) >= 0
                      }
                      onChange={(e) => inputChange(e, "intake_month")}
                    >
                      {MONTHS &&
                        MONTHS.map((month, index) => {
                          return (
                            <Option key={`month${index}`} value={month}>
                              {month}
                            </Option>
                          );
                        })}
                    </Select>
                  </Form.Item>

                  <Form.Item label="Intake Year" name="intake_year">
                    <Select
                      showSearch
                      placeholder=""
                      optionFilterProp="children"
                      filterOption={(input, option) =>
                        option.props.children
                          .toLowerCase()
                          .indexOf(input.toLowerCase()) >= 0
                      }
                      onChange={(e) => inputChange(e, "intake_year")}
                    >
                      {YEARS &&
                        YEARS.map((year) => {
                          return (
                            <Option key={`year${year}`} value={year}>
                              {year}
                            </Option>
                          );
                        })}
                    </Select>
                  </Form.Item>
                  <Button
                    type="primary"
                    icon={<ReloadOutlined />}
                    onClick={(e) => resetFormData()}
                    className="bg-success mr-2 text-white"
                  >
                    Clear
                  </Button>
                  <Button
                    type="primary"
                    icon={<SearchOutlined />}
                    onClick={(e) => onSearch()}
                  >
                    Apply Filter
                  </Button>
                </Card>
              </div>
            </Col>
            <Col xs={24} sm={24} md={24} lg={16}>
              <h4>Colleges/Universities</h4>
              <CollegeCard
                collegeCoursesList={collegeCoursesList}
                applyCourse={applyCourse}
                submitLoading={submitLoading}
                studentId={studentId}
                showPopup={showPopup}
                collegeCoursesListApply={collegeCoursesListApply}
              />
            </Col>
          </Row>
          <div className="text-right mt-3">
            <Pagination
              defaultCurrent={1}
              total={record}
              onChange={nexPageData}
              hideOnSinglePage
              pageSizeOptions={[10, 50, 100, 500]}
            />
          </div>
        </Form>
      </Spin>


    </>
  );
};

export default SearchApply;
