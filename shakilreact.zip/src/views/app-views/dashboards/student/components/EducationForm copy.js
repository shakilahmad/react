import React, { useState, useEffect } from "react";
import leadsService from "../../../../../services/LeadsServices";
import {
  Button,
  message,
  Input,
  Row,
  Col,
  Card,
  Form,
  Select,
  Switch,
  Radio,
  DatePicker,
  Table,
} from "antd";
import { MinusCircleOutlined, PlusOutlined } from "@ant-design/icons";
import masterService from "../../../../../services/MasterService";
import { useNavigate } from "react-router-dom";
import dayjs from "dayjs";

const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const EducationForm123 = (props) => {
  const dateFormat = "DD/MM/YYYY";
  const { mode = ADD, userDetail } = props;
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [countryList, setCountryList] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [statusShow, setStatusShow] = useState(false);

  const listCountryData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getCountry(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setCountryList(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  const listStatusesData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getStatus(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setStatuses(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    listCountryData();
    listStatusesData();

    if (mode === EDIT) {
      const studentId = parseInt(userDetail.id);
    }
  }, [form, mode, props]);

  const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 4 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 20 },
    },
  };
  const formItemLayoutWithOutLabel = {
    wrapperCol: {
      xs: { span: 24, offset: 0 },
      sm: { span: 20, offset: 4 },
    },
  };

  const statusOnChange = (show) => {
    setStatusShow(show);
  };

  const columns = [
    {
      title: "Country of Education",
      dataIndex: "education_country_id",
      key: "education_country_id",
      //width: "12%",
      //use the field here to get all infos for the form
      render: (_, field) => (
        <Form.Item
          {...field}
          name={[field.name, "education_country_id"]}
          key={[field.key, "education_country_id"]}
          noStyle
        >
          <Select
            showSearch
            placeholder="Select Country"
            optionFilterProp="children"
            filterOption={(input, option) =>
              option.props.children
                .toLowerCase()
                .indexOf(input.toLowerCase()) >= 0
            }
          >
            {countryList &&
              countryList.map((countrylist, index) => {
                return (
                  <Option key={`country${index}`} value={countrylist.id}>
                    {countrylist.name}
                  </Option>
                );
              })}
          </Select>
        </Form.Item>
      ),
    },
    {
      title: "Heighest Level of Education",
      dataIndex: "high_education",
      key: "high_education",
      render: (_, field) => (
        <Form.Item
          {...field}
          name={[field.name, "high_education"]}
          //@ts-ignore
          key={[field.key, "high_education"]}
          noStyle
        >
          <Select
            showSearch
            placeholder="Please choose a education"
            optionFilterProp="children"
            filterOption={(input, option) =>
              option.props.children
                .toLowerCase()
                .indexOf(input.toLowerCase()) >= 0
            }
          >
            <Option key={`edu1`} value="Grade 10">
              Grade 10
            </Option>
            <Option key={`edu2`} value="Grade 11">
              Grade 11
            </Option>
            <Option key={`edu3`} value="Grade 12">
              Grade 12
            </Option>
            <Option key={`edu4`} value="1yr Certification after High School">
              1yr Certification after High School
            </Option>
            <Option key={`edu5`} value="2yr Undergraduate Diploma">
              2yr Undergraduate Diploma
            </Option>
            <Option key={`edu6`} value="3yr Bachelor Degree">
              3yr Bachelor Degree
            </Option>
            <Option key={`edu7`} value="Post Graduate Diploma/Cert">
              Post Graduate Diploma/Cert
            </Option>
            <Option key={`edu8`} value="Masters Degree">
              Masters Degree
            </Option>
          </Select>
        </Form.Item>
      ),
    },
    {
      title: "Grading Scheme",
      dataIndex: "grading_schema",
      key: "grading_schema",
      render: (_, field) => (
        <Form.Item
          {...field}
          name={[field.name, "grading_schema"]}
          //@ts-ignore
          key={[field.key, "grading_schema"]}
          noStyle
        >
          <Select
            showSearch
            placeholder="Please choose a grading scheme"
            optionFilterProp="children"
            filterOption={(input, option) =>
              option.props.children
                .toLowerCase()
                .indexOf(input.toLowerCase()) >= 0
            }
          >
            <Option key={`grade1`} value="Grade 10">
              Out of 5
            </Option>
            <Option key={`grade2`} value="Grade 11">
              Out of 10
            </Option>
            <Option key={`grade3`} value="Grade 12">
              Out of 100
            </Option>
          </Select>
        </Form.Item>
      ),
    },
    {
      title: "Score",
      dataIndex: "score",
      key: "score",
      render: (_, field) => (
        <Form.Item
          {...field}
          name={[field.name, "score"]}
          //@ts-ignore
          key={[field.key, "score"]}
          noStyle
        >
          <Input placeholder="score" />
        </Form.Item>
      ),
    },
  ];

  const itemInputs = userDetail.educations.map((item) => {
    return {
      education_country_id: parseInt(item.education_country_id),
      high_education: item.high_education,
      grading_schema: item.grading_schema,
      score: item.score,
    };
  });
  const onFinish = (values) => {
    //console.log('Received values of form:', values);
    if (mode === EDIT) {
      leadsService.educationHistoryStudent(values);
      message.success(`Background info successfully updated.`);
      //navigate(`/dashboards/student`)
    }
  };
  return (
    <>
      <Form onFinish={onFinish}>
        <Card title={`Education History`}>
          <hr />

          <Form.Item
            name="student_id"
            initialValue={userDetail.id}
            style={{ display: "none" }}
          >
            <Input />
          </Form.Item>

          <Form.List name="educationHistory" initialValue={itemInputs}>
            {(fields, { add, remove }, { errors }) => (
              <>
                <Table
                  dataSource={fields}
                  columns={columns}
                  pagination={false}
                />
                <Form.Item className="mt-3">
                  <Button
                    type="dashed"
                    onClick={() => add()}
                    icon={<PlusOutlined />}
                  >
                    Add More Education
                  </Button>
                  <Form.ErrorList errors={errors} />
                </Form.Item>
              </>
            )}
          </Form.List>

          <Form.Item>
            <Button type="primary" htmlType="submit">
              {" "}
              Submit{" "}
            </Button>
          </Form.Item>
        </Card>
      </Form>
    </>
  );
};

export default EducationForm123;
