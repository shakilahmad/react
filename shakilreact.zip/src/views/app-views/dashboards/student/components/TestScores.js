import React, { useState, useEffect } from "react";
import leadsService from "../../../../../services/LeadsServices";
import {
    Button,
    message,
    Input,
    Row,
    Col,
    Card,
    Form,
    Select,
    Switch,
    Radio,
    DatePicker,
} from "antd";

import masterService from "../../../../../services/MasterService";
import { useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';
const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const TestScores = (props) => {
    const dateFormat = 'DD/MM/YYYY';
    const { mode = ADD, userDetail } = props;
    const navigate = useNavigate();
    const [form] = Form.useForm();
    const [submitLoading, setSubmitLoading] = useState(false);
    const [countryList, setCountryList] = useState([]);
    const [statuses, setStatuses] = useState([]);
    const [statusShow, setStatusShow] = useState(false);
    const [show, setShow] = useState(false)

    const listCountryData = () => {
        const reqeustParam = {};
        try {
            const resp = masterService.getCountry(reqeustParam);
            resp
                .then((res) => {
                    setCountryList(res.data);
                })
                .catch((err) => { });
        } catch (errors) {
            console.log(errors);
        }
    };

    const listStatusesData = () => {
        const reqeustParam = {};
        try {
            const resp = masterService.getStatus(reqeustParam);
            resp
                .then((res) => {
                    setStatuses(res.data);
                })
                .catch((err) => { });
        } catch (errors) {
            console.log(errors);
        }
    };

    useEffect(() => {
        listCountryData();
        listStatusesData();
        if (mode === EDIT) {
            showValue(userDetail.english_exam_type)
            statusOnChange(userDetail.is_active)
            form.setFieldsValue({
                english_exam_type: userDetail.english_exam_type === 'undefined' ? '' : userDetail.english_exam_type,
                exam_date: userDetail.exam_date === 'undefined' ? '' : (userDetail.exam_date != '' ? dayjs(userDetail.exam_date, dateFormat) : ''),
                exact_score: userDetail.exact_score === 'undefined' ? '' : userDetail.exact_score,
                reading: userDetail.reading === 'undefined' ? '' : userDetail.reading,
                writing: userDetail.writing === 'undefined' ? '' : userDetail.writing,
                speaking: userDetail.speaking === 'undefined' ? '' : userDetail.speaking,
                listening: userDetail.listening === 'undefined' ? '' : userDetail.listening,
            });
        }
    }, [form, mode, props]);

    const onFinish = () => {
        setSubmitLoading(true);
        form
            .validateFields()
            .then((values) => {
                setTimeout(() => {
                    setSubmitLoading(false);
                    if (mode === EDIT) {
                        let daytm=''
                        if(values.exam_date){
                        let dayyear = dayjs(values.exam_date).year();
                        let daymonth = dayjs(values.exam_date).month() + 1;
                        let daydate = dayjs(values.exam_date).date();
                        daytm = `${dayyear}-${daymonth}-${daydate}`
                        }
                        
                        const studentId = parseInt(userDetail.id)
                        const data = { ...values, student_id: studentId, exam_date:daytm }
                        leadsService.testScoreStudent(data)
                        message.success(`Test score successfully updated.`);
                    }
                }, 1500);
            })
            .catch((info) => {
                setSubmitLoading(false);
                console.log("info", info);
                message.error("Please enter all required field ");
            });
    };

    const statusOnChange = (show) => {
        setStatusShow(show);
    };

    const showValue = (value) => {
        if (value === "I don't have this" || value === 'I will provide this later') {
            setShow(false)
        } else {
            setShow(true)
        }
    }

    return (
        <>
            <Form
                layout="vertical"
                form={form}
                name="advanced_search"
                className="ant-advanced-search-form"
            >
                <div className="container123">
                    <Card title={`Test Scores`}>
                        <hr />
                        <Row className="pt-5 px-lg-5" gutter={16}>
                            <Col xs={24} sm={24} md={8}>
                                <Form.Item label="English Exam Type" name="english_exam_type" rules={[
                                    {
                                        required: true,
                                        message: "Please enter english exam type!",
                                    },
                                ]}>
                                    <Select
                                        onChange={showValue}
                                        showSearch
                                        placeholder="Please choose a english exam type"
                                        optionFilterProp="children"
                                        filterOption={(input, option) =>
                                            option.props.children
                                                .toLowerCase()
                                                .indexOf(input.toLowerCase()) >= 0
                                        }
                                    >
                                        <Option key={`eng1`} value="I don't have this">I don't have this</Option>
                                        <Option key={`eng2`} value="I will provide this later">I will provide this later</Option>
                                        <Option key={`eng3`} value="TOEFL">TOEFL</Option>
                                        <Option key={`eng4`} value="IELTS">IELTS</Option>
                                        <Option key={`eng4`} value="PTE">PTE</Option>
                                        <Option key={`eng5`} value="Duolingo English Test">Duolingo English Test</Option>
                                    </Select>
                                </Form.Item>
                            </Col>

                            {show &&
                                <>
                                    <Col xs={24} sm={24} md={8}>
                                        <Form.Item name="exam_date" label="Date of Exam" rules={[
                                            {
                                                required: false,
                                                message: "Please enter date of exam!",
                                            },
                                        ]}>
                                            <DatePicker format={dateFormat} className="w-100" />
                                        </Form.Item>
                                    </Col>

                                    <Col xs={24} sm={24} md={8}>
                                        <Form.Item name="exact_score" label="Exact Scores">
                                            <Input />
                                        </Form.Item>
                                    </Col>

                                    <Col xs={24} sm={24} md={6}>
                                        <Form.Item name="reading" label="Reading">
                                            <Input />
                                        </Form.Item>
                                    </Col>

                                    <Col xs={24} sm={24} md={6}>
                                        <Form.Item name="writing" label="Writing">
                                            <Input />
                                        </Form.Item>
                                    </Col>

                                    <Col xs={24} sm={24} md={6}>
                                        <Form.Item name="speaking" label="Speaking">
                                            <Input />
                                        </Form.Item>
                                    </Col>

                                    <Col xs={24} sm={24} md={6}>
                                        <Form.Item name="listening" label="Listening">
                                            <Input />
                                        </Form.Item>
                                    </Col>
                                </>
                            }
                        </Row>
                        <Row className="px-lg-5">
                            <Col xs={24} sm={24} md={12}>
                                <Button
                                    className="px-5"
                                    type="primary"
                                    htmlType="submit"
                                    loading={submitLoading}
                                    onClick={() => onFinish()}
                                >
                                    {mode === "ADD" ? "Submit" : `Save`}
                                </Button>
                            </Col>
                        </Row>
                    </Card>
                </div>
            </Form>
        </>
    );
};
export default TestScores;
