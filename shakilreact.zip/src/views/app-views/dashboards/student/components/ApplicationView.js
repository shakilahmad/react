import React, { useState, useEffect } from "react";
import {
  Button,
  message,
  Input,
  Row,
  Col,
  Card,
  Form,
  Select,
  Switch,
  Radio,
  DatePicker,
  Tag,
  Table,
  Avatar,
  Tooltip,
  Tabs,
  Spin,
  Popover,
  Breadcrumb,
} from "antd";
import utils from "utils";

import masterService from "../../../../../services/MasterService";
import leadsService from "../../../../../services/LeadsServices";
import { Link, useNavigate, useParams } from "react-router-dom";
import dayjs from "dayjs";
import DataDisplayWidget from "components/shared-components/DataDisplayWidget";
import { BASE_URL_IMAGE } from "configs/AppConfig";
import style from "react-syntax-highlighter/dist/esm/styles/hljs/a11y-dark";
import AppRequirement from "./AppRequirement";
import UnivesityDocument from "./UniversityDocument";
import { EditOutlined } from "@ant-design/icons";
import GetStatusForm from "./GetStatusForm";
import { useSelector } from "react-redux";
import Credentials from "./Credentials";
import NotificationApp from "./NotificationApp";
import PartnerForm from "./PartnerForm";

const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const ApplicationView = () => {
  //console.log(history)
  //const loginDetail = JSON.parse(useSelector(state => state.auth))
  //console.log(loginDetail)
  const params = useParams();
  const dateFormat = "DD/MM/YYYY";
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [appDetil, setAppDetail] = useState([]);
  const [showLoader, setShowLoader] = useState(true);
  const [showOther, setShowOther] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [showPartnerPopup, setShowPartnerPopup] = useState(false);
  const [btnShowHide, setBtnShowHide] = useState({
    status: 0,
    credlist: 0,
    adddoc: 0,
    partner: 0,
  });
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );

  const listAppData = () => {
    //console.log(params)

    try {
      const reqeustParam = { application_id: params.id };
      const resp = leadsService.applicationDetail(reqeustParam);
      resp
        .then((res) => {
          setAppDetail(res.data.app_detail);
          setShowOther(res.data.app_list);
          loaderShow();
          setShowPopup(false);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    listAppData();

    const statusPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 53
    );
    const credlistPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 98
    );
    const adddocPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 59
    );
    const universityPartnerPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 116
    );

    const notificationPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 94
    );

    setBtnShowHide({
      status: statusPermission.length,
      credlist: credlistPermission.length,
      adddoc: adddocPermission.length,
      notificationlist: notificationPermission.length,
      partner: universityPartnerPermission.length,
    });
  }, [params]);

  const handleFileChange = (event) => {
    // setFilechanges(event.target.files[0]);
  };
  const onFinish = () => {
    setSubmitLoading(true);
    form
      .validateFields()
      .then((values) => {
        setTimeout(() => {
          setSubmitLoading(false);
        }, 1500);
      })
      .catch((info) => {
        setSubmitLoading(false);
        console.log("info", info);
        message.error("Please enter all required field ");
      });
  };

  let i = 1;
  const imgsrc =
    auth_details.profile || `${BASE_URL_IMAGE}/img/avatars/profile.png`;
  const imgsrcnew = `${BASE_URL_IMAGE}/img/color-logo.png`;

  const loaderShow = () => {
    //console.log('ikkkk')
    setShowLoader(false);
  };
  const showStudentDetail = (e) => {
    //console.log(e)
    if (e > 0) {
      navigate(`/dashboards/application-detail/${e}`);
    }
  };

  const handleVisibleChange = () => {
    showPopup === true ? setShowPopup(false) : setShowPopup(true);
  };

  const handleVisiblePartnerChange = () => {
    showPartnerPopup === true
      ? setShowPartnerPopup(false)
      : setShowPartnerPopup(true);
  };
  return (
    <>
      <Spin size="large" spinning={showLoader}>
        <Form
          layout="vertical"
          form={form}
          name="advanced_search"
          className="ant-advanced-search-form"
        >
          <div className="container123">
            <Breadcrumb className="mb-3">
              <Breadcrumb.Item>
                <Button
                  style={{ height: `unset`, padding: `unset`, color: `unset` }}
                  type="link"
                  onClick={() => navigate(`/dashboards/student`)}
                >
                  Student List
                </Button>
              </Breadcrumb.Item>
              <Breadcrumb.Item>
                <Button
                  style={{ height: `unset`, padding: `unset`, color: `unset` }}
                  type="link"
                  onClick={() =>
                    navigate(
                      `/dashboards/student-detail/${appDetil.student?.id}`,
                      { state: { defalutApp: 4 } }
                    )
                  }
                >
                  Student Detail
                </Button>
              </Breadcrumb.Item>
              <Breadcrumb.Item>
                Application Detail / {appDetil.student?.name}
              </Breadcrumb.Item>
            </Breadcrumb>

            <Card title="Show Application">
              <Form.Item label="" name="other">
                <Select
                  defaultValue="Other Application"
                  showSearch
                  onChange={showStudentDetail}
                  placeholder="Select Other"
                  optionFilterProp="children"
                  filterOption={(input, option) =>
                    option.props.children
                      .toLowerCase()
                      .indexOf(input.toLowerCase()) >= 0
                  }
                >
                  <Option value="0" selected>
                    Other Application
                  </Option>
                  {showOther &&
                    showOther.map((showOther, index) => {
                      return (
                        <Option key={`other${index}`} value={showOther.id}>
                          {showOther.college_course?.college.name} -
                          {showOther.college_course?.course.name}
                        </Option>
                      );
                    })}
                </Select>
              </Form.Item>
              <Row gutter={16}>
                <Col xs={24} sm={24} md={10}>
                  <Card>
                    <Row gutter={16}>
                      {/* <Col xs={24} sm={24} md={6}>
                        <Avatar src={imgsrc} />
                      </Col>
                      <Col xs={24} sm={24} md={24}></Col> */}

                      <Col xs={24} sm={24} md={24}>
                        <div className="d-flex mt-2">
                          <Avatar
                            className="mr-2"
                            src={
                              appDetil.college_course?.college.logo || imgsrcnew
                            }
                          />
                          <div>
                            <h4 className="mb-0 pb-0" style={{ color: "blue" }}>
                              {appDetil.college_course?.college.name}
                            </h4>
                            <h5 className="pt-0 mt-0" style={{ color: "blue" }}>
                              {appDetil.college_course?.course.name}
                            </h5>
                          </div>
                        </div>
                        <div className="mt-1">
                          {/* Delivery Method:   <Tag color="green">Blended</Tag><br /> */}
                          Level: {appDetil.college_course?.course.level}
                          <br />
                          {/*Required Lavel: Grad 12/ High School */}
                          Application ID: {appDetil.application_no}
                        </div>
                      </Col>
                    </Row>
                    <hr />
                    <Row gutter={16} className="pt-2">
                      <Col xs={24} sm={24} md={6}>
                        <div>Intake(s)</div>
                      </Col>
                      <Col xs={24} sm={24} md={18}>
                        <div>
                          : {appDetil.intake_month}-{appDetil.intake_year}
                        </div>
                      </Col>
                    </Row>
                    {/* <Row gutter={16}><Col xs={24} sm={24} md={24}><hr /></Col></Row>
                                     <Row gutter={16}>
                                        
                                        <Col xs={24} sm={24} md={6}>
                                            <div>Academics Submission Deadline:</div>
                                        </Col>
                                        <Col xs={24} sm={24} md={18}>
                                            <div>Oct 2, 2023</div>

                                        </Col>

                                    </Row>
                                                */}
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={24}>
                        <hr />
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={6}>
                        <div>Status</div>
                      </Col>
                      <Col xs={24} sm={24} md={18}>
                        <div>
                          : {appDetil.get_status_name}
                          {btnShowHide.status > 0 && (
                            <Popover
                              content={
                                <GetStatusForm
                                  appid={params.id}
                                  listAppData={listAppData}
                                />
                              }
                              title="Status"
                              trigger="click"
                              open={showPopup}
                              onOpenChange={handleVisibleChange}
                            >
                              <Button type="link">
                                <EditOutlined />
                              </Button>
                            </Popover>
                          )}
                        </div>
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={24}>
                        <hr />
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={6}>
                        <div>Student</div>
                      </Col>
                      <Col xs={24} sm={24} md={18}>
                        <div>
                          : {appDetil.student?.student_id} |{" "}
                          {appDetil.student?.name}
                        </div>
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={24}>
                        <hr />
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={6}>
                        <div>Background</div>
                      </Col>
                      <Col xs={24} sm={24} md={18}>
                        <div>
                          : Nationality - {appDetil.student?.nationality}
                        </div>
                        <div>
                          {" "}
                          &nbsp; Residence - {appDetil.student?.residence}
                        </div>
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={24}>
                        <hr />
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={6}>
                        <div>Age</div>
                      </Col>
                      <Col xs={24} sm={24} md={18}>
                        <div>: {appDetil.student?.age} Years</div>
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={24}>
                        <hr />
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={6}>
                        <div>Education</div>
                      </Col>
                      <Col xs={24} sm={24} md={18}>
                        :{" "}
                        {appDetil.student?.high_education?.is_latest && (
                          <>
                            {appDetil.student?.high_education?.high_education} |{" "}
                            {appDetil.student?.high_education?.degree_name} |{" "}
                            {appDetil.student?.high_education?.score}
                          </>
                        )}
                      </Col>
                    </Row>

                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={24}>
                        <hr />
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={6}>
                        <div>English Test Score</div>
                      </Col>
                      <Col xs={24} sm={24} md={18}>
                        <div>
                          : {appDetil.student?.english_exam_type} |{" "}
                          {appDetil.student?.exact_score}
                        </div>
                        <div>
                          R - {appDetil.student?.reading} | W -{" "}
                          {appDetil.student?.writing} | S -{" "}
                          {appDetil.student?.speaking} | L -{" "}
                          {appDetil.student?.listening}
                        </div>
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={24}>
                        <hr />
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={6}>
                        <div>GET Counsellor</div>
                      </Col>
                      <Col xs={24} sm={24} md={18}>
                        <div>: {appDetil.last_update_by}</div>
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={24}>
                        <hr />
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col xs={24} sm={24} md={6}>
                        <div>PP/ Ambassador</div>
                      </Col>
                      <Col xs={24} sm={24} md={18}>
                        <div>: {appDetil.student?.parent.name}</div>
                      </Col>
                    </Row>
                    {btnShowHide.partner > 0 && appDetil.status_id == 2 && (
                      <Row gutter={16}>
                        <Col xs={24} sm={24} md={24}>
                          <hr />
                        </Col>
                        <Col xs={24} sm={24} md={6}>
                          <div className="mt-2">Universities Partner</div>
                        </Col>
                        <Col xs={24} sm={24} md={18}>
                          <div>
                            {appDetil?.university_partner?.name ? (
                              appDetil.university_partner.name
                            ) : (
                              <span></span>
                            )}

                            <Popover
                              content={
                                <PartnerForm
                                  appid={params.id}
                                  listAppData={listAppData}
                                />
                              }
                              title="Partner"
                              trigger="click"
                              open={showPartnerPopup}
                              onOpenChange={handleVisiblePartnerChange}
                            >
                              <Button type="link">
                                <EditOutlined />
                              </Button>
                            </Popover>
                          </div>
                        </Col>
                      </Row>
                    )}
                  </Card>
                </Col>
                <Col xs={24} sm={24} md={14}>
                  <Card>
                    <Tabs
                      defaultActiveKey="1"
                      destroyInactiveTabPane={true}
                      items={[
                        {
                          label: "Student Application Requirement",
                          key: "1",
                          children: <AppRequirement appDetail={appDetil} />,
                        },
                        btnShowHide.adddoc > 0 && {
                          label: "University Documents",
                          key: "2",
                          children: <UnivesityDocument appDetail={appDetil} />,
                        },
                        btnShowHide.credlist > 0 && {
                          label: "Credentials",
                          key: "3",
                          children: <Credentials appDetail={appDetil} />,
                        },

                        btnShowHide.notificationlist > 0 && {
                          label: "Notification",
                          key: "4",
                          children: <NotificationApp appDetail={appDetil} />,
                        },
                      ]}
                    />
                  </Card>
                </Col>
              </Row>
            </Card>
          </div>
        </Form>
      </Spin>
    </>
  );
};

export default ApplicationView;
