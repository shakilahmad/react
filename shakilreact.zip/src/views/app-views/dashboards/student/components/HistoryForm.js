import React, { useState, useEffect } from "react";
import {

    Card,
    Form,
    Select,
    Timeline,

} from "antd";
import utils from 'utils'
import { DeleteOutlined } from '@ant-design/icons';

import masterService from "../../../../../services/MasterService";
import leadsService from "../../../../../services/LeadsServices";
import { useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';
import DataDisplayWidget from "components/shared-components/DataDisplayWidget";
import { BASE_URL_IMAGE } from "configs/AppConfig";
import style from "react-syntax-highlighter/dist/esm/styles/hljs/a11y-dark";
import ApplicationView from "./ApplicationView";
import Flex from "components/shared-components/Flex";
import { useSelector } from "react-redux";
import SettingService from "services/SettingService";

const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const HistoryForm = (props) => {
    const dateFormat = 'DD/MM/YYYY';
    const { mode = ADD, userDetail } = props;
    const navigate = useNavigate();
    const [form] = Form.useForm();
    const [listAll, setListAll] = useState([]);
    const [listCourseAll, setListCourseAll] = useState([]);
    const [record, setrecord] = useState(1);
    const [list, setList] = useState([]);
    const [btnShowHide, setBtnShowHide] = useState({ add: 0, view: 0, delete: 0 });
    const auth_details = JSON.parse(useSelector(state => state.auth.auth_details))

    const listData = (page, pageSize) => {
        const reqeustParam = { page: page, pageSize: pageSize, type_id: userDetail.id};
        try {
            const resp = SettingService.notification(reqeustParam);
            resp
                .then((res) => {
                    setrecord(res.data.total);
                    setList(res.data.data);
                    setListAll(res.data.data);
                })
                .catch((err) => { });
        } catch (errors) {
            console.log(errors);
        }
    };
    const nexPageData = (page, pageSize) => {
        listData(page, pageSize);
    };


    useEffect(() => {
        listData(1, 50)
        const addPermission = auth_details.role_permissions.filter((listPer) => listPer.id === 49)
        const viewPermission = auth_details.role_permissions.filter((listPer) => listPer.id === 52)
        const delPermission = auth_details.role_permissions.filter((listPer) => listPer.id === 51)
        setBtnShowHide({ add: addPermission.length, view: viewPermission.length, delete: delPermission.length })
    }, [form, mode, props]);

    return (
        <>
            <Card title={`History`}>
                <hr />
                <div className="table-responsive mt-3" >
                    <Timeline>
                        {list && list.map((listing,index) => {
                            return (
                                <Timeline.Item>{listing.message} {listing.updated_at} updated by {listing.user_name}</Timeline.Item>
                            )
                        })
                    }
                    </Timeline>
                </div>
            </Card>
        </>
    );
};

export default HistoryForm;
