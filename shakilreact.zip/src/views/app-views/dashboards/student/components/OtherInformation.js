import React, { useState, useEffect } from "react";
import leadsService from "../../../../../services/LeadsServices";
import {
  Button,
  message,
  Input,
  Row,
  Col,
  Card,
  Form,
  Select,
  Switch,
  Radio,
  DatePicker,
} from "antd";

import masterService from "../../../../../services/MasterService";
import { Link, useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';
import DataDisplayWidget from "components/shared-components/DataDisplayWidget";
import { RocketOutlined } from '@ant-design/icons';
import QuestionAnswer from "./QuestionAnswer";

const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const OtherInformation = (props) => {
  //console.log(props)
  const dateFormat = 'DD/MM/YYYY';
  const { mode = ADD, userDetail } = props;
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [countryList, setCountryList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [cityList, setCityList] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [statusShow, setStatusShow] = useState(false);
  const [courseTypeList, setCourseTypeList] = useState([]);
  const[formShow, setFormShow] = useState(true);
  const [courseTypeId, setCourseTypeId] = useState("")

  const listCourseTypeData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getCourseType(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setCourseTypeList(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      //console.log(errors);
    }
  };

  

  useEffect(() => {
    listCourseTypeData()
    //console.log(props.mode)
	if (mode === EDIT) {
           // console.log('is edit')
           // console.log('props', props)
            //const {  id } = userDetail
            //console.log(userDetail)
            /* setStatusShow(userDetail.is_active)
            
            form.setFieldsValue({
              first_name: userDetail.first_name==='undefined'?'':userDetail.first_name,
              last_name: userDetail.last_name==='undefined'?'':userDetail.last_name,
              middle_name: userDetail.middle_name==='undefined'?'':userDetail.middle_name,
              dob: userDetail.dob==='undefined'?'':dayjs(userDetail.dob, dateFormat) ,
              country_id: userDetail.country_id==='undefined'?'':parseInt(userDetail.country_id) ,
              state_id: userDetail.state_id==='undefined' || userDetail.state_id===null?'':parseInt(userDetail.state_id) ,
              city_id: userDetail.city_id==='undefined' || userDetail.city_id===null?'':parseInt(userDetail.city_id) ,
              passport_number: userDetail.passport_number==='undefined'?'':userDetail.passport_number,
              passport_expiry: userDetail.passport_expiry==='undefined'?'':dayjs(userDetail.passport_expiry, dateFormat) ,
              gender: userDetail.gender==='undefined'?'':userDetail.gender,
              email: userDetail.email==='undefined'?'':userDetail.email,
              mobile: userDetail.mobile==='undefined'?'':userDetail.mobile,
              marital_status: userDetail.marital_status==='undefined'?'':userDetail.marital_status,
              citizen_country_id: userDetail.citizen_country_id==='undefined'?'':parseInt(userDetail.citizen_country_id),
              address: userDetail.address==='undefined'?'':userDetail.address,
              zip_code: userDetail.zip_code==='undefined'?'':userDetail.zip_code,
              language: userDetail.language==='undefined'?'':userDetail.language,
              is_active: userDetail.is_active==='undefined'?'':userDetail.is_active
              

              
                        
          });
          */

            
            
            
        }
	
	
	
	
  }, [form, mode, props]);

  const onFinish = async () => {
    setSubmitLoading(true);
    form
      .validateFields()
      .then((values) => {
        setTimeout(() => {
          setSubmitLoading(false);
          
          if (mode === EDIT) {
            //console.log(values)
            const studentId = parseInt(userDetail.id)
			
			let statusname = values.is_active === true ? 1: values.is_active === 1 ? 1 : 0
            /* const data = {...values, is_active:statusname, student_id:studentId}
			const resp = leadsService.personalInformationStudent(data)
			*/
            //console.log(resp);
      //console.log(resp.data);
       /* resp.then(res => {
        //message.success(`Student successfully updated.`);
        //props.showProfile();  
       }).catch(err => {

       }) 
       */    

      
            //navigate(`/dashboards/student`)
			
          }
        }, 1500);
      })
      .catch((info) => {
        setSubmitLoading(false);
        console.log("info", info);
        message.error("Please enter all required field ");
      });
  };

  const statusOnChange = (show) => {
    setStatusShow(show);
  };
  const showForm = (id) => {
    //console.log(id)
    setCourseTypeId(id);
    setFormShow(false)

  }

  return (
    <>
      
        <div className="container123">
          {formShow && 
          <Card title={`Other Information`}>
            <hr />
            <Row className="pt-5 px-lg-5" gutter={16}>
            <Col xs={24} sm={24} md={24}><h3>What do you want to study Abroad? Select an Option</h3></Col>  
            </Row>
            
            <Row className="pt-5 px-lg-5" gutter={16}>
              {courseTypeList && courseTypeList.map((list,index) => {

              return(
              
              <Col xs={24} sm={24} md={8} onClick={() => showForm(list.id)} style={{ cursor:'pointer'}}>
                
                <DataDisplayWidget
                                icon={<RocketOutlined />}
                                value=""
                                title={list.name}
                                color="cyan"
                                vertical={true}
                                avatarSize={55}
                            
                            />
                

                
              </Col>
              )
              })
            }
              

            </Row>

            
          </Card>
}
        {!formShow && 
        <QuestionAnswer mode={props.mode} userDetail={props.userDetail} courseTypeId={courseTypeId} />
}
        </div>
     
    </>
  );
};

export default OtherInformation;
