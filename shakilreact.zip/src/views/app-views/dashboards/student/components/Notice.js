import React, { useState, useEffect } from "react";
import {
    Row,
    Col,
    Card,
    Table,
    Input,
    Button,
    Tooltip,
    Tag,
    Modal,
    Form,
    Switch,
    notification,
    Select,
    Pagination,
    DatePicker,
    Popover,
} from "antd";
import {
    DeleteOutlined,
    SearchOutlined,
    PlusCircleOutlined,
    EditOutlined,
    AimOutlined,
    EyeOutlined
} from "@ant-design/icons";
import Flex from "components/shared-components/Flex";
import { useNavigate } from "react-router-dom";
import utils from "utils";
//import { getCourseType } from '../../../../services/MasterService';
import masterService from "services/MasterService";
import leadsService from "services/LeadsServices";
import { connect, useDispatch, useSelector } from "react-redux";
import dayjs from 'dayjs';
import NoticeStatusForm from "./Noticestatusform";
import { navheaderList, navheaderListAll } from "store/slices/navheaderSlice";
const { Search } = Input;

const AddNewCardForm = ({
    visible,
    onCreate,
    onCancel,
    statusOnChange,
    statusShow,
    initialVal,
    listCourseAll,
    inputChange,
}) => {
    const [form] = Form.useForm();
    const { Option } = Select;
    const dateFormat = 'DD/MM/YYYY';
    //console.log(initialVal)
    form.setFieldsValue({
        description: initialVal.description,
        subject: initialVal.subject,
        email: initialVal.email,
        date: initialVal.date === 'undefined' ? '' : (initialVal.date != '' ? dayjs(initialVal.date,dateFormat) : ''),
        statusName: statusShow,
    });
    return (
        <Modal
            destroyOnClose={true}
            title="Add New Notification"
            open={visible}
            okText="Submit"
            onCancel={onCancel}
            onOk={() => {
                form
                    .validateFields()
                    .then((values) => {
                        form.resetFields();
                        onCreate(values);
                    })
                    .catch((info) => {
                        console.log("Validate Failed:", info);
                    });
            }}
        >
            <Form
                preserve={false}
                form={form}
                name="addCourseType"
                layout="vertical"
                initialValues={{
                    id: initialVal.id,
                    description: initialVal.description,
                    subject: initialVal.subject,
                    email: initialVal.email,
                    date: dayjs(initialVal.date, dateFormat),
                    statusName: statusShow,
                }}
            >
                <Form.Item label="Subject" name="subject"
                    rules={[
                        {
                            required: true,
                            message: "Please enter subject!",
                        },
                    ]}
                >
                    <Input placeholder="Subject" onChange={inputChange("subject")} />
                </Form.Item>
                <Form.Item
                    label="Email"
                    name="email"
                    rules={[
                        {
                            required: true,
                            message: "Please enter email!",
                        },
                    ]}
                >
                    <Input placeholder="Email" onChange={inputChange("email")} />
                </Form.Item>



                <Form.Item label="Date" name="date" rules={[
                    {
                        required: true,
                        message: "Please enter date!",
                    },
                ]}>
                    <DatePicker format={dateFormat} className="w-100" onChange={inputChange("date")} />
                </Form.Item>
                <Form.Item label="Description" name="description"
                    rules={[
                        {
                            required: true,
                            message: "Please enter description!",
                        },
                    ]}
                >
                    <Input placeholder="Description" onChange={inputChange("description")} />
                </Form.Item>

                { /* <Form.Item label="Status" name="statusName">
                    <Switch onChange={statusOnChange} checked={statusShow} />
                </Form.Item>
            */ }
            </Form>
        </Modal>
    );
};
const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
    return (
        <Modal
            destroyOnClose={true}
            title="Notification"
            open={visible}
            okText="OK"
            onCancel={onCancelConfirm}
            onOk={() => {
                onOKConfirm();
            }}
        >
            Are you sure want to delete this item?
        </Modal>
    );
};
const ADD = "ADD";
const EDIT = "EDIT";
const Notice = (props) => {
    const { mode = ADD, userDetail } = props;
    const dateFormat = 'DD/MM/YYYY';
    const [list, setList] = useState([]);
    const [modalVisible, setModalVisible] = useState(false);
    const [statusShow, setStatusShow] = useState(false);
    const [initialVal, setInitialVal] = useState({
        id: "",
        description: "",
        email: "",
        date: "",
        subject: ""

    });
    const [modalVisibleConfirmation, setModalVisibleConfirmation] =
        useState(false);
    const [initialId, setInitialId] = useState(0);
    const [listAll, setListAll] = useState([]);
    const [listCourseAll, setListCourseAll] = useState([]);
    const [record, setrecord] = useState(1);
    const [btnShowHide, setBtnShowHide] = useState({
        add: 0,
        edit: 0,
        delete: 0,
        statusupdate:0
    });
    const navigate = useNavigate()
    const auth_details = JSON.parse(
        useSelector((state) => state.auth.auth_details)
    );

    const dispatch = useDispatch()
  const navheaderlist = useSelector((state) => state.navheaderlist)
  
  const {
    loading,
    showMessage,
    navheaderListAll
  } = props

    const listData = (page, pageSize, search = null) => {
        const reqeustParam = { page: page, pageSize: pageSize, search: search };
        try {
            const resp = leadsService.getNotification(reqeustParam);
            resp
                .then((res) => {
                    setrecord(res.data.total);
                    setList(res.data.data);
                    setListAll(res.data.data);
                })
                .catch((err) => { });
        } catch (errors) {
            console.log(errors);
        }
    };

    const nexPageData = (page, pageSize) => {
        listData(page, pageSize);
    };


    useEffect(() => {
        listData(1, 10);

        const addPermission = auth_details.role_permissions.filter(
            (listPer) => listPer.id === 95
        );
        const editPermission = auth_details.role_permissions.filter(
            (listPer) => listPer.id === 95
        );
        const delPermission = auth_details.role_permissions.filter(
            (listPer) => listPer.id === 96
        );
        setBtnShowHide({
          add: addPermission.length,
          edit: editPermission.length,
          delete: delPermission.length,
          statusupdate:editPermission.length,
        });
        
        
    }, []);

    const updateReload = () => {
        listData(1, 10);
      }

    const tableColumns = [
        {
            title: "Sr. No.",
            render: (_, elm, index) => index + 1,
        },
        {
            title: "Name",
            dataIndex: "name",
            render: (_, elm) => (
                <>
                    {elm.student?.first_name} {elm.student?.middle_name} {elm.student?.last_name}
                </>
            ),

            sorter: (a, b) => utils.antdTableSorter(a, b, "name"),
        },
        {
            title: "Subject",
            dataIndex: "subject",

            sorter: (a, b) => utils.antdTableSorter(a, b, "subject"),
        },
        {
            title: "Description",
            dataIndex: "description",

            sorter: (a, b) => utils.antdTableSorter(a, b, "description"),
        },
        {
            title: "Email",
            dataIndex: "email",

            sorter: (a, b) => utils.antdTableSorter(a, b, "email"),
        },
        {
            title: "Date",
            //dataIndex: "date",
            render: (_, elm) => (
                <>{elm.date}</>
            ),

            sorter: (a, b) => utils.antdTableSorter(a, b, "date"),
        },
        {
            title:"Status",
            dataIndex: "status",
            

            sorter: (a, b) => utils.antdTableSorter(a, b, "status"),
        },

        {
            title: "Action",
            dataIndex: "actions",
            render: (_, elm) => (
                <Flex>
                    { /* btnShowHide.edit > 0 && (
                        <Tooltip title="Edit">
                            <Button
                                type="primary"
                                className="mr-2"
                                icon={<EditOutlined />}
                                onClick={() => {
                                    showEditVaue(elm);
                                }}
                                size="small"
                            />
                        </Tooltip>
                            ) */ }

                            <Tooltip title="View">
                            <Button
                                type="primary"
                                className="bg-warning mr-1"
                                icon={<EyeOutlined />}
                                onClick={() => {
                                    showView(elm);
                                }}
                                size="small"
                            />
                        </Tooltip>

                            {btnShowHide.statusupdate > 0 && (
            <Popover content={<NoticeStatusForm appid={elm.id} updateReload={updateReload} />} title="Status" trigger="click">
              <Button type="primary" className="bg-primary mr-1" size="small" icon={<AimOutlined />} />
            </Popover>
          )}
                    {btnShowHide.delete > 0 && (
                        <Tooltip title="Delete">
                            <Button
                                danger
                                icon={<DeleteOutlined />}
                                onClick={() => {
                                    deleteCourse(elm.id);
                                }}
                                size="small"
                            />
                        </Tooltip>
                    )}
                </Flex>
            ),
        },
    ];

    const onSearch = (e) => {
        //console.log(e.currentTarget.value);
        /* const value = e.currentTarget.value;
        const searchArray = e.currentTarget.value ? listAll : listAll;
        const data = utils.wildCardSearch(searchArray, value);
        //setList(data);
        */
        listData(1, 10, e);
    };

    const showModal = () => {
        setModalVisible(true);
    };

    const closeModal = () => {
        setInitialVal({
            id: "",
            description: "",
            email: "",
            date: "",
            subject: ""

        });
        setModalVisible(false);
        setStatusShow(false);
    };

    const statusOnChange = (show) => {
        setStatusShow(show);
    };

    const addCourseType = (values) => {
        let dayyear = dayjs(values.date).year();
        let daymonth = dayjs(values.date).month() + 1;
        let daydate = dayjs(values.date).date();
        let daytm = `${dayyear}-${daymonth}-${daydate}`
        
        let coursetype = values.statusName === true ? 1 : 0;

        //console.log(initialVal);
        if (initialVal.id > 0) {
            const reqeustParam = {
                notification_id: initialVal.id,
                student_id: userDetail.id,
                description: values.description,
                email: values.email,
                date: daytm,
                subject: values.subject,

            };
            
            const resp = leadsService.editNotification(reqeustParam);
            resp
                .then((res) => {
                    if (res.status === 200) {
                        listData();
                    }
                    notification.success({ message: "Notification updated successfully." });
                    setInitialVal({
                        id: "",
                        description: "",
                        email: "",
                        date: "",
                        subject: ""

                    });
                    setStatusShow(false);
                    setModalVisible(false);
                })
                .catch((err) => { });
        } else {
            const reqeustParam = {
                student_id: userDetail.id,
                description: values.description,
                email: values.email,
                date: values.date,
                subject: values.subject,

            };
           
            const resp = leadsService.addNotification(reqeustParam);
            resp
                .then((res) => {
                    if (res.status === 200) {
                        listData();
                    }

                    notification.success({ message: "Notification added successfully." });
                    setInitialVal({
                        id: "",
                        description: "",
                        email: "",
                        date: "",
                        subject: ""

                    });
                    setStatusShow(false);
                    setModalVisible(false);
                })
                .catch((err) => { });
        }

    };
    const showEditVaue = (elm) => {
        //console.log(elm)

        let statustype = elm.is_active === 1 ? true : false;
        setInitialVal({
            id: elm.id,
            description: elm.description,
            email: elm.email,
            date: dayjs(elm.date, dateFormat),
            subject: elm.subject

        });
        setStatusShow(statustype);
        showModal();
    };
    const deleteCourse = (elm) => {
        //console.log(elm)
        setInitialId(elm);
        setModalVisibleConfirmation(true);
    };
    const onCancelConfirm = () => {
        setInitialId(0);
        setModalVisibleConfirmation(false);
    };

    const onOKConfirm = () => {
        const reqeustParam = { notification_id: initialId };
        //console.log(initialId)
        const resp = leadsService.deleteNotification(reqeustParam);
        resp
            .then((res) => {
                if (res.status === 200) {
                    setModalVisibleConfirmation(false);
                    listData();
                    navheaderListAll()
                    notification.success({ message: "Notification deleted successfully." });
                }
            })
            .catch((err) => { });
    };

    const inputChange = (name) => (e) => {

        
        let value;
        name === "description" || name === "email" || name === "subject"
            ? (value = e.target.value)
            : (value = e);
            
        setInitialVal({ ...initialVal, [name]: value });
    };
    const showView = (values) => {
        //console.log(values)
        /* if (values.type == 'APPLICATION' || values.type == 'APPLICATION_STATUS') {
            navigate(`/dashboards/application-detail/${values.type_id}`, { state: { defalutApp: 1 } });
        } else if (values.type == 'LEADS') {
          navigate(`/dashboards/student-detail/${values.type_id}`, { state: { defalutApp: 1 } });  
        }
        */
       if(values.application_id > 0){
        navigate(`/dashboards/application-detail/${values.application_id}`);
       } else {

        navigate(`/dashboards/student-detail/${values.student.id}`);
       }

    }

    return (
        <Card title="Notification">
            <Row gutter={16} className="justify-content-between">
                <Col className="text-end mb-2" xs={24} sm={24} md={18}>
                    { /* btnShowHide.add > 0 && (
                        <Button
                            onClick={showModal}
                            type="primary"
                            icon={<PlusCircleOutlined />}
                        >
                            Add Notification
                        </Button>
                    ) */ }
                    
                </Col>
                <Col className="text-end mb-2" xs={24} sm={24} md={6}>
                 { /* <Search
              placeholder="Search"
              enterButton={<SearchOutlined />}
              onSearch={(e) => onSearch(e)}
              allowClear
            />
                */ }
                    
          
                </Col>
            </Row>
            <AddNewCardForm
                visible={modalVisible}
                onCreate={addCourseType}
                onCancel={closeModal}
                statusOnChange={statusOnChange}
                statusShow={statusShow}
                initialVal={initialVal}
                listCourseAll={listCourseAll}
                inputChange={inputChange}
            />
            <ConfirmationBox
                id={initialId}
                visible={modalVisibleConfirmation}
                onOKConfirm={onOKConfirm}
                onCancelConfirm={onCancelConfirm}
            />
            <div className="table-responsive">
                <Table
                    columns={tableColumns}
                    dataSource={list}
                    rowKey="id"
                    pagination={false}
                />
                <div className="text-right mt-3">
                    <Pagination
                        defaultCurrent={1}
                        total={record}
                        onChange={nexPageData}
                        defaultPageSize={10}
                        hideOnSinglePage
                        pageSizeOptions={[10, 50, 100, 500]}
                    />
                </div>
            </div>
        </Card>
    );
};

const mapStateToProps = ({ navheaderlist }) => {
    const { loading, message, list } = navheaderlist;
    return { loading, message, list }
  }
  
  const mapDispatchToProps = {
    navheaderListAll
  
  }
  
  export default connect(mapStateToProps, mapDispatchToProps)(Notice);
//export default Notice;