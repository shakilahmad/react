import React, { useState, useEffect } from "react";
import {
    Button,
    message,
    Form,
    Select,
    Input
} from "antd";
import masterService from "services/MasterService";
import leadsService from "services/LeadsServices";
import { navheaderList, navheaderListAll } from "store/slices/navheaderSlice";
import { connect, useDispatch, useSelector } from "react-redux";

const { Option } = Select;

const NoticeStatusForm = (props) => {
    //console.log(props)
    const [form] = Form.useForm();
    const [showStaus, setShowStatus] = useState([])
    const [submitLoading, setSubmitLoading] = useState(false);
    
    const dispatch = useDispatch()
  const navheaderlist = useSelector((state) => state.navheaderlist)
  
  const {
    loading,
    showMessage,
    navheaderListAll
  } = props

    useEffect(() => {

       

    }, [])

    const onFinish = () => {
        setSubmitLoading(true);
        form
            .validateFields()
            .then((values) => {
                setTimeout(() => {
                    setSubmitLoading(false);

                    //console.log(values)
                    const data = { notification_id: props.appid, status: values.status }
                    const resp = leadsService.noticeStatus(data);
                    resp.then(res => {
                        //console.log(res);
                        const resp = leadsService.noticeRead({notification_id:props.appid});
                        resp
                        .then((res) => {
                            navheaderListAll()
                        })
                        .catch((err) => {});
                        
                        props.updateReload();

                    })



                }, 1500);
            })
            .catch((info) => {
                setSubmitLoading(false);
                console.log("info", info);
                message.error("Please enter all required field ");
            });
    };



    return (
        <>
            <Form
                layout="vertical"
                form={form}
                name="advanced_search"
                className="ant-advanced-search-form"
            >

                <Form.Item
                    label=""
                    name="status"
                    rules={[
                        {
                            required: true,
                            message: "Please select status!",
                        },
                    ]}
                >
                    <Select
                        showSearch
                        placeholder="Select Status"
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                            option.props.children
                                .toLowerCase()
                                .indexOf(input.toLowerCase()) >= 0
                        }
                    >

                        
                                return (
                                    <Option
                                        key={`country1`}
                                        value="Due for Action"
                                    >
                                        Due for Action
                                    </Option>
                                    <Option
                                        key={`country2`}
                                        value="Complete"
                                    >
                                        Complete
                                    </Option>
                                );
                            

                    </Select>
                </Form.Item>
                

                <Button
                    className=""
                    type="primary"
                    htmlType="submit"
                    loading={submitLoading}
                    onClick={() => onFinish()}
                >
                    {`Save`}
                </Button>

            </Form>


        </>

    )

}
const mapStateToProps = ({ navheaderlist }) => {
    const { loading, message, list } = navheaderlist;
    return { loading, message, list }
  }
  
  const mapDispatchToProps = {
    navheaderListAll
  
  }
  
  export default connect(mapStateToProps, mapDispatchToProps)(NoticeStatusForm);

//export default NoticeStatusForm;