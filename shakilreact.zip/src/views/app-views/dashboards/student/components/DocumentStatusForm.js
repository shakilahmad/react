import React, { useState, useEffect } from "react";
import {
    Button,
    message,
    Form,
    Select
} from "antd";
import masterService from "../../../../../services/MasterService";
import leadsService from "../../../../../services/LeadsServices";




const { Option } = Select;

const DocumentStatusForm = (props) => {
    //console.log(props)
    const [form] = Form.useForm();
    const [showStaus, setShowStatus] = useState([])
    const [submitLoading, setSubmitLoading] = useState(false);
    const shortlistData = () => {
        //const reqeustParam = { is_active: 1 }
        try {

            //const studentId = parseInt(userDetail.id)
            const reqeustParam = { is_active: 1 }
            const resp = masterService.getGETStatus(reqeustParam);


            resp.then(res => {
                //console.log(res)
                setShowStatus(res.data)



            })
                .catch(err => {

                })

        } catch (errors) {
            console.log(errors)
        }
    }


    useEffect(() => {

        shortlistData();

    }, [props, form])

    const onFinish = () => {
        setSubmitLoading(true);
        form
            .validateFields()
            .then((values) => {
                setTimeout(() => {
                    setSubmitLoading(false);

                    //console.log(values)
                    const data = { student_document_id: props.appid, status: values.status, student_id:props.studentId }
                    //console.log(data)
                    const resp = leadsService.documentsStudentStatus(data);
                    resp.then(res => {
                        //console.log(res);
                        props.updateReload();

                    })



                }, 1500);
            })
            .catch((info) => {
                setSubmitLoading(false);
                console.log("info", info);
                message.error("Please enter all required field ");
            });
    };



    return (
        <>
            <Form
                layout="vertical"
                form={form}
                name="advanced_search"
                className="ant-advanced-search-form"
            >

                <Form.Item
                    label=""
                    name="status"
                    rules={[
                        {
                            required: false,
                            message: "Please select status!",
                        },
                    ]}
                >
                    <Select
                        showSearch
                        placeholder="Select Status"
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                            option.props.children
                                .toLowerCase()
                                .indexOf(input.toLowerCase()) >= 0
                        }
                    >

                        <Option
                            key={`status`}
                            value="Approved"
                        >
                            Approved
                        </Option>
                        <Option
                            key={`status1`}
                            value="Reupload"
                        >
                            Reupload
                        </Option>

                    </Select>
                </Form.Item>

                <Button
                    className=""
                    type="primary"
                    htmlType="submit"
                    loading={submitLoading}
                    onClick={() => onFinish()}
                >
                    {`Save`}
                </Button>

            </Form>


        </>

    )

}
export default DocumentStatusForm;