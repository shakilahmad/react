import React, { useState, useEffect } from "react";
import { Button, message, Form, Select } from "antd";
import masterService from "../../../../../services/MasterService";

const { Option } = Select;

const PartnerForm = (props) => {
  const [form] = Form.useForm();
  const [showStatus, setShowStatus] = useState([]);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [popoverVisible, setPopoverVisible] = useState(true); // Local state for popover visibility

  const shortlistData = () => {
    try {
      const requestParam = { is_active: 1 };
      const resp = masterService.getPartners(requestParam);

      resp
        .then((res) => {
          setShowStatus(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    shortlistData();
  }, [props, form]);

  const onFinish = () => {
    setSubmitLoading(true);
    form
      .validateFields()
      .then((values) => {
        setTimeout(() => {
          setSubmitLoading(false);
          const data = {
            application_id: props.appid,
            university_partner_id: values.name,
          };
          const resp = masterService.partnerGetName(data);
          resp
            .then((res) => {
              props.listAppData();
              message.success("Data saved successfully");
              setPopoverVisible(false); // Close the popover
            })
            .catch((error) => {
              message.error("Failed to save data");
            });
        }, 1500);
      })
      .catch((error) => {
        setSubmitLoading(false);
        message.error("Please enter all required fields");
      });
  };

  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
        style={{ width: "275px" }}
      >
        <Form.Item
          label=""
          name="name"
          rules={[
            {
              required: true,
              message: "Please select name!",
            },
          ]}
        >
          <Select
            showSearch
            placeholder="Select Universities Partner name"
            optionFilterProp="children"
            filterOption={(input, option) =>
              option.props.children
                .toLowerCase()
                .indexOf(input.toLowerCase()) >= 0
            }
          >
            {showStatus &&
              showStatus.map((showStatus, index) => (
                <Option key={`country${index}`} value={showStatus.id}>
                  {showStatus.name}
                </Option>
              ))}
          </Select>
        </Form.Item>

        <Button
          className=""
          type="primary"
          htmlType="submit"
          loading={submitLoading}
          onClick={onFinish}
        >
          Save
        </Button>
      </Form>
    </>
  );
};

export default PartnerForm;
