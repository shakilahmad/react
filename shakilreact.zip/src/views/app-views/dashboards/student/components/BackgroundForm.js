import React, { useState, useEffect } from "react";
import leadsService from "../../../../../services/LeadsServices";
import {
    Button,
    message,
    Input,
    Row,
    Col,
    Card,
    Form,
    Select,
    Switch,
    Radio,
    DatePicker,
} from "antd";

import masterService from "../../../../../services/MasterService";
import { useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';


const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const BackgroundForm = (props) => {
    const dateFormat = 'DD/MM/YYYY';
    const { mode = ADD, userDetail } = props;
    const navigate = useNavigate();
    const [form] = Form.useForm();
    const [submitLoading, setSubmitLoading] = useState(false);
    const [countryList, setCountryList] = useState([]);
    const [show, setShow] = useState(false)

    const listCountryData = () => {
        const reqeustParam = {};
        try {
            const resp = masterService.getCountry(reqeustParam);
            resp
                .then((res) => {
                    //console.log(res.data)
                    setCountryList(res.data);
                })
                .catch((err) => { });
        } catch (errors) {
            console.log(errors);
        }
    };



    useEffect(() => {
        listCountryData();


        if (mode === EDIT) {
            // console.log('is edit')
            //console.log('props', props)

            // const studentId = parseInt(userDetail.id)

            //statusOnChange(res.data.is_active)
            //setShowImage(res.data.logo)
            //showValue(userDetail.background_info)
            userDetail.background_info === 'Yes' ? setShow(true) : setShow(false);


            form.setFieldsValue({
                background_info: userDetail.background_info === 'undefined' ? '' : userDetail.background_info,
                background_country_id: userDetail.background_country_id === 'undefined' || userDetail.background_country_id === null ? '' : parseInt(userDetail.background_country_id),
                emergency_email: userDetail.emergency_email === 'undefined' ? '' : userDetail.emergency_email,
                emergency_name: userDetail.emergency_name === 'undefined' ? '' : userDetail.emergency_name,
                emergency_relation: userDetail.emergency_relation === 'undefined' ? '' : userDetail.emergency_relation,
                emergency_contact: userDetail.emergency_contact === 'undefined' ? '' : userDetail.emergency_contact,



            });





        }




    }, [form, mode, props]);

    const onFinish = () => {
        setSubmitLoading(true);
        form
            .validateFields()
            .then((values) => {
                setTimeout(() => {
                    setSubmitLoading(false);
                    if (mode === ADD) {
                        //console.log(values)


                        //navigate(`/dashboards/student`)



                    }
                    if (mode === EDIT) {
                        //console.log(values)

                        const studentId = parseInt(userDetail.id)
                        let emergency_email = values.emergency_email == undefined ? '' : values.emergency_email;
                        let emergency_name = values.emergency_name == undefined ? '' : values.emergency_name;
                        let emergency_relation = values.emergency_relation == undefined ? '' : values.emergency_relation;
                        let emergency_contact = values.emergency_contact == undefined ? '' : values.emergency_contact;


                        //let statusname = values.is_active === true ? 1 : values.is_active === 1 ? 1 : 0
                        const data = { ...values, student_id: studentId, emergency_email:emergency_email, emergency_name:emergency_name, emergency_relation:emergency_relation, emergency_contact:emergency_contact }
                        leadsService.backgroundInfoStudent(data)
                        message.success(`Background info successfully updated.`);
                        //navigate(`/dashboards/student`)

                    }
                }, 1500);
            })
            .catch((info) => {
                setSubmitLoading(false);
                console.log("info", info);
                message.error("Please enter all required field ");
            });
    };



    const showValue = (e) => {

        if (e.target.value === "Yes") {
            setShow(true)
        } else {
            setShow(false)
        }
    }

    return (
        <>
            <Form
                layout="vertical"
                form={form}
                name="advanced_search"
                className="ant-advanced-search-form"
            >
                <div className="container123">
                    <Card title={`Background Information`}>
                        <hr />
                        <Row className="pt-5 px-lg-5" gutter={16}>

                            <Col xs={24} sm={24} md={8}>
                                <Form.Item name="background_info" label="Have you been refused a visa from Canada, the USA, the United Kingdom, New Zealand, Australia or Ireland?" rules={[
                                    {
                                        required: true,
                                        message: "Please select",
                                    },
                                ]}>
                                    <Radio.Group onChange={showValue}>
                                        <Radio value="Yes">Yes</Radio>
                                        <Radio value="No">No</Radio>
                                    </Radio.Group>
                                </Form.Item>
                            </Col>

                            {show &&
                                <>
                                    <Col xs={24} sm={24} md={8}>
                                        <Form.Item
                                            label="Country"
                                            name="background_country_id"
                                            rules={[
                                                {
                                                    required: false,
                                                    message: "Please select country!",
                                                },
                                            ]}
                                        >
                                            <Select
                                                showSearch
                                                placeholder="Select Country"
                                                optionFilterProp="children"
                                                filterOption={(input, option) =>
                                                    option.props.children
                                                        .toLowerCase()
                                                        .indexOf(input.toLowerCase()) >= 0
                                                }
                                            >
                                                {countryList &&
                                                    countryList.map((countrylist, index) => {
                                                        return (
                                                            <Option
                                                                key={`country${index}`}
                                                                value={countrylist.id}
                                                            >
                                                                {countrylist.name}
                                                            </Option>
                                                        );
                                                    })}
                                            </Select>
                                        </Form.Item>
                                    </Col>
                                </>
                            }


                        </Row>
                        <Row className="pt-1 px-lg-5" gutter={16}>

                            <Col className="h5" xs={24} sm={24} md={24}><strong>Emergency Contact</strong></Col>
                           
                        </Row>
                        <Row className=" px-lg-5" gutter={16}>    
                            <Col xs={24} sm={24} md={6}>
                            <Form.Item
                            name="emergency_name"
                            label="Name"
                            rules={[
                                {
                                required: false,
                                message: "Please enter name!",
                                },
                            ]}
                            >
                            <Input />
                            </Form.Item>
                            </Col>
                            <Col xs={24} sm={24} md={6}>
                            <Form.Item
                            name="emergency_relation"
                            label="Relation"
                            rules={[
                                {
                                required: false,
                                message: "Please enter relation!",
                                },
                            ]}
                            >
                            <Input />
                            </Form.Item>
                            </Col>
                            <Col xs={24} sm={24} md={6}>
                            <Form.Item
                            name="emergency_email"
                            label="Email"
                            rules={[
                                {
                                required: false,
                                type: "email",
                                message: "Please enter valid email!",
                                },
                            ]}
                            >
                            <Input />
                            </Form.Item>
                            </Col>
                            <Col xs={24} sm={24} md={6}>
                            <Form.Item
                            name="emergency_contact"
                            label="Contact"
                            rules={[
                                {
                                required: false,
                                message: "Please enter contact!",
                                },
                            ]}
                            >
                            <Input />
                            </Form.Item>
                            </Col>
                        </Row>

                        <Row className="px-lg-5">
                            <Col xs={24} sm={24} md={12}>
                                <Button
                                    className="px-5"
                                    type="primary"
                                    htmlType="submit"
                                    loading={submitLoading}
                                    onClick={() => onFinish()}
                                >
                                    {mode === "ADD" ? "Submit" : `Save`}
                                </Button>
                            </Col>
                        </Row>
                    </Card>
                </div>
            </Form>
        </>
    );
};

export default BackgroundForm;
