import React, { useState, useEffect } from "react";
import leadsService from "../../../../../services/LeadsServices";
import {
  Button,
  message,
  Input,
  Row,
  Col,
  Card,
  Form,
  Select,
  Switch,
  Radio,
  DatePicker,
} from "antd";

import masterService from "../../../../../services/MasterService";
import { useNavigate } from "react-router-dom";
import dayjs from "dayjs";
import { useSelector } from "react-redux";

const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const AddStudent = (props) => {
  //console.log(props)
  const dateFormat = "DD/MM/YYYY";
  const { mode = ADD, userDetail } = props;
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [countryList, setCountryList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [cityList, setCityList] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [statusShow, setStatusShow] = useState(false);
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );

  const listCountryData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getCountry(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setCountryList(res.data);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };

  const listStateData = (e = '') => {

    const country_id = e != '' ? e : userDetail.country_id
    const reqeustParam = { country_id: country_id };
    try {
      const resp = masterService.getState(reqeustParam);
      resp
        .then((res) => {
          setStateList(res.data);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };
  const listCityData = (e = '') => {
    const state_id = e != '' ? e : userDetail.state_id
    const reqeustParam = { state_id: state_id };
    try {
      const resp = masterService.getCity(reqeustParam);
      resp
        .then((res) => {
          setCityList(res.data);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };

  const listStatusesData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getStatus(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setStatuses(res.data);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    //console.log('form')
    listCountryData();
    listStatusesData();
    listStateData();
    listCityData();

    if (mode === EDIT) {
      setStatusShow(userDetail.is_active);
      //console.log(userDetail);
      form.setFieldsValue({
        first_name: userDetail.first_name === "undefined" ? "" : userDetail.first_name,
        last_name: userDetail.last_name === "undefined" ? "" : userDetail.last_name,
        middle_name: userDetail.middle_name === "undefined" ? "" : userDetail.middle_name,
        dob: userDetail.dob === "undefined" ? "" : userDetail.dob != '' ? dayjs(userDetail.dob, dateFormat) : '',
        country_id: userDetail.country_id === "undefined" || userDetail.country_id === null ? '' : parseInt(userDetail.country_id),
        state_id: userDetail.state_id === "undefined" || userDetail.state_id === null ? "" : parseInt(userDetail.state_id),
        city_id: userDetail.city_id === "undefined" || userDetail.city_id === null ? "" : parseInt(userDetail.city_id),
        passport_number: userDetail.passport_number === "undefined" ? "" : userDetail.passport_number,
        passport_expiry: userDetail.passport_expiry === "undefined" ? '' : userDetail.passport_expiry != '' ? dayjs(userDetail.passport_expiry, dateFormat) : '',
        gender: userDetail.gender === "undefined" ? "" : userDetail.gender,
        email: userDetail.email === "undefined" ? "" : userDetail.email,
        email2: userDetail.email2 === "undefined" ? "" : userDetail.email2,
        mobile: userDetail.mobile === "undefined" ? "" : userDetail.mobile,
        marital_status: userDetail.marital_status === "undefined" ? "" : userDetail.marital_status,
        citizen_country_id: userDetail.citizen_country_id === "undefined" || userDetail.citizen_country_id === null ? "" : parseInt(userDetail.citizen_country_id),
        address: userDetail.address === "undefined" ? "" : userDetail.address,
        zip_code: userDetail.zip_code === "undefined" ? "" : userDetail.zip_code,
        language: userDetail.language === "undefined" ? "" : userDetail.language,
        is_active: userDetail.is_active === "undefined" ? "" : userDetail.is_active,
        mobile: userDetail.mobile === "undefined" ? "" : userDetail.mobile,
        
      });
    }
  }, [form, mode, props]);

  useEffect(() => {
    setTimeout(() => {
      props.loaderShow();
    }, 5000);
  }, []);

  const onFinish = async () => {
    setSubmitLoading(true);
    form
      .validateFields()
      .then((values) => {
        setTimeout(() => {
          setSubmitLoading(false);
          if (mode === ADD) {
            //console.log(values)

            let statusname =
              values.is_active === true ? 1 : values.is_active === 1 ? 1 : 0;
            const data = { ...values, is_active: statusname };
          }
          if (mode === EDIT) {
            //console.log(values)
            let dayyear = dayjs(values.dob).year();
            let daymonth = dayjs(values.dob).month() + 1;
            let daydate = dayjs(values.dob).date();
            let daytm = `${dayyear}-${daymonth}-${daydate}`
           
            let daytmpassport_expiry
            if(values.passport_expiry){
            let daypassport_expiry = dayjs(values.passport_expiry).year();
            let daymonthpassport_expiry = dayjs(values.passport_expiry).month() + 1;
            let daydatepassport_expiry = dayjs(values.passport_expiry).date();
            daytmpassport_expiry = `${daypassport_expiry}-${daymonthpassport_expiry}-${daydatepassport_expiry}`
            }
            

            const studentId = parseInt(userDetail.id);

            let statusname =
              values.is_active === true ? 1 : values.is_active === 1 ? 1 : 0;
            const data = {
              ...values,
              is_active: statusname,
              student_id: studentId,
              dob:daytm,
              passport_expiry:daytmpassport_expiry

            };
            const resp = leadsService.personalInformationStudent(data);
            resp
              .then((res) => {
                message.success(`Student successfully updated.`);
                props.showProfile();
              })
              .catch((err) => { });
               
          }
        }, 1500);
      })
      .catch((info) => {
        setSubmitLoading(false);
        console.log("info", info);
        message.error("Please enter all required field ");
      });
  };

  const statusOnChange = (show) => {
    setStatusShow(show);
  };

  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
      >
        <div className="pb-5">
          <h4 className="p-3 pb-0">Personal Information</h4>
          <div className="border-lg px-2">
            <Row className="pt-4 px-lg-5" gutter={16}>
              <Col xs={24} sm={24} md={8}>
                <Form.Item
                  name="first_name"
                  label="First Name"
                  rules={[
                    {
                      required: true,
                      message: "Please enter first name!",
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={8}>
                <Form.Item
                  name="last_name"
                  label="Last Name"
                  rules={[
                    {
                      required: true,
                      message: "Please enter last name!",
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={8}>
                <Form.Item name="middle_name" label="Middel Name">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={8}>
                <Form.Item
                  name="dob"
                  label="Date of Birth"
                  rules={[
                    {
                      required: true,
                      message: "Please enter date of birth!",
                    },
                  ]}
                >
                  <DatePicker format={dateFormat} className="w-100" />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={8}>
                <Form.Item name="language" label="First Language">
                  <Input />
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={8}>
                <Form.Item
                  label="Country of Citizenship"
                  name="citizen_country_id"
                  rules={[
                    {
                      required: true,
                      message: "Please select country!",
                    },
                  ]}
                >
                  <Select
                    showSearch
                    placeholder="Select Country"
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                      option.props.children
                        .toLowerCase()
                        .indexOf(input.toLowerCase()) >= 0
                    }
                  >
                    {countryList &&
                      countryList.map((countrylist, index) => {
                        return (
                          <Option
                            key={`country${index}`}
                            value={countrylist.id}
                          >
                            {countrylist.name}
                          </Option>
                        );
                      })}
                  </Select>
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={8}>
                <Form.Item name="passport_number" label="Passport Number">
                  <Input />
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={8}>
                <Form.Item
                  name="passport_expiry"
                  label="Passport Expiry Date"
                  rules={[
                    {
                      required: false,
                      message: "Please enter passport expiry date!",
                    },
                  ]}
                >
                  <DatePicker format={dateFormat} className="w-100" />
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={8}>
                <Row gutter={16}>
                <Col xs={24} sm={24} md={12}>
                <Form.Item name="marital_status" label="Marital Status">
                  <Radio.Group>
                    <Radio value="Single">Single</Radio>
                    <Radio value="Married">Married</Radio>
                  </Radio.Group>
                </Form.Item>
                  </Col>
                  <Col xs={24} sm={24} md={12}>
                  <Form.Item name="gender" label="Gender">
                  <Radio.Group>
                    <Radio value="Male">Male</Radio>
                    <Radio value="Female">Female</Radio>
                  </Radio.Group>
                </Form.Item>
                  </Col>
                </Row>
              
              </Col>
              {/* <Col xs={24} sm={24} md={8}>
                
              </Col> */}
              <Col xs={24} sm={24} md={8}>
                <Form.Item
                  name="email"
                  label="Email "
                  rules={[
                    {
                      required: false,
                      message: "Please enter email !",
                    },
                    {
                      type: 'email',
                      message: 'The input is not valid E-mail!',
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={8}>
                <Form.Item
                  name="email2"
                  label="Email 2"
                  rules={[
                    {
                      required: false,
                      message: "Please enter email 2!",
                    },
                    {
                      type: 'email',
                      message: 'The input is not valid E-mail!',
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={8}>
                <Form.Item
                  name="mobile"
                  label="Mobile No."
                  rules={[
                    {
                      required: true,
                      message: "Please enter mobile no.!",
                    },
                    
                  ]}
                >
                  <Input />
                </Form.Item>
              </Col> 



              <Col className="pb-4" xs={24} sm={24} md={24}>
                <h4>Address Detail</h4>
              </Col>

              <Col xs={24} sm={24} md={8}>
                <Form.Item name="address" label="Address">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={8}>
                <Form.Item
                  label="Country"
                  name="country_id"
                  rules={[
                    {
                      required: true,
                      message: "Please select country!",
                    },
                  ]}
                >
                  <Select
                    showSearch
                    placeholder="Select Country"
                    optionFilterProp="children"
                    onChange={(e) => listStateData(e)}
                    filterOption={(input, option) =>
                      option.props.children
                        .toLowerCase()
                        .indexOf(input.toLowerCase()) >= 0
                    }
                  >
                    {countryList &&
                      countryList.map((countrylist, index) => {
                        return (
                          <Option
                            key={`country${index}`}
                            value={countrylist.id}
                          >
                            {countrylist.name}
                          </Option>
                        );
                      })}
                  </Select>
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={8}>
                <Form.Item
                  label="Province/State"
                  name="state_id"
                  rules={[
                    {
                      required: true,
                      message: "Please select state!",
                    },
                  ]}
                >
                  <Select
                    showSearch
                    onChange={(e) => listCityData(e)}
                    placeholder="Select State"
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                      option.props.children
                        .toLowerCase()
                        .indexOf(input.toLowerCase()) >= 0
                    }
                  >
                    {stateList &&
                      stateList.map((stateList, index) => {
                        return (
                          <Option key={`state${index}`} value={stateList.id}>
                            {stateList.name}
                          </Option>
                        );
                      })}
                  </Select>
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={8}>
                <Form.Item
                  label="City/Town"
                  name="city_id"
                  rules={[
                    {
                      required: true,
                      message: "Please select city!",
                    },
                  ]}
                >
                  <Select
                    showSearch
                    placeholder="Select City"
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                      option.props.children
                        .toLowerCase()
                        .indexOf(input.toLowerCase()) >= 0
                    }
                  >
                    {cityList &&
                      cityList.map((cityList, index) => {
                        return (
                          <Option key={`city${index}`} value={cityList.id}>
                            {cityList.name}
                          </Option>
                        );
                      })}
                  </Select>
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={8}>
                <Form.Item name="zip_code" label="Postal/ZIP Code">
                  <Input />
                </Form.Item>
              </Col>
              {auth_details.user_type == 'student' ? '' :
                <Col xs={24} sm={24} md={8}>
                  <Form.Item name="is_active" label="Status">
                    <Switch onChange={statusOnChange} checked={statusShow} />
                  </Form.Item>
                </Col>
              }
            </Row>

            <Row className="px-lg-5">
              <Col xs={24} sm={24} md={12}>
                <Button
                  className="px-5"
                  type="primary"
                  htmlType="submit"
                  loading={submitLoading}
                  onClick={() => onFinish()}
                >
                  {mode === "ADD" ? "Submit" : `Save`}
                </Button>
              </Col>
            </Row>
          </div>
        </div>
      </Form>
    </>
  );
};

export default AddStudent;
