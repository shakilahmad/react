import React, { useState, useEffect } from "react";
import leadsService from "services/LeadsServices";
import {
  Button,
  message,
  Input,
  Row,
  Col,
  Card,
  Form,
  Select,
  Switch,
  Radio,
  DatePicker,
  Tag,
  Table,
  Avatar,
  Tooltip,
  notification,
  Modal,
  Popover,
  Upload,
} from "antd";
import utils from "utils";
import masterService from "../../../../../services/MasterService";
import { Link, useNavigate } from "react-router-dom";
import dayjs from "dayjs";
import {
  CheckOutlined,
  UploadOutlined,
  DownloadOutlined,
  EyeOutlined,
  DeleteOutlined,
  PlusCircleOutlined,
  CloseOutlined,
  CloudUploadOutlined,
  PlusOutlined,
  MinusCircleOutlined,
  EditOutlined,
  AimOutlined
} from "@ant-design/icons";
import DataDisplayWidget from "components/shared-components/DataDisplayWidget";
import UploadFile from "./UploadFile";
import DocumentStatusForm from "./DocumentStatusForm";
import { connect, useDispatch, useSelector } from "react-redux";
import NoticeStatusForm from "./Noticestatusform";
import { navheaderList, navheaderListAll } from "store/slices/navheaderSlice";
const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const AddNewCardForm = ({
  visible,
  onCreate,
  onCancel,
  statusShow,
  initialVal,
  inputChange,
  appDetail,
  userDetail
}) => {
  const [form] = Form.useForm();
  const { Option } = Select;
  const dateFormat = 'DD/MM/YYYY';
  //console.log(initialVal, userDetail)
  //let now = dayjs()

  form.setFieldsValue({
    description: initialVal.description,
    subject: initialVal.subject,
    email: initialVal.email != '' ? initialVal.email : initialVal.type=='Student' ? userDetail.email : '',
    date: initialVal.date === 'undefined' ? '' : (initialVal.date != '' ? dayjs(initialVal.date, dateFormat) : dayjs()),
    statusName: statusShow,
    type:initialVal.type !='' ? initialVal.type : 'Counsellor',
  });
  return (
    <Modal
      destroyOnClose={true}
      title="Add New Notification"
      open={visible}
      okText="Submit"
      onCancel={onCancel}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
          })
          .catch((info) => {
            console.log("Validate Failed:", info);
          });
      }}
    >
      <Form
        preserve={false}
        form={form}
        name="addCourseType"
        layout="vertical"
        initialValues={{
          id: initialVal.id,
          description: initialVal.description,
          subject: initialVal.subject,
          email: initialVal.email != '' ? initialVal.email : initialVal.type=='Student' ? userDetail.email : '',
          date: initialVal.date === 'undefined' ? '' : (initialVal.date != '' ? dayjs(initialVal.date, dateFormat) : dayjs()),
          statusName: statusShow,
          type:initialVal.type !='' ? initialVal.type : 'Counsellor',
        }}
      >
        <Row gutter={14}>
        <Col xs={24} sm={24} md={8}>
        <Form.Item
        
          label="Type"
          name="type"
          rules={[
            {
              required: true,
              message: "Please select type!",
            },

          ]}
        >
          <Select
            showSearch
            onChange={inputChange("type")}
            placeholder="Select Type"
            optionFilterProp="children"
            filterOption={(input, option) =>
              option.props.children
                .toLowerCase()
                .indexOf(input.toLowerCase()) >= 0
            }
          >
            return (
            <Option
              key={`type1`}
              value="Student"
            >
              Student
            </Option>
            <Option
              key={`type2`}
              value="Counsellor"
            >
              Counsellor
            </Option>
            );
          </Select>
        </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={16}>
        <Form.Item
          label="Email To"
          name="email"
          rules={[
            {
              required: true,
              message: "Please enter email!",
            },
            {
              type: 'email',
              message: 'The input is not valid E-mail!',
            },
          ]}
        >
          <Input placeholder="Email" onChange={inputChange("email")} />
        </Form.Item>
        </Col>
          </Row>


        <Form.Item label="Date" name="date" rules={[
          {
            required: true,
            message: "Please enter date!",
          },
        ]}>
          <DatePicker format={dateFormat} allowClear={false} className="w-100" onChange={inputChange("date")} />
        </Form.Item>
        <Form.Item label="Subject" name="subject"
          rules={[
            {
              required: true,
              message: "Please enter subject!",
            },
          ]}
        >
          <Input placeholder="Subject" onChange={inputChange("subject")} />
        </Form.Item>
        <Form.Item label="Description" name="description"
          rules={[
            {
              required: true,
              message: "Please enter description!",
            },
          ]}
        >
          <Input.TextArea placeholder="Description" onChange={inputChange("description")} />
        </Form.Item>

        { /* <Form.Item label="Status" name="statusName">
                    <Switch onChange={statusOnChange} checked={statusShow} />
                </Form.Item>
            */ }
      </Form>
    </Modal>
  );
};
const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
  return (
    <Modal
      destroyOnClose={true}
      title="Notification"
      open={visible}
      okText="OK"
      onCancel={onCancelConfirm}
      onOk={() => {
        onOKConfirm();
      }}
    >
      Are you sure want to delete this item?
    </Modal>
  );
};

const NotificationApp = (props) => {
  const dateFormat = "DD/MM/YYYY";
  const { mode = ADD, appDetail } = props;
  const userDetail = Object.assign(appDetail.student);
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [listMis, setListMis] = useState([]);
  const [ListMisOther, setListMisOther] = useState([]);
  const [number, setNumber] = useState(100);
  const [btnShow, setBtnShow] = useState(false);
  const [modalVisibleConfirmation, setModalVisibleConfirmation] =
    useState(false);
  const [initialId, setInitialId] = useState(0);
  const [showPopup, setShowPopup] = useState(0);
  const [btnShowHide, setBtnShowHide] = useState({
    add: 0,
    edit: 0,
    delete: 0,
    upload: 0,
    download: 0,
  });
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );
  const [listMisSelect, setListMisSelect] = useState([]);
  const [list, setList] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [statusShow, setStatusShow] = useState(false);
  const [initialVal, setInitialVal] = useState({
    id: "",
    description: "",
    email: "",
    date: "",
    subject: "",
    type:"Counsellor"

  });

  const dispatch = useDispatch()
  const navheaderlist = useSelector((state) => state.navheaderlist)
  
  const {
    loading,
    showMessage,
    navheaderListAll
  } = props

  const listData = (page, pageSize, search = null) => {
    const reqeustParam = { page: page, pageSize: pageSize, search: search, application_id: appDetail.id };
    try {
      const resp = leadsService.getNotification(reqeustParam);
      resp
        .then((res) => {
          //console.log(res)
          //setrecord(res.data.total);
          setList(res.data.data);
          //setListAll(res.data.data);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };





  useEffect(() => {
    listData();
    //listDataOther();
    const addPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 95
    );
    const editPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 95
    );
    const delPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 96
    );
    setBtnShowHide({
      add: addPermission.length,
      edit: editPermission.length,
      delete: delPermission.length,
    });
  }, [form, mode, props]);

  const updateReload = () => {
    listData();
    
  }


  let i = 1;


  const showModal = () => {
    setInitialVal({
      id: "",
      description: "",
      email: "",
      date: "",
      subject: "",
      type:"Counsellor"

    });
    setModalVisible(true);
  };

  const closeModal = () => {
    setInitialVal({
      id: "",
      description: "",
      email: "",
      date: "",
      subject: ""

    });
    setModalVisible(false);
    setStatusShow(false);
  };

  const statusOnChange = (show) => {
    setStatusShow(show);
  };

  const addCourseType = (values) => {
    let dayyear = dayjs(values.date).year();
    let daymonth = dayjs(values.date).month() + 1;
    let daydate = dayjs(values.date).date();
    let daytm = `${dayyear}-${daymonth}-${daydate}`

    let coursetype = values.statusName === true ? 1 : 0;

    //console.log(initialVal);
    if (initialVal.id > 0) {
      const reqeustParam = {
        notification_id: initialVal.id,
        student_id: userDetail.id,
        application_id: appDetail.id,
        description: values.description,
        email: values.email,
        date: daytm,
        subject: values.subject,
        type:values.type

      };

      const resp = leadsService.editNotification(reqeustParam);
      resp
        .then((res) => {
          if (res.status === 200) {
            listData();
            navheaderListAll()
          }
          notification.success({ message: "Notification updated successfully." });
          setInitialVal({
            id: "",
            description: "",
            email: "",
            date: "",
            subject: ""

          });
          setStatusShow(false);
          setModalVisible(false);
        })
        .catch((err) => { });
    } else {
      const reqeustParam = {
        student_id: userDetail.id,
        application_id: appDetail.id,
        description: values.description,
        email: values.email,
        date: values.date,
        subject: values.subject,
        type:values.type

      };
      
      const resp = leadsService.addNotification(reqeustParam);
      resp
        .then((res) => {
          if (res.status === 200) {
            listData();
            navheaderListAll()
          }

          notification.success({ message: "Notification added successfully." });
          setInitialVal({
            id: "",
            description: "",
            email: "",
            date: "",
            subject: ""

          });
          setStatusShow(false);
          setModalVisible(false);
        })
        .catch((err) => { });
        
    }

  };
  const showEditVaue = (elm) => {
    //console.log(elm)

    let statustype = elm.is_active === 1 ? true : false;
    setInitialVal({
      id: elm.id,
      description: elm.description,
      email: elm.email,
      date: dayjs(elm.date, dateFormat),
      subject: elm.subject

    });
    setStatusShow(statustype);
    showModal();
  };
  const deleteCourse = (elm) => {
    //console.log(elm)
    setInitialId(elm);
    setModalVisibleConfirmation(true);
  };
  const onCancelConfirm = () => {
    setInitialId(0);
    setModalVisibleConfirmation(false);
  };

  const onOKConfirm = () => {
    const reqeustParam = { notification_id: initialId };
    //console.log(initialId)
    const resp = leadsService.deleteNotification(reqeustParam);
    resp
      .then((res) => {
        if (res.status === 200) {
          setModalVisibleConfirmation(false);
          listData();
          navheaderListAll()
          notification.success({ message: "Notification deleted successfully." });
        }
      })
      .catch((err) => { });
  };

  const inputChange = (name) => (e) => {


    let value;
    name === "description" || name === "email" || name === "subject"
      ? (value = e.target.value)
      : (value = e);

    if(name === 'type' && value === 'Student'){
      //console.log(userDetail.email)
      setInitialVal({ ...initialVal, 'email': userDetail.email, 'type': value });  
    } else  if(name === 'type' && value === 'Counsellor'){
      //console.log(userDetail.email)
      setInitialVal({ ...initialVal, 'email': '', 'type': value });  
    } else {
      setInitialVal({ ...initialVal, [name]: value });
    }


    
  };

  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
      >
        <div className="container123">

          <Row gutter={16} className="justify-content-between">
            <Col className="text-end mb-2" xs={24} sm={24} md={18}>
              {btnShowHide.add > 0 && (
                <Button
                  onClick={showModal}
                  type="primary"
                  icon={<PlusCircleOutlined />}
                >
                  Add Notification
                </Button>
              )}
            </Col>

          </Row>

          {list &&
            list.map((listmis, index) => {
              return (
                <Card>
                  <Row gutter={14}>

                    <Col xs={24} sm={24} md={20}>
                      <Row gutter={14}>
                        <Col xs={24} sm={24} md={24}>
                          <>

                            <p style={{ fontSize: `10px`, marginBottom:`unset` }}>{listmis.email} &nbsp; {listmis.date ? listmis.date : ''}</p>
                            <p style={{ fontSize: `10px` }}>{listmis.status}</p>

                          </>
                        </Col>
                        



                        <Col xs={24} sm={24} md={24}>
                          <strong>{listmis.subject}</strong>
                        </Col>

                        <Col xs={24} sm={24} md={24}>
                          <strong>{listmis.description}</strong>
                        </Col>
                      </Row>
                    </Col>

                    <Col xs={24} sm={24} md={4}>
                    {btnShowHide.edit > 0 && (
            <Popover content={<NoticeStatusForm appid={listmis.id} updateReload={updateReload} />} title="Status" trigger="click">
              <label>
                          <Avatar
                            className="ml-1"
                            icon={<AimOutlined />}
                            size={25}
                            style={{ backgroundColor: `blue`, cursor: `pointer` }}
                           
                          />
                        </label>
              
              
            </Popover>
          )}
                      
                      {btnShowHide.add > 0 && (
                        <label>
                          <Avatar
                            className="ml-1"
                            icon={<DeleteOutlined />}
                            size={25}
                            style={{ backgroundColor: `red`, cursor: `pointer` }}
                            onClick={() => {
                              deleteCourse(listmis.id);
                            }}
                          />
                        </label>
                      )}
                      
                    </Col>

                  </Row>
                </Card>
              );
            })}

          <AddNewCardForm
            visible={modalVisible}
            onCreate={addCourseType}
            onCancel={closeModal}
            statusShow={statusShow}
            initialVal={initialVal}
            inputChange={inputChange}
            appDetail={appDetail}
            userDetail={userDetail}
          />
          <ConfirmationBox
            id={initialId}
            visible={modalVisibleConfirmation}
            onOKConfirm={onOKConfirm}
            onCancelConfirm={onCancelConfirm}
          />

        </div>
      </Form>
    </>
  );
};

const mapStateToProps = ({ navheaderlist }) => {
  const { loading, message, list } = navheaderlist;
  return { loading, message, list }
}

const mapDispatchToProps = {
  navheaderListAll

}

export default connect(mapStateToProps, mapDispatchToProps)(NotificationApp);

//export default NotificationApp;
