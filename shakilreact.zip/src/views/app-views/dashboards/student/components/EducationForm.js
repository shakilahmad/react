import React, { useEffect, useState } from "react";
import {
  MinusCircleOutlined,
  PlusOutlined,
  CloudUploadOutlined,
} from "@ant-design/icons";
import {
  Table,
  Input,
  InputNumber,
  Popconfirm,
  Form,
  Select,
  message,
  Button,
  Checkbox
} from "antd";
import masterService from "../../../../../services/MasterService";
import leadsService from "../../../../../services/LeadsServices";
import Flex from "components/shared-components/Flex";
const { Option } = Select;
var is_checked = 0;
const EditableCell = ({
  editing,
  dataIndex,
  title,
  options,
  record,
  index,
  children,
  ...restProps
}) => {
  const textType =
    options === "" ? (
      dataIndex === "is_latest" ? <Checkbox checked={is_checked} onChange={onChange} /> :
      <Input style={{width:"150px"}}/>
    ) : (
      <Select
        showSearch
        placeholder="Please choose any one"
        optionFilterProp="children"
        filterOption={(input, option) =>
          option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
        }
      >
        {options &&
          options.map((options, i) => {
            return (
              <Option key={`${dataIndex}_${i}`} value={options.name}>
                {options.name}
              </Option>
            );
          })}
      </Select>
    );
  return (
    <td {...restProps}>
      { 
      editing ? 
      dataIndex==='is_latest'?
      (
        <Form.Item
          name={dataIndex}
          style={{
            margin: 0,
          }}
          rules={[
            {
              required: false,
              message: `Please Input ${title}!`,
            },
          ]}
        >
          {textType}
        </Form.Item>
      ) 
      :
      (
        <Form.Item
          name={dataIndex}
          style={{
            margin: 0,
          }}
          rules={[
            {
              required: true,
              message: `Please Input ${title}!`,
            },
          ]}
        >
          {textType}
        </Form.Item>
      ) : (
        children
      )}
    </td>
  );
};

function onChange(e) {
  is_checked = e.target.checked;
  //console.log(is_checked);
}

const EducationForm = (props) => {
  const { userDetail } = props;
  const [form] = Form.useForm();
  const [educationData, setEducationData] = useState([]);
  const [editingKey, setEditingKey] = useState("");
  const [countryList, setCountryList] = useState([]);
  const [number, setNumber] = useState(100);
  const [btnShow, setBtnShow] = useState(false);
  const isEditing = (record) => record.id === editingKey;

  const highLevel = [
    { id: "Grade 10", name: "Grade 10" },
    { id: "Grade 11", name: "Grade 11" },
    { id: "Grade 12", name: "Grade 12" },
    {
      id: "1yr Certification after High School",
      name: "1yr Certification after High School",
    },
    { id: "2yr Undergraduate Diploma", name: "2yr Undergraduate Diploma" },
    { id: "3yr Bachelor Degree", name: "3yr Bachelor Degree" },
    { id: "Post Graduate Diploma/Cert", name: "Post Graduate Diploma/Cert" },
    { id: "Masters Degre", name: "Masters Degree" },
  ];

  const grading = [
    { id: "Grade 5", name: "Grade 5" },
    { id: "Grade 10", name: "Grade 10" },
    { id: "Grade 100", name: "Grade 100" },
  ];

  const edit = (record) => {
    //console.log(record)
    record.is_latest ? is_checked=true : is_checked=false
    
    form.setFieldsValue({ ...record });
    setEditingKey(record.id);
    setBtnShow(false);
  };

  const cancel = () => {
    setEditingKey("");
    setBtnShow(false);
  };
 
  const listCountryData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getCountry(reqeustParam);
      resp
        .then((res) => {
          
          setCountryList(res.data);
         // console.log(res.data)
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    
    const originData = userDetail.educations.map((item) => {
      return {
        id: item.id,
        is_latest: item.is_latest,
        degree_name: item.degree_name,
        country_name: item.country_name,
        high_education: item.high_education,
        grading_schema: item.grading_schema,
        score: item.score,
      };
    });
    //console.log(originData.length)
    const dataDefault = [{
      id: '',
      is_latest: '',
      degree_name: '',
      country_name: '',
      high_education: '',
      grading_schema: '',
      score: '',
    }]
    originData.length > 0 ? setEducationData(originData) : setEducationData(dataDefault)

    listCountryData();

    

  }, []);

  
  const save = async (key) => {
    try {
      const row = await form.validateFields();
      row.education_id = key;
      row.is_latest = is_checked;
     //console.log(row)
      const resp = leadsService.educationHistoryUpdateStudent(row);
      resp
        .then((res) => {
          if (res.status == 200) {
            const newData = [...educationData];
            const index = newData.findIndex((item) => key === item.id);
            if (index > -1) {
              const item = newData[index];
              newData.splice(index, 1, { ...item, ...row });
              //console.log(newData)
              setEducationData(newData);
              setEditingKey("");
              setBtnShow(false);
            }
            message.success(res.message);
          } else {
            message.error(res.message);
          }
        })
        .catch((err) => {
          message.error("Please upload valid data with valid format");
        });
    } catch (errInfo) {
      console.log("Validate Failed:", errInfo);
    }
  };

  const cancelMore = (index) => {
    const newData = [...educationData];
      newData.splice(index, 1);
      setEducationData(newData);
      setBtnShow(false);
  };

  const saveMore = async (index) => {
    try {
      const row = await form.validateFields();
      row.student_id = userDetail.id;
      row.is_latest = is_checked;
     // console.log(row)
      const resp = leadsService.educationHistoryStudent(row);
      resp
        .then((res) => {
          
          if (res.status == 200) {
            const newData = [...educationData];
            const data = res.data;
            newData.splice(index, 1);
            newData.push(data);
            //console.log(newData)
            setEducationData(newData);
            setBtnShow(false);
            setEditingKey("");
            message.success(res.message);
          } else {
            message.error(res.message);
          }
        })
        .catch((err) => {
          message.error("Please upload valid data with valid format");
        });
    } catch (errInfo) {
      console.log("Validate Failed:", errInfo);
    }
  };

  const columns = [
    {
      title: "Country of Education",
      dataIndex: "country_name",
      width: "20%",
      editable: true,
      data: countryList,
    },
    {
      title: "Heighest Level of Education",
      dataIndex: "high_education",
      width: "20%",
      editable: true,
      data: highLevel,
    },
    {
      title: "Latest Education",
      dataIndex: "is_latest",
      width: "20%",
      editable: true,
      data: "",
      render: (text, record, index) => {
        const editable = isEditing(record);
        //console.log(record)
        //console.log(record.id)

        return record.id === "" ? (
          <>
            <Flex>
            
            </Flex>
          </>
        ) : editable ? (
          <Flex>
            
          </Flex>
        ) : (
          <Flex>
           {record.is_latest ?
            'Yes'
            :
            ''
           }
          </Flex>
        );
      },
    },
    {
      title: "Degree Name",
      dataIndex: "degree_name",
      width: "20%",
      editable: true,
      data: "",
    },
    {
      title: "Grading Scheme",
      dataIndex: "grading_schema",
      width: "20%",
      editable: true,
      data: grading,
    },
    {
      title: "Score",
      dataIndex: "score",
      width: "20%",
      editable: true,
      data: "",
    },
    {
      title: "operation",
      dataIndex: "operation",
      render: (text, record, index) => {
        const editable = isEditing(record);
        return record.id === "" ? (
          <>
            <Flex>
              <Button type="link" onClick={() => saveMore(index)}>
                Save
              </Button>
              <Popconfirm
                title="Sure to remove?"
                onConfirm={() => cancelMore(index)}
              >
                <Button type="link" >Remove</Button>
              </Popconfirm>
            </Flex>
          </>
        ) : editable ? (
          <Flex>
            <Button type="link" onClick={() => save(record.id)}>
              Save
            </Button>
            <Popconfirm
              title="Sure to cancel?"
              onConfirm={() => cancel(record.id)}
            >
              <Button>Cancel</Button>
            </Popconfirm>
          </Flex>
        ) : (
          <a disabled={editingKey !== ""} onClick={() => edit(record)}>
            Edit
          </a>
        );
      },
    },
  ];
  const components = {
    body: {
      cell: EditableCell,
    },
  };

  const mergedColumns = columns.map((col) => {
    if (!col.editable) {
      return col;
    }
    return {
      ...col,
      onCell: (record) => ({
        record,
        dataIndex: col.dataIndex,
        title: col.title,
        options: col.data,
        editing: isEditing(record),
      }),
    };
  });

  const addMoreField = () => {
    const newElement = {
      id: "",
      country_name: "",
      high_education: "",
      grading_schema: "",
      score: "",
      is_latest:"",
      degree_name:""
    };
    setNumber(number + 1);
    setEducationData((educationData) => [...educationData, newElement]);
    setBtnShow(false);
  };

  return (
    <>
      <Form form={form}>
        <Table
          components={components}
          bordered
          dataSource={educationData}
          columns={mergedColumns}
          rowClassName="editable-row"
          pagination={false}
        />
      </Form>
      <Button
        className="mt-2"
        type="primary"
        hidden={btnShow}
        icon={<PlusOutlined />}
        onClick={() => {
          addMoreField();
        }}
      >
        Add More
      </Button>
    </>
  );
};

export default EducationForm;
