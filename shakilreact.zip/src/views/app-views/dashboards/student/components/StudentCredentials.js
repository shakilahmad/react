import React, { useState, useEffect } from "react";
import leadsService from "../../../../../services/LeadsServices";
import {
  Button,
  message,
  Input,
  Row,
  Col,
  Card,
  Form,
  Avatar,
  notification,
  Modal,
} from "antd";
import {
  DeleteOutlined,
  PlusCircleOutlined,
  PlusOutlined,
  MinusCircleOutlined,
  EditOutlined,
} from "@ant-design/icons";
import { useSelector } from "react-redux";

const ADD = "ADD";

const EditNewCredentialForm = ({
  visible,
  onCreate,
  onCancel,
  initialVal,
  inputChange,
}) => {
  const [form] = Form.useForm();
  form.setFieldsValue({
    link: initialVal.link,
    username: initialVal.username,
    password: initialVal.password,
  });
  return (
    <Modal
      destroyOnClose={true}
      title="Edit Credential"
      open={visible}
      okText="Save"
      onCancel={onCancel}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
          })
          .catch((info) => {
            console.log("Validate Failed:", info);
          });
      }}
    >
      <Form
        preserve={false}
        form={form}
        name="editCredential"
        layout="vertical"
        initialValues={{
          id: initialVal.id,
          link: initialVal.link,
          username: initialVal.username,
          password: initialVal.password,
        }}
      >
        <Form.Item
          label="Link"
          name="link"
          rules={[
            {
              required: false,
              message: "Please enter link",
            },
          ]}
          className="w-100"
        >
          <Input
            placeholder="Enter Link"
            onChange={(e) => inputChange(e, "link")}
          />
        </Form.Item>

        <Form.Item
          label="User Name"
          name="username"
          rules={[
            {
              required: false,
              message: "Please enter username",
            },
          ]}
          className="w-100"
        >
          <Input
            placeholder="Enter Username"
            onChange={(e) => inputChange(e, "username")}
          />
        </Form.Item>

        <Form.Item
          label="Password"
          name="password"
          rules={[
            {
              required: false,
              message: "Please enter password",
            },
          ]}
          className="w-100"
        >
          <Input
            placeholder="Enter Password"
            onChange={(e) => inputChange(e, "password")}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
  return (
    <Modal
      destroyOnClose={true}
      title="Credential"
      open={visible}
      okText="OK"
      onCancel={onCancelConfirm}
      onOk={() => {
        onOKConfirm();
      }}
    >
      Are you sure want to delete this item?
    </Modal>
  );
};

const StudentCredentials = (props) => {
    //console.log('kkkkkkkkkkkkkkkkkkkkkk',props)
    const { mode = ADD, userDetail = [] } = props;
  
  //const application_id = userDetail.id;
  const student_id = userDetail.id;
  const [form] = Form.useForm();
  const [ListMisOther, setListMisOther] = useState([]);
  const [initialVal, setInitialVal] = useState({
    id: "",
    link: "",
    username: "",
    password: "",
  });
  const [modalVisible, setModalVisible] = useState(false);
  const [modalVisibleConfirmation, setModalVisibleConfirmation] =
    useState(false);
  const [initialId, setInitialId] = useState(0);
  const [showPopup, setShowPopup] = useState(0);
  const [btnShowHide, setBtnShowHide] = useState({
    add: 0,
    delete: 0,
  });
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );

  const listDataOther = () => {
    try {
      if (student_id > 0) {
        const reqeustParam = {
          student_id: student_id,
        };
        const respData = leadsService.applicationCredentialList(reqeustParam);
        respData
          .then((res) => {
            setListMisOther(res.data);
          })
          .catch((err) => {});
      }
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    listDataOther();
    const addPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 99
    );
    const delPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 100
    );

    setBtnShowHide({
      add: addPermission.length,
      delete: delPermission.length,
    });
  }, [form, mode, props]);

  const onFinish = (name, remove) => {
    const data = new FormData();
    data.append("student_id", student_id);
    data.append("link", initialVal.link);
    data.append("username", initialVal.username);
    data.append("password", initialVal.password);

    try {
      const resp = leadsService.applicationCredentialCreate(data);

      resp
        .then((res) => {
          listDataOther();
          remove(name);
          setInitialVal({ id: "", link: "", username: "", password: "" });
          message.success("Credentials create successfully.");
        })
        .catch((err) => {
          message.error(err.response.data.message);
        });
    } catch (errors) {
      //
    }
  };

  const editCredential = (values) => {
    const data = new FormData();
    data.append("credential_id", initialVal.id);
    data.append("student_id", student_id);
    data.append("link", values.link);
    data.append("username", values.username);
    data.append("password", values.password);
    try {
      const resp = leadsService.applicationCredentialCreate(data);
      resp
        .then((res) => {
          listDataOther();
          setModalVisible(false);
          setInitialVal({ id: "", link: "", username: "", password: "" });
          message.success("Credentials updated successfully.");
        })
        .catch((err) => {
          message.error(err.response.data.message);
        });
    } catch (errors) {
      //
    }
  };

  let i = 1;

  const inputChange = (e, name) => {
    let value =
      name == "image"
        ? e.target.files[0]
        : name == "document_name"
        ? e
        : e.target.value;
    setInitialVal({ ...initialVal, [name]: value });
  };

  const deleteStudentDoc = (elm) => {
    setInitialId(elm);
    setModalVisibleConfirmation(true);
  };

  const onCancelConfirm = () => {
    if (initialId != 0) {
      setInitialId(0);
    }
    setModalVisibleConfirmation(false);
  };

  const onOKConfirm = () => {
    let value = initialId;
    const reqeustParam = {
      credential_id: value,
    };
    const resp = leadsService.applicationCredentialDelete(reqeustParam);
    resp
      .then((res) => {
        if (res.status === 200) {
          setModalVisibleConfirmation(false);

          listDataOther();
          notification.success({ message: res.message });
        }
      })
      .catch((err) => {});
  };

  const showEditValue = (elm) => {
    setInitialVal({
      id: elm.id,
      link: elm.link,
      username: elm.username,
      password: elm.password,
    });
    showModal();
  };
  const showModal = () => {
    setModalVisible(true);
  };

  const closeModal = () => {
    setInitialVal({ id: "", link: "", username: "", password: "" });
    setModalVisible(false);
  };

  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
      >
        <div className="container123">
          {ListMisOther &&
            ListMisOther.map((ListMisOther, index) => {
              return (
                <Card>
                  <Row className="" gutter={16}>
                    <Col xs={24} sm={24} md={20}>
                      <Row gutter={16}>
                        <Col xs={24} sm={24} md={24}>
                          <Row gutter={16}>
                            <Col xs={24} sm={24} md={4}>
                              Link
                            </Col>
                            <Col xs={24} sm={24} md={20}>
                              : {ListMisOther.link}
                            </Col>
                          </Row>
                        </Col>
                        <Col xs={24} sm={24} md={24}>
                          <Row gutter={16}>
                            <Col xs={24} sm={24} md={4}>
                              Username
                            </Col>
                            <Col xs={24} sm={24} md={20}>
                              : {ListMisOther.username}
                            </Col>
                          </Row>
                        </Col>
                        <Col xs={24} sm={24} md={24}>
                          <Row gutter={16}>
                            <Col xs={24} sm={24} md={4}>
                              Password
                            </Col>
                            <Col xs={24} sm={24} md={20}>
                              : {ListMisOther.password}
                            </Col>
                          </Row>
                        </Col>
                      </Row>
                    </Col>
                    <Col xs={24} sm={24} md={4}>
                      <div className="d-flex">
                        {btnShowHide.add > 0 && (
                          <label>
                            <Avatar
                              className="mr-1"
                              icon={<EditOutlined />}
                              size={25}
                              style={{
                                backgroundColor: `blue`,
                                cursor: `pointer`,
                              }}
                              onClick={() => {
                                showEditValue(ListMisOther);
                              }}
                            />
                          </label>
                        )}
                        {btnShowHide.delete > 0 && (
                          <label>
                            <Avatar
                              className="mr-1"
                              icon={<DeleteOutlined />}
                              size={25}
                              style={{
                                backgroundColor: `red`,
                                cursor: `pointer`,
                              }}
                              onClick={() => {
                                deleteStudentDoc(ListMisOther.id);
                              }}
                            />
                          </label>
                        )}
                      </div>
                    </Col>
                  </Row>
                </Card>
              );
            })}

          <ConfirmationBox
            id={initialId}
            visible={modalVisibleConfirmation}
            onOKConfirm={onOKConfirm}
            onCancelConfirm={onCancelConfirm}
          />
          <EditNewCredentialForm
            visible={modalVisible}
            onCreate={editCredential}
            onCancel={closeModal}
            initialVal={initialVal}
            inputChange={inputChange}
          />
          <Form.List name="variants">
            {(fields, { add, remove }) => {
              return (
                <div className="mt-3">
                  {fields.map((field, index) => (
                    <Card id={field.name}>
                      <Row key={field.key} gutter={16}>
                        <Col xs={24} sm={24} md={7}>
                          <Form.Item
                            {...field}
                            label=""
                            name={[field.name, "link"]}
                            fieldKey={[field.fieldKey, "link"]}
                            rules={[
                              {
                                required: false,
                                message: "Please enter link",
                              },
                            ]}
                            className="w-100"
                          >
                            <Input
                              placeholder="Enter Link"
                              onChange={(e) => inputChange(e, "link")}
                            />
                          </Form.Item>
                        </Col>
                        <Col xs={24} sm={24} md={6}>
                          <Form.Item
                            {...field}
                            label=""
                            name={[field.name, "username"]}
                            fieldKey={[field.fieldKey, "username"]}
                            rules={[
                              {
                                required: false,
                                message: "Please enter username",
                              },
                            ]}
                            className="w-100"
                          >
                            <Input
                              placeholder="Enter Username"
                              onChange={(e) => inputChange(e, "username")}
                            />
                          </Form.Item>
                        </Col>
                        <Col xs={24} sm={24} md={6}>
                          <Form.Item
                            {...field}
                            label=""
                            name={[field.name, "password"]}
                            fieldKey={[field.fieldKey, "password"]}
                            rules={[
                              {
                                required: false,
                                message: "Please enter password",
                              },
                            ]}
                            className="w-100"
                          >
                            <Input
                              placeholder="Enter Password"
                              onChange={(e) => inputChange(e, "password")}
                            />
                          </Form.Item>
                        </Col>
                        <Col sm={24} md={2} className="">
                          <Button
                            type="primary"
                            className="mr-2"
                            icon={<PlusCircleOutlined />}
                            size="small"
                            onClick={() => onFinish(field.name, remove)}
                          >
                            Save
                          </Button>
                        </Col>
                        <Col sm={24} md={3}>
                          <Button
                            type="primary"
                            danger
                            className="mr-2"
                            icon={<MinusCircleOutlined />}
                            size="small"
                            onClick={() => {
                              remove(field.name);
                            }}
                          >
                            Cancel
                          </Button>
                        </Col>
                      </Row>
                    </Card>
                  ))}
                  <Form.Item>
                    {btnShowHide.add > 0 && (
                      <Button
                        type="primary"
                        onClick={() => {
                          add();
                        }}
                        className="w-100"
                        ghost
                      >
                        <PlusOutlined /> Add Credentials
                      </Button>
                    )}
                  </Form.Item>
                </div>
              );
            }}
          </Form.List>
        </div>
      </Form>
    </>
  );
};

export default StudentCredentials;
