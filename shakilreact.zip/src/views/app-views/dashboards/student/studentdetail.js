import React, { useState, useEffect } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { Card, Avatar, Tabs, Spin, Breadcrumb, Button } from "antd";

import leadsService from "../../../../services/LeadsServices";
import Meta from "antd/es/card/Meta";
import Profile from "./components/Profile";
import DocumentForm from "./components/DocumentForm";
import SearchApply from "./components/SearchApply";
import ApplicationForm from "./components/ApplicationForm";
import HistoryForm from "./components/HistoryForm";
import NotificationAdd from "./components/Notification";
import { useSelector } from "react-redux";
//import Credentials from "./components/Credentials";
import StudentCredentials from "./components/StudentCredentials";

const DetailStudent = () => {
  const redirectData = useLocation();
  const navigate = useNavigate();
  const params = useParams();
  const [list, setList] = useState([]);
  const [showLoader, setShowLoader] = useState(true);
  const [showTab, setShowTab] = useState(redirectData.state?.defalutApp);
  const [btnShowHide, setBtnShowHide] = useState({
    history: 0,
    notification: 0,
    searchapply: 0,
    credential: 0,
  });
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );

  const listData = () => {
    const reqeustParam = { student_id: params.id };
    try {
      const resp = leadsService.detailsStudent(reqeustParam);
      resp
        .then((res) => {
          //console.log("res.dat", res.data);
          setList(res.data);
          setShowLoader(false);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    listData();

    const searchapplyPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 64
    );
    const historyPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 101
    );
    const notificationPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 93
    );
    const credlistPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 98
    );

    setBtnShowHide({
      history: historyPermission.length,
      notification: notificationPermission.length,
      searchapply: searchapplyPermission.length,
      credential: credlistPermission.length,
    });

    //console.log('general page')
  }, [params]);

  const showProfile = () => {
    listData();
  };
  const loaderShow = () => {
    //console.log('ikkkk')
    setShowLoader(false);
  };

  return (
    <>
      <Spin size="large" spinning={showLoader}>
        <div className="container123">
          <Breadcrumb className="mb-3">
            <Breadcrumb.Item>
              <Button
                style={{ height: `unset`, padding: `unset`, color: `unset` }}
                type="link"
                onClick={() => navigate(`/dashboards/student`)}
              >
                Student List
              </Button>
            </Breadcrumb.Item>
            <Breadcrumb.Item>Student Detail</Breadcrumb.Item>
          </Breadcrumb>

          <Card>
            <Meta
              avatar={
                <Avatar style={{ backgroundColor: "green" }}>
                  {list.first_name?.substring(0, 1)}
                  {list.last_name?.substring(0, 1)}
                </Avatar>
              }
              title={`${list.first_name} ${list.middle_name} ${list.last_name}`}
              description={`${list.email} | ${list.mobile}`}
            />

            <div className="container123">
              <Tabs
                defaultActiveKey={`${showTab}`}
                style={{ marginTop: 30 }}
                destroyInactiveTabPane={true}
                items={[
                  {
                    label: "Profile",
                    key: "1",
                    children: (
                      <Profile
                        mode="EDIT"
                        userDetail={list}
                        showProfile={showProfile}
                        loaderShow={loaderShow}
                      />
                    ),
                  },
                  {
                    label: "Documents",
                    key: "2",
                    children: <DocumentForm mode="EDIT" userDetail={list} />,
                  },
                  btnShowHide.searchapply > 0 && {
                    label: "Search and Apply",
                    key: "3",
                    children: <SearchApply mode="EDIT" userDetail={list} />,
                  },
                  {
                    label: "Applications",
                    key: "4",
                    children: <ApplicationForm mode="EDIT" userDetail={list} />,
                  },
                  btnShowHide.history > 0 && {
                    label: "History",
                    key: "5",
                    children: <HistoryForm mode="EDIT" userDetail={list} />,
                  },
                  btnShowHide.notification > 0 && {
                    label: "Notification",
                    key: "6",
                    children: <NotificationAdd mode="EDIT" userDetail={list} />,
                  },
                  btnShowHide.credential > 0 && {
                    label: "Credentials",
                    key: "7",
                    children: <StudentCredentials mode="EDIT" userDetail={list} />,
                  },
                ]}
              />
            </div>
          </Card>
        </div>
      </Spin>
    </>
  );
};

export default DetailStudent;
