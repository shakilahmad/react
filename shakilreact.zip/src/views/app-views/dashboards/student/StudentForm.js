import React, { useState, useEffect } from "react";
import leadsService from "../../../../services/LeadsServices";
import {
  Button,
  message,
  Input,
  Row,
  Col,
  Card,
  Form,
  Select,
  Switch,
  Radio,
  DatePicker,
} from "antd";

import masterService from "../../../../services/MasterService";
import { useNavigate } from "react-router-dom";
import dayjs from "dayjs";
import { useSelector } from "react-redux";

const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const AddStudent = (props) => {
  const dateFormat = "DD/MM/YYYY";
  const { mode = ADD, param } = props;
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [countryList, setCountryList] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [statusShow, setStatusShow] = useState(false);
  const [btnShowHide, setBtnShowHide] = useState({
    emailedit: 0,
  });
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );

  const listCountryData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getCountry(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setCountryList(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  const listStatusesData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getStatus(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setStatuses(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    const emailPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id == 117
    );
   
    if(mode == 'ADD'){
      
      setBtnShowHide({
        emailedit: 1,
      });
    } else {
    
    setBtnShowHide({
      emailedit: emailPermission.length,
    });
  }



    listCountryData();
    listStatusesData();

    if (mode === EDIT) {
      // console.log('is edit')
      // console.log('props', props)
      const { id } = param;
      const studentId = parseInt(id);

      const reqeustParam = { student_id: studentId };
      const resp = leadsService.detailsStudent(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data.dob)
          //listStateData(res.data.country_id)
          //listCityData(res.data.state_id)
          statusOnChange(res.data.is_active);
          //setShowImage(res.data.logo)
          form.setFieldsValue({
            first_name:
              res.data.first_name === "undefined" ? "" : res.data.first_name,
            last_name:
              res.data.last_name === "undefined" ? "" : res.data.last_name,
            middle_name:
              res.data.middle_name === "undefined" ? "" : res.data.middle_name,
            dob:
              res.data.dob === "undefined"
                ? ""
                : dayjs(res.data.dob, dateFormat),
            country_id:
              res.data.country_id === "undefined" ? "" : res.data.country_id,
            passport_number:
              res.data.passport_number === "undefined"
                ? ""
                : res.data.passport_number,
            gender: res.data.gender === "undefined" ? "" : res.data.gender,
            email: res.data.email === "undefined" ? "" : res.data.email,
            email2: res.data.email2 === "undefined" ? "" : res.data.email2,
            mobile: res.data.mobile === "undefined" ? "" : res.data.mobile,
            marital_status:
              res.data.marital_status === "undefined"
                ? ""
                : res.data.marital_status,
            referral_source:
              res.data.referral_source === "undefined"
                ? ""
                : res.data.referral_source,
            interest_country_id:
              res.data.interest_country_id === "undefined"
                ? ""
                : res.data.interest_country_id,
            service_interest:
              res.data.service_interest === "undefined"
                ? ""
                : res.data.service_interest,
            is_active:
              res.data.is_active === "undefined" ? "" : res.data.is_active,
          });
        })
        .catch((err) => {});
    }
  }, [form, mode, param, props]);

  const onFinish = () => {
    setSubmitLoading(true);
    form
      .validateFields()
      .then((values) => {
        setTimeout(() => {
          setSubmitLoading(false);
          if (mode === ADD) {
            //console.log(values)

            let statusname =
              values.is_active === true ? 1 : values.is_active === 1 ? 1 : 0;
            const data = { ...values, is_active: statusname };
            const resp = leadsService.addStudent(data);
            //console.log(resp);
            resp
              .then((res) => {
                //console.log(res.data.user_id);
                message.success(`Student successfully added.`);
                navigate(`/dashboards/student-detail/${res.data.id}`);
              })
              .catch((err) => {
                message.danger(`Student not added. Please try again?`);
              });

            /*  
              const data = new FormData();
                  data.append('first_name',values.first_name || "")
                  data.append('last_name',values.last_name || "")
                  data.append('middle_name',values.middle_name || "")
                  data.append('dob',values.dob || "")
                  data.append('country_id',values.country_id || null)
                  data.append('passport_number',values.passport_number || "")
                  data.append('gender',values.gender || "")
                  data.append('email',values.email || "")
                  data.append('mobile',values.mobile || "")
                  data.append('status_id',values.status_id || null)
                  data.append('referral_source',values.referral_source || "")
                  data.append('interest_country_id',values.interest_country_id || null)
                  data.append('service_interest',values.service_interest || "")
                  data.append('is_active',statusname)
            */
          }
          if (mode === EDIT) {
            //console.log(values)
            const { id } = param;
            const studentId = parseInt(id);

            let statusname =
              values.is_active === true ? 1 : values.is_active === 1 ? 1 : 0;
            const data = {
              ...values,
              is_active: statusname,
              student_id: studentId,
            };
            leadsService.personalInformationStudent(data);
            message.success(`Student successfully updated.`);
            navigate(`/dashboards/student`);
          }
        }, 1500);
      })
      .catch((info) => {
        setSubmitLoading(false);
        console.log("info", info);
        message.error("Please enter all required field ");
      });
  };

  const statusOnChange = (show) => {
    setStatusShow(show);
  };

  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
      >
        <div className="container123">
          <Card title={`Student ${mode}`}>
            <hr />
            <Row className="pt-5 px-lg-5" gutter={16}>
              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="first_name"
                  label="First Name"
                  rules={[
                    {
                      required: true,
                      message: "Please enter first name!",
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="last_name"
                  label="Last Name"
                  rules={[
                    {
                      required: true,
                      message: "Please enter last name!",
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="middle_name" label="Middel Name">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="dob"
                  label="Date of Birth"
                  rules={[
                    {
                      required: true,
                      message: "Please enter date of birth!",
                    },
                  ]}
                >
                  <DatePicker format={dateFormat} className="w-100" />
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  label="Country"
                  name="country_id"
                  rules={[
                    {
                      required: true,
                      message: "Please select country!",
                    },
                  ]}
                >
                  <Select
                    showSearch
                    placeholder="Select Country"
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                      option.props.children
                        .toLowerCase()
                        .indexOf(input.toLowerCase()) >= 0
                    }
                  >
                    {countryList &&
                      countryList.map((countrylist, index) => {
                        return (
                          <Option
                            key={`country${index}`}
                            value={countrylist.id}
                          >
                            {countrylist.name}
                          </Option>
                        );
                      })}
                  </Select>
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="passport_number"
                  label="Passport Number"
                  className="mb-0"
                >
                  <Input />
                </Form.Item>
                <small className="h5 text-danger">
                  Passport number is optional, but strongly recommended.
                </small>
              </Col>

              <Col xs={24} sm={24} md={12}>
                <Form.Item name="gender" label="Gender">
                  <Radio.Group>
                    <Radio value="Male">Male</Radio>
                    <Radio value="Female">Female</Radio>
                  </Radio.Group>
                </Form.Item>
              </Col>

              <Col className="pb-4" xs={24} sm={24} md={24}>
                <h4>Contact information</h4>
              </Col>

              {btnShowHide.emailedit > 0 && (
                <Col xs={24} sm={24} md={12}>
                  <Form.Item
                    name="email"
                    label="Email"
                    rules={[
                      {
                        required: true,
                        message: "Please enter your email!",
                      },
                      {
                        type: "email",
                        message: "The input is not valid E-mail!",
                      },
                    ]}
                  >
                    <Input />
                  </Form.Item>
                </Col>
              )}

              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="mobile"
                  label="Mobile"
                  rules={[
                    {
                      required: true,
                      message: "Please enter your mobile!",
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="email2"
                  label="Email 2"
                  rules={[
                    {
                      required: false,
                      message: "Please enter your email 2!",
                    },
                    {
                      type: "email",
                      message: "The input is not valid E-mail!",
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
              </Col>

              <Col className="pb-4" xs={24} sm={24} md={24}>
                <h4>Lead Management</h4>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item label="Marital Status" name="marital_status">
                  <Select
                    showSearch
                    placeholder="Please choose a marital status"
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                      option.props.children
                        .toLowerCase()
                        .indexOf(input.toLowerCase()) >= 0
                    }
                  >
                    <Option key={`mstatus1`} value="Married">
                      Married
                    </Option>
                    <Option key={`mstatus2`} value="Single">
                      Single
                    </Option>
                  </Select>
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={12}>
                <Form.Item label="Referral Source" name="referral_source">
                  <Input />
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  label="Country of interest"
                  name="interest_country_id"
                >
                  <Select
                    showSearch
                    placeholder="Select Country"
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                      option.props.children
                        .toLowerCase()
                        .indexOf(input.toLowerCase()) >= 0
                    }
                  >
                    {countryList &&
                      countryList.map((countrylist, index) => {
                        return (
                          <Option
                            key={`country_interest${index}`}
                            value={countrylist.id}
                          >
                            {countrylist.name}
                          </Option>
                        );
                      })}
                  </Select>
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={12}>
                <Form.Item label="Services of interest" name="service_interest">
                  <Select
                    showSearch
                    placeholder="Please choose a services of interest"
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                      option.props.children
                        .toLowerCase()
                        .indexOf(input.toLowerCase()) >= 0
                    }
                  >
                    <Option key="1" value="Admission to University">
                      Admission to University
                    </Option>
                    <Option key="2" value="English Proficiency Training">
                      English Proficiency Training
                    </Option>
                    <Option key="3" value="VISA Services">
                      VISA Services
                    </Option>
                    <Option key="4" value="Accommodation Services">
                      Accommodation Services
                    </Option>
                  </Select>
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={12}>
                <Form.Item name="is_active" label="Status">
                  <Switch onChange={statusOnChange} checked={statusShow} />
                </Form.Item>
              </Col>
            </Row>

            <Row className="px-lg-5">
              <Col xs={24} sm={24} md={12}>
                <Button
                  className="px-5"
                  type="primary"
                  htmlType="submit"
                  loading={submitLoading}
                  onClick={() => onFinish()}
                >
                  {mode === "ADD" ? "Submit" : `Save`}
                </Button>
              </Col>
            </Row>
          </Card>
        </div>
      </Form>
    </>
  );
};

export default AddStudent;
