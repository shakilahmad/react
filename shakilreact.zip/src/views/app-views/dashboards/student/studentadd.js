import React from 'react';
import StudentForm from './StudentForm';

const AddStudent = () => {
	return (
		<StudentForm mode="ADD"/>
	)
}

export default AddStudent;
