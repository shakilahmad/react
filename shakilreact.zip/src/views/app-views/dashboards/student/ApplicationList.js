import React, { useState, useEffect } from "react";
import {
    Button,
    message,
    Input,
    Row,
    Col,
    Card,
    Form,
    Select,
    Switch,
    Radio,
    DatePicker,
    Tag,
    Table,
    Avatar,
    Tooltip,
    Popconfirm,
    Pagination
} from "antd";
import utils from 'utils'
import { DeleteOutlined } from '@ant-design/icons';

import masterService from "../../../../services/MasterService";
import leadsService from "../../../../services/LeadsServices";
import { useNavigate, useSearchParams } from 'react-router-dom';
import dayjs from 'dayjs';
import DataDisplayWidget from "components/shared-components/DataDisplayWidget";
import { BASE_URL_IMAGE } from "configs/AppConfig";
import style from "react-syntax-highlighter/dist/esm/styles/hljs/a11y-dark";
import Flex from "components/shared-components/Flex";
import { useSelector } from "react-redux";
import { YEARS, MONTHS } from "constants/AuthConstant";



const ADD = "ADD";
const EDIT = "EDIT";
const { Option } = Select;

const ApplicationList = () => {
    const dateFormat = 'DD/MM/YYYY';
    const navigate = useNavigate();
    const [form] = Form.useForm();
    const [submitLoading, setSubmitLoading] = useState(false);
    const [countryList, setCountryList] = useState([]);
    const [statusShow, setStatusShow] = useState(false);
    const [show, setShow] = useState(false)
    const [courseList, setCourseList] = useState([]);
    const [courseTypeList, setCourseTypeList] = useState([]);
    const [showForm, setShowForm] = useState(true)
    const [shortList, setShortlist] = useState([])
    const [shortListApplied, setShortlistApplied] = useState([])
    const [intakeValue, setIntakeValue] = useState([])
    const [btnShowHide, setBtnShowHide] = useState({ add: 0, view: 0, delete: 0 });
    const auth_details = JSON.parse(useSelector(state => state.auth.auth_details))
    const [searchParams] = useSearchParams();
    const [listAll, setListAll] = useState([]);
    const [record, setrecord] = useState(1);


    const shortlistData = (page, pageSize,) => {
        //const reqeustParam = { is_active: 1 }
        try {
            let reqeustParamagent, reqeustParammonth, reqeustParamapplication_status, reqeustParamcountry_id, reqeustParamintake_year, reqeustParamstudent_status;
            if (searchParams.get('agent_id') && searchParams.get('agent_id') != 0) {
                reqeustParamagent = {
                    agent_id: decodeURI(searchParams.get('agent_id'))
                }

            }
            if (searchParams.get('intake_month') && searchParams.get('intake_month') != 0) {
                reqeustParammonth = {
                    intake_month: decodeURI(searchParams.get('intake_month'))
                }

            }
            if (searchParams.get('application_status') && searchParams.get('application_status') != 0) {
                reqeustParamapplication_status = {
                    application_status: decodeURI(searchParams.get('application_status'))
                }

            }
            if (searchParams.get('country_id') && searchParams.get('country_id') != 0) {
                reqeustParamcountry_id = {
                    country_id: decodeURI(searchParams.get('country_id'))
                }

            }
            if (searchParams.get('intake_year') && searchParams.get('intake_year') != 0) {
                reqeustParamintake_year = {
                    intake_year: decodeURI(searchParams.get('intake_year'))
                }

            }
            if (searchParams.get('student_status') && searchParams.get('student_status') != 0) {
                reqeustParamstudent_status = {
                    student_status: decodeURI(searchParams.get('student_status'))
                }

            }

            let reqeustParam = {
                page: page,
                pageSize: pageSize,
                ...reqeustParamagent,
                ...reqeustParammonth,
                ...reqeustParamapplication_status,
                ...reqeustParamcountry_id,
                ...reqeustParamintake_year,
                ...reqeustParamstudent_status
            }
            const resp = masterService.getDashboardFilter(reqeustParam)
            resp.then(res => {
                //console.log(res.applications.data)
                setrecord(parseInt(res.applications.total));
                setShortlistApplied(res.applications.data)
                setListAll(res.applications.data);
                //setShortlistApplied(res.applications.data)


            })
                .catch(err => {

                })


        } catch (errors) {
            console.log(errors)
        }
    }


    useEffect(() => {

        shortlistData(1, 10);

        const addPermission = auth_details.role_permissions.filter((listPer) => listPer.id === 49)
        const viewPermission = auth_details.role_permissions.filter((listPer) => listPer.id === 52)
        const delPermission = auth_details.role_permissions.filter((listPer) => listPer.id === 51)
        setBtnShowHide({ add: addPermission.length, view: viewPermission.length, delete: delPermission.length })


    }, []);


    let i = 1;
    const imgsrc = `${BASE_URL_IMAGE}/img/avatars/thumb-1.jpg`;


    const columnsapp = [
        {
            title: "Sr. No.",
            render: (_, elm, index) => index + 1,
        },
        {
            title: 'Name',
            dataIndex: '',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.student.first_name} {elm.student.middle_name} {elm.student.last_name}
                    
                </div>

            )
        },
        {
            title: 'Status',
            dataIndex: 'status',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.get_status_name}

                </div>

            )
        },
        
        {
            title: 'App #',
            dataIndex: 'application_no',
        },
        {
            title: 'School',
            dataIndex: 'school',
            render: (_, elm) => (
                <div className="text-left">
                    {
                        elm.college_course.college.name
                    }
                </div>

            )
        },
        {
            title: 'Program',
            dataIndex: 'program',
            render: (_, elm) => (
                <div className="text-left">
                    {
                        elm.college_course.course.name
                    }
                </div>

            )
        },

        {
            title: 'Intake Month',
            dataIndex: 'req',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.intake_month}
                </div>

            )

        },
        {
            title: 'Intake Year',
            dataIndex: 'req',
            render: (_, elm) => (
                <div className="text-left">
                    {elm.intake_year}
                </div>

            )

        },
        {
            title: '',
            dataIndex: 'action',
            render: (_, elm) => (
                <div className="text-left">
                    {btnShowHide.view > 0 &&
                        <Tooltip title="View">
                            <Button type="primary" className="mr-2 px-4" onClick={() => navigate(`/dashboards/application-detail/${elm.id}`)} size="small"> View </Button>
                        </Tooltip>
                    }


                </div>

            )
        },

    ];

    const nexPageData = (page, pageSize) => {
        shortlistData(page, pageSize);
    };

    return (
        <>
            <Card title={`Applications`}>
                <hr />
                <div className="table-responsive">
                    <Table
                        key={i++}
                        columns={columnsapp}
                        dataSource={shortListApplied}
                        rowKey='id'
                        pagination={false}



                    />
                    <div className="text-right mt-3">
                        <Pagination
                            defaultCurrent={1}
                            total={record}
                            onChange={nexPageData}
                            defaultPageSize={10}
                            hideOnSinglePage
                            pageSizeOptions={[10, 50, 100, 500]}
                        />
                    </div>
                </div>
            </Card>

        </>
    );
};

export default ApplicationList;
