import React, { useState, useEffect } from "react";
import {
  Row,
  Col,
  Card,
  Table,
  Input,
  Button,
  Tooltip,
  Tag,
  Modal,
  notification,
  Breadcrumb,
  Pagination,
  Popover,
  Select
} from "antd";
import {
  DeleteOutlined,
  SearchOutlined,
  PlusCircleOutlined,
  EyeOutlined,
  EditOutlined
} from "@ant-design/icons";
import Flex from "components/shared-components/Flex";
import { useNavigate, useSearchParams } from "react-router-dom";
import utils from "utils";
//import { getCourseType } from '../../../../services/MasterService';
import leadsService from "../../../../services/LeadsServices";
import { useSelector } from "react-redux";
import StudentStatusForm from "./studentstatusform";
import SettingService from "services/SettingService";
import masterService from "services/MasterService";
const { Search } = Input;
const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
  return (
    <Modal
      destroyOnClose={true}
      title="Student"
      open={visible}
      okText="OK"
      onCancel={onCancelConfirm}
      onOk={() => {
        onOKConfirm();
      }}
    >
      Are you sure want to delete this item?
    </Modal>
  );
};
const ConfirmationBoxPartner = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
  return (
    <Modal
      destroyOnClose={true}
      title="Assign To"
      open={visible}
      okText="OK"
      onCancel={onCancelConfirm}
      onOk={() => {
        onOKConfirm();
      }}
    >
      Are you sure want to assign this lead?
    </Modal>
  );
};



const StudentAllList = () => {
  const navigate = useNavigate();
  const [list, setList] = useState([]);
  const [modalVisibleConfirmation, setModalVisibleConfirmation] =
    useState(false);
  const [initialId, setInitialId] = useState(0);
  const [listAll, setListAll] = useState([]);
  const [record, setrecord] = useState(1);
  const [partnerList, setPartnerList] = useState([])
  const [selectedPartner, setSelectedPartner] = useState([])
  const [selectedValue, setSelectedValue] = useState("")
  const [modalVisibleConfirmationPartner, setModalVisibleConfirmationPartner] =
    useState(false);
  const [partnerId, setPartnerId] = useState(0)
  const [btnShowHide, setBtnShowHide] = useState({
    add: 0,
    detail: 0,
    delete: 0,
    statusupdate: 0
  });
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );
  const [searchParams] = useSearchParams();
  const { Option } = Select;

  const rowSelection = {
    selectedRowKeys: selectedPartner,
    onChange: (selectedRowKeys, selectedRows) => {
      //console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
      setSelectedPartner(selectedRowKeys)
    },
    getCheckboxProps: record => ({

      //disabled: record.name === 'Disabled User',
      // Column configuration not to be checked
      //name: record.name,
    }),

  };

  const listData = (page, pageSize, search = "") => {
    //const reqeustParam = { page:page, pageSize:pageSize, search:search };
    try {
      let reqeustParamagent, reqeustParammonth, reqeustParamapplication_status, reqeustParamcountry_id, reqeustParamintake_year, reqeustParamstudent_status;
      if (searchParams.get('agent_id') && searchParams.get('agent_id') != 0) {
        reqeustParamagent = {
          agent_id: decodeURI(searchParams.get('agent_id'))
        }

      }
      if (searchParams.get('intake_month') && searchParams.get('intake_month') != 0) {
        reqeustParammonth = {
          intake_month: decodeURI(searchParams.get('intake_month'))
        }

      }
      if (searchParams.get('application_status') && searchParams.get('application_status') != 0) {
        reqeustParamapplication_status = {
          application_status: decodeURI(searchParams.get('application_status'))
        }

      }
      if (searchParams.get('country_id') && searchParams.get('country_id') != 0) {
        reqeustParamcountry_id = {
          country_id: decodeURI(searchParams.get('country_id'))
        }

      }
      if (searchParams.get('intake_year') && searchParams.get('intake_year') != 0) {
        reqeustParamintake_year = {
          intake_year: decodeURI(searchParams.get('intake_year'))
        }

      }
      if (searchParams.get('student_status') && searchParams.get('student_status') != 0) {
        reqeustParamstudent_status = {
          student_status: decodeURI(searchParams.get('student_status'))
        }

      }

      let reqeustParam = {
        page: page,
        pageSize: pageSize,
        search: search,
        ...reqeustParamagent,
        ...reqeustParammonth,
        ...reqeustParamapplication_status,
        ...reqeustParamcountry_id,
        ...reqeustParamintake_year,
        ...reqeustParamstudent_status
      }

      //console.log(reqeustParam)
      const resp = masterService.getDashboardFilter(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.students.data.total)
          setrecord(parseInt(res.students.total));
          setList(res.students.data);
          setListAll(res.students.data);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };

  const listDataPartner = (roleId) => {
    const reqeustParam = { role_id: roleId };
    try {
      const resp = SettingService.getUser(reqeustParam);
      resp
        .then((res) => {
          setPartnerList(res.data)

        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    listData(1, 10);
    listDataPartner(3)
    const addPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 63
    );
    const detailPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 47
    );
    const delPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 48
    );
    const statusupdatePermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 92
    );
    setBtnShowHide({
      add: addPermission.length,
      detail: detailPermission.length,
      delete: delPermission.length,
      statusupdate: statusupdatePermission.length
    });
  }, []);

  const tableColumns = [
    {
      title: "Sr. No.",
      render: (_, elm, index) => index + 1,
    },
    {
      title: "Name",
      dataIndex: "name",
      render: (_, elm) => (
        <div className="text-left">
          {elm.first_name} {elm.middle_name} {elm.last_name}
        </div>
      ),
      sorter: (a, b) => utils.antdTableSorter(a, b, "name"),
    },
    {
      title: "Student Id",
      dataIndex: "student_id",

      sorter: (a, b) => utils.antdTableSorter(a, b, "student_id"),
    },
    {
      title: "Mobile",
      dataIndex: "mobile",

      sorter: (a, b) => utils.antdTableSorter(a, b, "mobile"),
    },
    {
      title: "Email",
      dataIndex: "email",

      sorter: (a, b) => utils.antdTableSorter(a, b, "email"),
    },
    {
      title: "Source",
      dataIndex: "source",
      render: (_, elm) => (
        elm.source
      ),
      sorter: (a, b) => utils.antdTableSorter(a, b, "status"),
    },
    {
      title: "Status",
      dataIndex: "status",
      render: (status) => (
        <Tag className="text-capitalize" color={status === 'Progress' ? "orange" : status === 'Arrived' ? "green" : 'red'}>
          {status}
        </Tag>
      ),
      sorter: (a, b) => utils.antdTableSorter(a, b, "status"),
    },

    {
      title: "Action",
      dataIndex: "actions",
      render: (_, elm) => (
        <Flex>
          {btnShowHide.detail > 0 && (
            <Tooltip title="View">
              <Button
                onClick={() => {
                  viewStudent(elm.id);
                }}
                type="primary"
                className="mr-2 bg-warning"
                icon={<EyeOutlined />}
                size="small"

              />
            </Tooltip>
          )}
          { /* btnShowHide.delete > 0 && (
            <Tooltip title="Delete">
              <Button
                type="primary"
                danger
                icon={<DeleteOutlined />}
                onClick={() => {
                  deleteStudent(elm.id);
                }}
                size="small"
                className="mr-2"
              />
            </Tooltip>
          )
          */
          }
          { /* btnShowHide.statusupdate > 0 && (
            <Popover content={<StudentStatusForm appid={elm.id} updateReload={updateReload} />} title="Status" trigger="click">
              <Button type="primary" className="bg-success" size="small" icon={<EditOutlined />} />
            </Popover>
          )
          */
          }

        </Flex>
      ),
    },
  ];

  const onSearch = (e) => {
    //console.log(e);
    const value = e;
    listData(1, 10, value);
  };

  const deleteStudent = (elm) => {
    //console.log(elm)
    setInitialId(elm);
    setModalVisibleConfirmation(true);
  };
  const onCancelConfirm = () => {
    setInitialId(0);
    setModalVisibleConfirmation(false);
  };

  const onOKConfirm = () => {
    const reqeustParam = { student_id: initialId };
    //console.log(initialId);
    const resp = leadsService.deleteStudent(reqeustParam);
    resp
      .then((res) => {
        if (res.status === 200) {
          setModalVisibleConfirmation(false);
          listData(1, 10);
          notification.success({
            message: "Student deleted successfully.",
          });
        }
      })
      .catch((err) => { });
  };

  const nexPageData = (page, pageSize) => {
    listData(page, pageSize);
  };

  const addStudent = () => {
    navigate(`/dashboards/student-add`);
  };
  const viewStudent = (id) => {
    navigate(`/dashboards/student-detail/${id}`, { state: { defalutApp: 1 } });
  };
  const updateReload = () => {
    listData(1, 10);
  }

  const assignPartner = (e) => {
    //console.log(e)
    //console.log(selectedPartner)
    if (e > 0) {
      if (selectedPartner.length > 0) {
        setPartnerId(e)
        setModalVisibleConfirmationPartner(true);



      } else {
        notification.warning({
          message: "Please select checkbox",
        });
      }
    }

  }
  const onOKConfirmPartner = () => {
    if (partnerId > 0) {
      const reqeustParam = { partner_id: partnerId, student_id: selectedPartner };
      //console.log(initialId);
      const resp = leadsService.studentAssign(reqeustParam);
      resp
        .then((res) => {
          if (res.status === 200) {
            setSelectedPartner([])
            setSelectedValue(null)
            setPartnerId(0)
            listData(1, 10);
            setModalVisibleConfirmationPartner(false);
            notification.success({
              message: res.message,
            });
          }
        })
        .catch((err) => { });
    } else {
      notification.warning({
        message: "Please select partner",
      });
    }


  }
  const onCancelConfirmPartner = () => {
    setSelectedPartner([])
    setSelectedValue(null)
    setPartnerId(0)
    setModalVisibleConfirmationPartner(false);
  };

  var i = 1;
  return (
    <>
      <Card title="Leads">
        <Row gutter={16} className="justify-content-between mb-4">
          <Col className="text-end mb-2" xs={24} sm={24} md={18}>
            { /* btnShowHide.add > 0 && (
              <Button
                onClick={addStudent}
                type="primary"
                icon={<PlusCircleOutlined />}
                className="mr-1"
              >
                Add Student
              </Button>
            )
            */

            }

            { /* <Select
              onChange={assignPartner}
              placeholder="Select Partner"
              defaultValue={selectedValue}
              value={selectedValue}
            >
              return (
              <Option value="">Select Partner</Option>
              <Option value="1">Direct Admission</Option>
              {partnerList &&
                partnerList.map((partnerList, index) => {
                  return (
                    <Option key={`partnerList${index}`} value={partnerList.id}>
                      {partnerList.name}
                    </Option>
                  )

                })}
              )
            </Select>
            */
            }

          </Col>
          <Col className="text-end mb-2" xs={24} sm={24} md={6}>
            <Search
              placeholder="Search"
              enterButton={<SearchOutlined />}
              onSearch={(e) => onSearch(e)}
              allowClear
            />
          </Col>
        </Row>
        <ConfirmationBox
          id={initialId}
          visible={modalVisibleConfirmation}
          onOKConfirm={onOKConfirm}
          onCancelConfirm={onCancelConfirm}
        />
        <ConfirmationBoxPartner
          id={0}
          visible={modalVisibleConfirmationPartner}
          onOKConfirm={onOKConfirmPartner}
          onCancelConfirm={onCancelConfirmPartner}
        />
        <div className="table-responsive mt-4">
          <Table
            key={i++}
            columns={tableColumns}
            dataSource={list}
            rowKey="id"
            pagination={false}
          /* rowSelection={{
            type: 'checkbox',
            ...rowSelection,
          }}
          */
          />
          <div className="text-right mt-3">
            <Pagination
              defaultCurrent={1}
              total={record}
              onChange={nexPageData}
              defaultPageSize={10}
              hideOnSinglePage
              pageSizeOptions={[10, 50, 100, 500]}
            />
          </div>
        </div>
      </Card>
    </>
  );
};

export default StudentAllList;
