import { Anchor, Button, Card, Col, Form, Modal, Row, Select, Spin, Timeline, message } from 'antd';
import StatisticWidget from 'components/shared-components/StatisticWidget';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import {
  CloseOutlined,
  CloudUploadOutlined,
  SearchOutlined,
  RightSquareOutlined,
  CheckCircleOutlined,
  CloudDownloadOutlined,
  DeleteOutlined,
  EyeOutlined,
  PlusCircleOutlined,
  EditOutlined,
  UploadOutlined,
  UserAddOutlined,
  ArrowRightOutlined,
  ReloadOutlined,
  ShoppingCartOutlined,
  RestOutlined,
  CheckOutlined
} from "@ant-design/icons";
import masterService from 'services/MasterService';
import SettingService from 'services/SettingService';
import DataDisplayWidget from 'components/shared-components/DataDisplayWidget';
import { YEARS, MONTHS } from "constants/AuthConstant";
import { STUDENT_STATUS_LIST } from "constants/AuthConstant";
import dayjs from "dayjs";

const { Option } = Select;
const DefaultDashboard = () => {
  const navigate = useNavigate()
  const [countryList, setCountryList] = useState([]);
  const [partnerList, setPartnerList] = useState([])
  const [showAppStaus, setShowAppStatus] = useState([])
  const [submitLoading, setSubmitLoading] = useState(false);
  const [countDashboard, setCountDashboard] = useState([])
  const [showLoader, setShowLoader] = useState(false);
  const [showColumn, setShowColumn] = useState(4)
  const [showSearchValue, setShowSearchValue] = useState([])
  const auth_details = JSON.parse(useSelector(state => state.auth.auth_details))
  const [form] = Form.useForm();
  const [btnShowHide, setBtnShowHide] = useState({
    add: 0,

  });
  const [modalVisibleConfirmation, setModalVisibleConfirmation] =
    useState(false);
  const [showMessagePop, setShowMessagePop] = useState('')


  const listCountryData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getCountry(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setCountryList(res.data);
        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };
  const listDataPartner = (roleId) => {
    const reqeustParam = { role_id: roleId };
    try {
      const resp = SettingService.getUser(reqeustParam);
      resp
        .then((res) => {
          setPartnerList(res.data)

        })
        .catch((err) => { });
    } catch (errors) {
      console.log(errors);
    }
  };
  const appStatusData = () => {
    //const reqeustParam = { is_active: 1 }
    try {

      //const studentId = parseInt(userDetail.id)
      const reqeustParam = { is_active: 1 }
      const resp = masterService.getGETStatus(reqeustParam);


      resp.then(res => {
        //console.log(res)
        setShowAppStatus(res.data)



      })
        .catch(err => {

        })

    } catch (errors) {
      console.log(errors)
    }
  }

  const appShowDashboard = () => {
    //const reqeustParam = { is_active: 1 }
    try {
      const reqeustParam = {}
      const resp = masterService.getDashboard(reqeustParam);
      resp.then(res => {
        setCountDashboard(res)

      })
        .catch(err => {

        })

    } catch (errors) {
      console.log(errors)
    }
  }

  const checkMembership = () => {
    const resp = SettingService.checkMembership({});
            resp
                .then((res) => {
                    
                  //console.log(res)
                  if(res.data.leftdays <= 15){
                    let dayyear = dayjs().year();
                    let daymonth = dayjs().month() + 1;
                    let daydate = dayjs().date();
                    let daytm = `${dayyear}-${daymonth}-${daydate}`
    
                    //console.log(daytm)
                    if(localStorage.getItem('popupdate') == daytm){ } else { 
                    
                    setShowMessagePop(res.message)
                    setModalVisibleConfirmation(true)
                    }
                  }
                    
                })
                .catch((err) => { });
  }

  useEffect(() => {
    //console.log(auth_details)
    if (!auth_details) {
      window.location.reload();
    } else if (auth_details.is_change == 0) {
      navigate('/dashboards/change-password')
    } else if (auth_details.user_type == 'student') {
      navigate(`/dashboards/student-detail/${auth_details.student_id}`)
    } 

    listCountryData()
    listDataPartner(3)
    appStatusData()
    appShowDashboard()
    //checkMembership()
    const addPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 1
    );
    setBtnShowHide({
      add: addPermission.length,
    });

    if (auth_details.parent_id == 1) {

    } else {
      setShowColumn(5)
    }
  }, [])

  const resetFormData = () => {
    form.resetFields();
    onFinish()

  };

  const onFinish = () => {
    setSubmitLoading(true);
    setShowLoader(true)
    form
      .validateFields()
      .then((values) => {
        setTimeout(() => {
          setSubmitLoading(false);
          const reqeustParam = {}
          const resp = masterService.getDashboard(values);
          resp.then(res => {
            setShowSearchValue(values)
            setCountDashboard(res)
            setShowLoader(false)

          })
            .catch(err => {

            })


        }, 1500);
      })
      .catch((info) => {
        setSubmitLoading(false);
        console.log("info", info);
        message.error("Please enter all required field ");
      });
  };

  const onFinishGoApp = (val,val2) => {

    let linkval;
    if (showSearchValue.agent_id) {
      linkval = `?agent_id=${showSearchValue.agent_id}`;
    } else {
      linkval = `?agent_id=0`;
    }
    if (showSearchValue.application_status) {
      if(val2 > 0){
        linkval += `&application_status=${val2}`;  
      } else {
      linkval += `&application_status=${showSearchValue.application_status}`;
      }
    } else {
      if(val2 > 0){
        linkval += `&application_status=${val2}`;  
      } else {
      linkval += `&application_status=0`;
      }
    }
    if (showSearchValue.country_id) {
      linkval += `&country_id=${showSearchValue.country_id}`;
    } else {
      linkval += `&country_id=0`;
    }
    if (showSearchValue.intake_month) {
      linkval += `&intake_month=${showSearchValue.intake_month}`;
    } else {
      linkval += `&intake_month=0`;
    }
    if (showSearchValue.intake_year) {
      linkval += `&intake_year=${showSearchValue.intake_year}`;
    } else {
      linkval += `&intake_year=0`;
    }
    if (showSearchValue.student_status) {
      linkval += `&student_status=${showSearchValue.student_status}`;
    } else {
      linkval += `&student_status=0`;
    }

    if(val == 2){
    navigate(`/dashboards/student-list${encodeURI(linkval)}`)
    }else{
      navigate(`/dashboards/application-list${encodeURI(linkval)}`)
    }

  }

  const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
    return (
      <Modal
        destroyOnClose={true}
        title="Subscription"
        open={visible}
        okText="OK"
        cancelText="No"
        onCancel={onCancelConfirm}
        onOk={() => {
          onOKConfirm();
        }}
      >
        {showMessagePop}
      </Modal>
    );
  };

  const onOKConfirm = () => {
            let dayyear = dayjs().year();
            let daymonth = dayjs().month() + 1;
            let daydate = dayjs().date();
            let daytm = `${dayyear}-${daymonth}-${daydate}`
    
    //console.log(daytm)
    localStorage.setItem('popupdate', daytm);
    setModalVisibleConfirmation(false);
  }
  const onCancelConfirm = () => {
    setModalVisibleConfirmation(false);
  };

  return (
    <>
      <ConfirmationBox
        visible={modalVisibleConfirmation}
        onOKConfirm={onOKConfirm}
        onCancelConfirm={onCancelConfirm}
      />
      
      {btnShowHide.add > 0 &&
        <Spin size="large" spinning={showLoader}>
          <Card>
            <Form
              layout="vertical"
              form={form}
              name="advanced_search"
              className="ant-advanced-search-form"
            >
              <div className="container123">
                <Row gutter={16}>
                  {auth_details.parent_id == 1 &&
                    <Col xs={24} sm={24} md={showColumn}>
                      <Form.Item
                        label="Source"
                        name="agent_id"
                        rules={[
                          {
                            required: false,
                            message: "Please select agent!",
                          },
                        ]}
                      >
                        <Select
                          showSearch
                          placeholder="Select Agent"
                          optionFilterProp="children"
                          filterOption={(input, option) =>
                            option.props.children
                              .toLowerCase()
                              .indexOf(input.toLowerCase()) >= 0
                          }
                        >

                          return (
                          <Option key={`partnerListAdmin`} value="1">
                            Direct Admission
                          </Option>
                          )
                          {partnerList &&
                            partnerList.map((partnerList, index) => {
                              return (
                                <Option key={`partnerList${index}`} value={partnerList.id}>
                                  {partnerList.name}
                                </Option>
                              )

                            })}

                        </Select>
                      </Form.Item>
                    </Col>
                  }
                  <Col xs={24} sm={24} md={showColumn}>
                    <Form.Item
                      label="Intake Month"
                      name="intake_month"
                      rules={[
                        {
                          required: false,
                          message: "Please select intake month!",
                        },
                      ]}
                    >
                      <Select
                        showSearch
                        placeholder="Select Intake"
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                          option.props.children
                            .toLowerCase()
                            .indexOf(input.toLowerCase()) >= 0
                        }
                      >

                        {MONTHS &&
                          MONTHS.map((month, index) => {
                            return (
                              <Option key={`month${index}`} value={month}>
                                {month}
                              </Option>
                            );
                          })}

                      </Select>
                    </Form.Item>
                  </Col>
                  <Col xs={24} sm={24} md={showColumn}>
                    <Form.Item
                      label="Intake Year"
                      name="intake_year"
                      rules={[
                        {
                          required: false,
                          message: "Please select intake!",
                        },
                      ]}
                    >
                      <Select
                        showSearch
                        placeholder="Select Intake"
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                          option.props.children
                            .toLowerCase()
                            .indexOf(input.toLowerCase()) >= 0
                        }
                      >

                        {YEARS &&
                          YEARS.map((year, index) => {
                            return (
                              <Option key={`year${index}`} value={year}>
                                {year}
                              </Option>
                            );
                          })}

                      </Select>
                    </Form.Item>
                  </Col>

                  <Col xs={24} sm={24} md={showColumn}>
                    <Form.Item
                      label="Destination"
                      name="country_id"
                      rules={[
                        {
                          required: false,
                          message: "Please select destination!",
                        },
                      ]}
                    >
                      <Select
                        showSearch
                        placeholder="Select Destination"
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                          option.props.children
                            .toLowerCase()
                            .indexOf(input.toLowerCase()) >= 0
                        }
                      >
                        {countryList &&
                          countryList.map((countrylist, index) => {
                            return (
                              <Option
                                key={`country${index}`}
                                value={countrylist.id}
                              >
                                {countrylist.name}
                              </Option>
                            );
                          })}
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col xs={24} sm={24} md={showColumn}>
                    <Form.Item
                      label="Student Status"
                      name="student_status"
                      rules={[
                        {
                          required: false,
                          message: "Please select student status!",
                        },
                      ]}
                    >
                      <Select
                        showSearch
                        placeholder="Select Student Status"
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                          option.props.children
                            .toLowerCase()
                            .indexOf(input.toLowerCase()) >= 0
                        }
                      >

                        {STUDENT_STATUS_LIST &&
                          STUDENT_STATUS_LIST.map((stdstatus, index) => {
                            return (
                              <Option
                                key={`studentstatus${index}`}
                                value={stdstatus}
                              >
                                {stdstatus}
                              </Option>
                            );
                          })}

                      </Select>
                    </Form.Item>
                  </Col>
                  <Col xs={24} sm={24} md={4}>
                    <Form.Item
                      label="Application Status"
                      name="application_status"
                      rules={[
                        {
                          required: false,
                          message: "Please select application status!",
                        },
                      ]}
                    >
                      <Select
                        showSearch
                        placeholder="Select Application Status"
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                          option.props.children
                            .toLowerCase()
                            .indexOf(input.toLowerCase()) >= 0
                        }
                      >

                        {showAppStaus &&
                          showAppStaus.map((showAppStaus, index) => {
                            return (
                              <Option
                                key={`appstatus${index}`}
                                value={showAppStaus.id}
                              >
                                {showAppStaus.name}
                              </Option>
                            );
                          })}

                      </Select>
                    </Form.Item>
                  </Col>
                </Row>
                <Row gutter={16} className='text-right'>
                  <Col xs={24} sm={24} md={24}>
                    <Form.Item

                    >
                      <Button
                        type="primary"
                        icon={<ReloadOutlined />}
                        onClick={(e) => resetFormData()}
                        className="bg-success mr-2 text-white"
                      >
                        Clear
                      </Button>
                      <Button
                        type="primary"
                        onClick={() => onFinish()}
                        htmlType="submit"
                        loading={submitLoading}
                        icon={<SearchOutlined />}

                      >
                        Search
                      </Button>
                    </Form.Item>
                  </Col>
                </Row>

                <Row gutter={16}>
                  <Col xs={24} sm={24} md={6}>
                    <a

                      onClick={() => onFinishGoApp(1,0)}
                    >
                      <DataDisplayWidget
                        icon={<EditOutlined />}
                        value={countDashboard.total_application}
                        title="Application"
                        color="blue"
                        vertical={true}
                        avatarSize={55}

                      />
                    </a>
                  </Col>
                  <Col xs={24} sm={24} md={6}>
                    <a

                      onClick={() => onFinishGoApp(2,0)}
                    >
                      <DataDisplayWidget
                        icon={<UserAddOutlined />}
                        value={countDashboard.total_student}
                        title="Students"
                        color="orange"
                        vertical={true}
                        avatarSize={55}
                      />
                    </a>
                  </Col>
                  {countDashboard.status && countDashboard.status.map((liststatus, index) => {
                    let icon, color;
                    if (liststatus.id === 8) {
                      icon = <ShoppingCartOutlined />
                      color = 'grey'
                    } else
                      if (liststatus.id === 9) {
                        icon = <RestOutlined />
                        color = 'red'
                      } else
                        if (liststatus.id === 10) {
                          icon = <CheckOutlined />
                          color = 'green'
                        } else
                          if (liststatus.id === 13) {
                            icon = <CheckCircleOutlined />
                            color = 'cyan'
                          } else
                            if (liststatus.id === 15) {
                              icon = <PlusCircleOutlined />
                              color = 'gold'
                            } else
                              if (liststatus.id === 16) {
                                icon = <ArrowRightOutlined />
                                color = 'pink'
                              } else {
                                icon = <PlusCircleOutlined />
                                color = 'gold'
                              }


                    return (
                      <Col xs={24} sm={24} md={6}>
                        <a

                          onClick={() => onFinishGoApp(1,liststatus.id)}
                        >
                          <DataDisplayWidget
                            icon={icon}
                            value={liststatus.applications}
                            title={liststatus.name}
                            color={color}
                            vertical={true}
                            avatarSize={55}
                          />
                        </a>
                      </Col>

                    )
                  })
                  }

                </Row>
              </div>
            </Form>

          </Card>

          { /* <Card>
        <Row gutter={16}>
          <Col xs={24} sm={24} md={24}>

            <Timeline>
              <Timeline.Item><a href="#components-anchor-demo-basic" target="_blank" style={{ color: '#455560' }}>market & university update</a></Timeline.Item>
              <Timeline.Item><a href="#components-anchor-demo-basic" target="_blank" style={{ color: '#455560' }}>market & university update</a></Timeline.Item>
              <Timeline.Item><a href="#components-anchor-demo-basic" target="_blank" style={{ color: '#455560' }}>market & university update</a></Timeline.Item>
              <Timeline.Item><a href="#components-anchor-demo-basic" target="_blank" style={{ color: '#455560' }}>market & university update</a></Timeline.Item>

            </Timeline>

          </Col>
        </Row>
      </Card>
            */ }
        </Spin>


      }

    </>
  )
}


export default DefaultDashboard;
