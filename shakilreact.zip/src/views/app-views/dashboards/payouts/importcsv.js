import React, { useState } from "react";
import { Button, message, Input, Row, Col, Card, Form } from "antd";
import PayoutService from "../../../../services/PayoutService";
import { useNavigate } from "react-router-dom";
const ADD = "ADD";

const PayoutImport = () => {
  const mode = ADD;
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [fileChanges, setFilechanges] = useState("");
  
  const onFinish = () => {
    setSubmitLoading(true);
    form
      .validateFields()
      .then((values) => {
        setTimeout(() => {
          const data = new FormData();
          data.append("file", fileChanges);
          try {
            const resp = PayoutService.importLayouts(data);
            resp
              .then((res) => {
                setSubmitLoading(false);
                message.success(`Layout successfully added.`);
                navigate(`/dashboards/payouts`);
              })
              .catch((err) => {
                message.error("Please upload valid data with valid format");
              });
          } catch (errors) {
            //
          }
        }, 1500);
      })
      .catch((info) => {
        setSubmitLoading(false);
        console.log("info", info);
        message.error("Please enter all required field ");
      });
  };

  const handleFileChange = (event) => {
    setFilechanges(event.target.files[0]);
  };

  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
        initialValues={{
          id: "",
          name: "",
          course_link: "",
        }}
      >
        <div className="container123">
          <Card title={`PAYOUTS IMPORT WITH CSV`}>
            <Row gutter={16}>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="logo" label="Upload CSV">
                  <Input type="file" onChange={handleFileChange} />
                </Form.Item>
              </Col>
            </Row>

            <Row>
              <Col xs={24} sm={24} md={12}>
                <Button
                  type="primary"
                  onClick={() => onFinish()}
                  htmlType="submit"
                  loading={submitLoading}
                >
                  {mode === "ADD" ? "Submit" : `Save`}
                </Button>
              </Col>
            </Row>
          </Card>
        </div>
      </Form>
    </>
  );
};

export default PayoutImport;
