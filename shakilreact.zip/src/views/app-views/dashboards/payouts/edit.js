import React, { useState, useEffect } from "react";
import { Button, message, Input, Row, Col, Card, Form, Select } from "antd";
import { useNavigate, useParams } from "react-router-dom";
import PayoutService from "services/PayoutService";
import universityService from "services/UniversityService";
const { Option } = Select;
const ADD = "ADD";
const EDIT = "EDIT";
const EditPayout = (props) => {
  const { mode = EDIT, param } = props;
  const navigate = useNavigate();
  const [list, setList] = useState([]);
  const [initialVal, setInitialVal] = useState({
    id: "",
    college_id: "",
    country: "",
    payout_agent: "",
    ug_payout: "",
    pg_payout: "",
    comment: "",
    payout_type: "",
  });
  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const params = useParams();
  const { TextArea } = Input;

  const listCollegesData = () => {
    const reqeustParam = { is_active: 1 };
    try {
      const resp = universityService.getCollegeList(reqeustParam);
      resp
        .then((res) => {
          setList(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    listCollegesData();
    if (mode === EDIT) {
      const reqeustParam = { payout_id: params.payout_id };
      const resp = PayoutService.editPayout(reqeustParam);
      resp
        .then((res) => {
          form.setFieldsValue({
            college_id:
              res.data.college_id === "undefined" ? "" : res.data.college_id,
            country: res.data.country === "undefined" ? "" : res.data.country,
            payout_agent:
              res.data.payout_agent === "undefined"
                ? ""
                : res.data.payout_agent,
            ug_payout:
              res.data.ug_payout === "undefined" ? "" : res.data.ug_payout,
            pg_payout:
              res.data.pg_payout === "undefined" ? "" : res.data.pg_payout,
            comment: res.data.comment === "undefined" ? "" : res.data.comment,
            payout_type:
              res.data.payout_type === "undefined" ? "" : res.data.payout_type,
          });
        })
        .catch((err) => {});
    }
  }, [form, mode, param, props]);

  const onFinish = () => {
    setSubmitLoading(true);
    form
      .validateFields()
      .then((values) => {
        setTimeout(() => {
          setSubmitLoading(false);
          if (mode === ADD) {
            const resp = PayoutService.AddPayout(values);
            resp
              .then((res) => {
                message.success(res.message);
                navigate(`/dashboards/payouts`);
              })
              .catch((err) => {});
          }
          if (mode === EDIT) {
            const data = {
              ...values,
              payout_id: params.payout_id,
            };
            const resp = PayoutService.updatePayout(data);
            resp
              .then((res) => {
                message.success(res.message);
                navigate(`/dashboards/payouts`);
              })
              .catch((err) => {});
          }
        }, 1500);
      })
      .catch((info) => {
        setSubmitLoading(false);
        message.error("Please enter all required field ");
      });
  };

  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
      >
        <div className="container123">
          <Card title="Payout Edit">
            <hr />
            <Row className="pt-5 px-lg-5" gutter={16}>
              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  label="college"
                  name="college_id"
                  rules={[
                    {
                      required: true,
                      message: "Please select college!",
                    },
                  ]}
                >
                  <Select
                    showSearch
                    placeholder="Select college"
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                      option.props.children
                        .toLowerCase()
                        .indexOf(input.toLowerCase()) >= 0
                    }
                  >
                    {list &&
                      list.map((list, index) => {
                        return (
                          <Option key={`college${index}`} value={list.id}>
                            {list.name}
                          </Option>
                        );
                      })}
                  </Select>
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="country" label="Country">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="payout_agent" label="Payout Agent">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="ug_payout"
                  label="UG Payout"
                  rules={[
                    {
                      required: true,
                      message: "Please enter country!",
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="pg_payout"
                  label="PG Payout"
                  rules={[
                    {
                      required: true,
                      message: "Please enter country!",
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="payout_type"
                  label="Payout Type"
                  rules={[
                    {
                      required: true,
                      message: "Please enter country!",
                    },
                  ]}
                >
                  <Select placeholder="Please choose a payout type">
                    <Option key="1" value="percentage">
                      Percentage
                    </Option>
                    <Option key="2" value="fixed">
                      Fixed
                    </Option>
                  </Select>
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={24}>
                <Form.Item name="comment" label="Comment" className="mb-0">
                  <TextArea minRows={2} />
                </Form.Item>
              </Col>
            </Row>

            <Row className="px-lg-5 mt-4">
              <Col xs={24} sm={24} md={12}>
                <Button
                  className="px-5"
                  type="primary"
                  htmlType="submit"
                  loading={submitLoading}
                  onClick={() => onFinish()}
                >
                  Save
                </Button>
              </Col>
            </Row>
          </Card>
        </div>
      </Form>
    </>
  );
};

export default EditPayout;
