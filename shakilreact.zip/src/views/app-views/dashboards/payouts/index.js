import React, { useState, useEffect } from "react";
import {
  Card,
  Table,
  Input,
  Button,
  Tooltip,
  Modal,
  notification,
  Row,
  Col,
  Checkbox,
} from "antd";
import {
  DeleteOutlined,
  SearchOutlined,
  PlusCircleOutlined,
  EditOutlined,
  FileExcelOutlined,
} from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import utils from "utils";
import PayoutService from "services/PayoutService";
import { useSelector } from "react-redux";

const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
  return (
    <Modal
      destroyOnClose={true}
      title="Course Type"
      open={visible}
      okText="OK"
      onCancel={onCancelConfirm}
      onOk={() => {
        onOKConfirm();
      }}
    >
      Are you sure want to delete this item?
    </Modal>
  );
};

const Payouts = () => {
  const navigate = useNavigate();
  const [list, setList] = useState([]);
  const [ids, setIds] = useState([]);
  const [initialVal, setInitialVal] = useState({
    name: "",
    status: "",
    date_from: "",
    date_to: "",
    agent: "",
  });
  const [modalVisibleConfirmation, setModalVisibleConfirmation] =
    useState(false);
  const [initialId, setInitialId] = useState(0);
  const [listAll, setListAll] = useState([]);
  const [btnShowHide, setBtnShowHide] = useState({
    add: 0,
    edit: 0,
    delete: 0,
    upload: 0,
  });
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );

  const listData = () => {
    const reqeustParam = initialVal;
    try {
      const resp = PayoutService.getPayout(reqeustParam);
      resp
        .then((res) => {
          setList(res.data);
          setListAll(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    listData();
    const addPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 88
    );
    const editPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 89
    );
    const delPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 90
    );
    const uploadPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 91
    );
    setBtnShowHide({
      add: addPermission.length,
      edit: editPermission.length,
      delete: delPermission.length,
      upload: uploadPermission.length,
    });
  }, []);

  const tableColumns = [
    {
      title: "Sr. No.",
      render: (_, elm, index) => (
        <>
          {index + 1}
          <Checkbox
            className="ml-2"
            onClick={() => {
              deleteIds(elm.id);
            }}
          ></Checkbox>
        </>
      ),
    },
    {
      title: "College Name",
      dataIndex: "college_name",
      sorter: (a, b) => utils.antdTableSorter(a, b, "college_name"),
    },
    {
      title: "Country",
      dataIndex: "country",
      sorter: (a, b) => utils.antdTableSorter(a, b, "country"),
    },
    {
      title: "Payout Agent",
      dataIndex: "payout_agent",
      sorter: (a, b) => utils.antdTableSorter(a, b, "payout_agent"),
    },
    {
      title: "UG Payout",
      render: (_, elm) => (
        <>
          {elm.ug_payout}
          {elm.payout_type == "fixed" ? " USD flat" : "%"}
        </>
      ),
      sorter: (a, b) => utils.antdTableSorter(a, b, "ug_payout"),
    },
    {
      title: "PG Payout",
      render: (_, elm) => (
        <>
          {elm.ug_payout}
          {elm.payout_type == "fixed" ? " USD flat" : "%"}
        </>
      ),
      sorter: (a, b) => utils.antdTableSorter(a, b, "pg_payout"),
    },
    {
      title: "Comment",
      dataIndex: "comment",
      sorter: (a, b) => utils.antdTableSorter(a, b, "comment"),
    },
    {
      title: "Action",
      dataIndex: "actions",
      render: (_, elm) => (
        <div className="text-left">
          {btnShowHide.edit > 0 && (
            <Tooltip title="Edit">
              <Button
                type="primary"
                className="mr-2"
                icon={<EditOutlined />}
                onClick={() => {
                  showEditVaue(elm);
                }}
                size="small"
              />
            </Tooltip>
          )}
          {btnShowHide.delete > 0 && (
            <Tooltip title="Delete">
              <Button
                danger
                icon={<DeleteOutlined />}
                onClick={() => {
                  deleteCourse(elm.id);
                }}
                size="small"
              />
            </Tooltip>
          )}
        </div>
      ),
    },
  ];

  const deleteIds = (id) => {
    let payout_id = id;
    const idData = ids;
    if (idData.indexOf(payout_id) > -1 === false) {
      idData.push(payout_id);
    } else {
      var index = idData.indexOf(payout_id);
      if (index !== -1) {
        idData.splice(index, 1);
      }
    }
    setIds(idData);
  };

  const showEditVaue = (elm) => {
    let payout_id = elm.id;
    navigate(`/dashboards/payouts/edit/${payout_id}`);
  };

  const excelImport = () => {
    navigate(`/dashboards/payouts/import-csv`);
  };

  const deleteCourse = (elm) => {
    setInitialId(elm);
    setModalVisibleConfirmation(true);
  };
  const onCancelConfirm = () => {
    if (initialId != 0) {
      setInitialId(0);
    }
    setModalVisibleConfirmation(false);
  };

  const onSearch = (e) => {
    const value = e.currentTarget.value;
    const searchArray = e.currentTarget.value ? listAll : listAll;
    const data = utils.wildCardSearch(searchArray, value);
    setList(data);
  };

  const onOKConfirm = () => {
    let value = initialId == 0 ? ids : initialId;
    const reqeustParam = { payout_id: value };
    const resp = PayoutService.deletePayout(reqeustParam);
    resp
      .then((res) => {
        if (res.status === 200) {
          setModalVisibleConfirmation(false);
          listData();
          notification.success({ message: res.message });
        }
      })
      .catch((err) => {});
  };

  const onDelete = () => {
    if (ids.length === 0) {
      notification.error({ message: "Please select layouts." });
    } else {
      setModalVisibleConfirmation(true);
    }
  };

  return (
    <Card>
      <h5>
        <u>
          <SearchOutlined /> Filter Payouts
        </u>
      </h5>
      <Row gutter={16} className="justify-content-between my-4">
        <Col className="text-end mb-2" xs={24} sm={24} md={18}>
          {btnShowHide.delete > 0 && (
            <Button
              type="primary"
              icon={<DeleteOutlined />}
              danger
              onClick={() => {
                onDelete();
              }}
              className="mb-1"
            >
              Delete Payout
            </Button>
          )}
          {btnShowHide.add > 0 && (
            <Button
              type="primary"
              icon={<PlusCircleOutlined />}
              className="mx-1"
              onClick={() => {
                excelImport();
              }}
            >
              Add Payout
            </Button>
          )}
          {btnShowHide.upload > 0 && (
            <Button
              style={{ width: "140px" }}
              type="primary"
              icon={<FileExcelOutlined />}
              className="bg-success "
            >
              Export
            </Button>
          )}
        </Col>
        <Col xs={24} sm={24} md={6}>
          <Input
            placeholder="Search"
            prefix={<SearchOutlined />}
            onChange={(e) => onSearch(e)}
          />
        </Col>
      </Row>
      <div>
        <ConfirmationBox
          id={initialId}
          visible={modalVisibleConfirmation}
          onOKConfirm={onOKConfirm}
          onCancelConfirm={onCancelConfirm}
        />
      </div>
      <div className="table-responsive">
        <Table columns={tableColumns} dataSource={list} rowKey="id" />
      </div>
    </Card>
  );
};

export default Payouts;
