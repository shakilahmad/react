import React, { useState, useEffect } from "react";
import {
    Row,
    Col,
    Card,
    Table,
    Input,
    Button,
    Tooltip,
    Tag,
    Modal,
    Form,
    Switch,
    notification,
    Select,
    Pagination,
} from "antd";
import {
    DeleteOutlined,
    SearchOutlined,
    PlusCircleOutlined,
    EditOutlined,
    EyeOutlined
} from "@ant-design/icons";
import Flex from "components/shared-components/Flex";
import { useNavigate } from "react-router-dom";
import utils from "utils";
//import { getCourseType } from '../../../../services/MasterService';
import masterService from "../../../../services/MasterService";
import SettingService from "services/SettingService";
import { connect, useDispatch, useSelector } from "react-redux";
import leadsService from "services/LeadsServices";
import { navheaderList, navheaderListAll } from "store/slices/navheaderSlice";


const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
    return (
        <Modal
            destroyOnClose={true}
            title="Course Type"
            open={visible}
            okText="OK"
            onCancel={onCancelConfirm}
            onOk={() => {
                onOKConfirm();
            }}
        >
            Are you sure want to delete this item?
        </Modal>
    );
};

const CommentList = (props) => {
    const [list, setList] = useState([]);
    const [modalVisible, setModalVisible] = useState(false);
    const [statusShow, setStatusShow] = useState(false);
    const [initialVal, setInitialVal] = useState({
        id: "",

    });
    const [modalVisibleConfirmation, setModalVisibleConfirmation] =
        useState(false);
    const [initialId, setInitialId] = useState(0);
    const [listAll, setListAll] = useState([]);
    const [listCourseAll, setListCourseAll] = useState([]);
    const [record, setrecord] = useState(1);
    const [btnShowHide, setBtnShowHide] = useState({
        add: 0,
        edit: 0,
        delete: 0,
    });
    const auth_details = JSON.parse(
        useSelector((state) => state.auth.auth_details)
    );
    const navigate = useNavigate()
    const dispatch = useDispatch()
  const navheaderlist = useSelector((state) => state.navheaderlist)
  
  const {
    loading,
    showMessage,
    navheaderListAll
  } = props


    const listData = (page, pageSize) => {
        const reqeustParam = { page: page, pageSize: pageSize };
        try {
            const resp = leadsService.getHeaderNofification(reqeustParam);
            resp
                .then((res) => {
                    setrecord(res.data.total);
                    setList(res.data.data);
                    setListAll(res.data.data);
                })
                .catch((err) => { });
        } catch (errors) {
            console.log(errors);
        }
    };
    const nexPageData = (page, pageSize) => {
        listData(page, pageSize);
    };

    useEffect(() => {
        listData();
        const addPermission = auth_details.role_permissions.filter(
            (listPer) => listPer.id === 95
        );
        const editPermission = auth_details.role_permissions.filter(
            (listPer) => listPer.id === 95
        );
        const delPermission = auth_details.role_permissions.filter(
            (listPer) => listPer.id === 96
        );
        setBtnShowHide({
            add: addPermission.length,
            edit: editPermission.length,
            delete: delPermission.length,
        });
    }, []);

    const tableColumns = [

        {
            title: "Sr. No.",
            render: (_, elm, index) => index + 1,
        },
        {
            title: "Name",
            dataIndex: "name",
            render: (_, elm) => (
                <>
                    {elm.student?.first_name} {elm.student?.middle_name} {elm.student?.last_name}
                </>
            ),

            sorter: (a, b) => utils.antdTableSorter(a, b, "name"),
        },
        {
            title: "Subject",

            dataIndex: "subject",

            sorter: (a, b) => utils.antdTableSorter(a, b, "subject"),
        },
        {
            title: "Description",

            dataIndex: "description",

            sorter: (a, b) => utils.antdTableSorter(a, b, "description"),
        },
        {
            title: "Email",
            dataIndex: "email",

            sorter: (a, b) => utils.antdTableSorter(a, b, "email"),
        },
        {
            title: "Date",
            //dataIndex: "date",
            render: (_, elm) => (
                <>{elm.date}</>
            ),

            sorter: (a, b) => utils.antdTableSorter(a, b, "date"),
        },
        {
            title:"Status",
            dataIndex: "status",
            

            sorter: (a, b) => utils.antdTableSorter(a, b, "status"),
        },
        {
            title: "Action",
            dataIndex: "actions",
            render: (_, elm) => (
                <Flex>

                    
                        <Tooltip title="View">
                            <Button
                                type="primary"
                                className="bg-warning"
                                icon={<EyeOutlined />}
                                onClick={() => {
                                    showView(elm);
                                }}
                                size="small"
                            />
                        </Tooltip>
                    

                </Flex>
            ),
        },
    ];

    const onSearch = (e) => {
        //console.log(e.currentTarget.value);
        const value = e.currentTarget.value;
        const searchArray = e.currentTarget.value ? listAll : listAll;
        const data = utils.wildCardSearch(searchArray, value);
        setList(data);
    };

    const showModal = () => {
        setModalVisible(true);
    };

    const closeModal = () => {
        setInitialVal({
            id: "",
        });
        setModalVisible(false);
        setStatusShow(false);
    };

    const deleteCourse = (elm) => {
        //console.log(elm)
        setInitialId(elm);
        setModalVisibleConfirmation(true);
    };
    const onCancelConfirm = () => {
        setInitialId(0);
        setModalVisibleConfirmation(false);
    };

    const onOKConfirm = () => {
        const reqeustParam = { notification_id: initialId };
        //console.log(initialId)
        const resp = leadsService.deleteNotification(reqeustParam);
        resp
            .then((res) => {
                if (res.status === 200) {
                    setModalVisibleConfirmation(false);
                    listData();
                    notification.success({ message: "Notification deleted successfully." });
                }
            })
            .catch((err) => { });

    };

    const showView = (values) => {
        //console.log(values)
        /* if (values.type == 'APPLICATION' || values.type == 'APPLICATION_STATUS') {
            navigate(`/dashboards/application-detail/${values.type_id}`, { state: { defalutApp: 1 } });
        } else if (values.type == 'LEADS') {
          navigate(`/dashboards/student-detail/${values.type_id}`, { state: { defalutApp: 1 } });  
        }
        */
        const resp = leadsService.noticeRead({notification_id:values.id});
        resp
          .then((res) => {
            navheaderListAll()
          })
          .catch((err) => {});
        
       if(values.application_id > 0){
        navigate(`/dashboards/application-detail/${values.application_id}`);
       } else {

        navigate(`/dashboards/student-detail/${values.student.id}`);
       }

    }


    return (
        <Card>
            <Row gutter={16} className="justify-content-between my-4">
                <Col className="text-end mb-2" xs={24} sm={24} md={18}></Col>
                <Col className="text-end mb-2" xs={24} sm={24} md={6}>
                    <Input
                        placeholder="Search"
                        prefix={<SearchOutlined />}
                        onChange={(e) => onSearch(e)}
                    />
                </Col>
            </Row>

            <ConfirmationBox
                id={initialId}
                visible={modalVisibleConfirmation}
                onOKConfirm={onOKConfirm}
                onCancelConfirm={onCancelConfirm}
            />
            <div className="table-responsive">
                <Table
                    columns={tableColumns}
                    dataSource={list}
                    rowKey="id"
                    pagination={false}
                />
                <div className="text-right mt-3">
                    <Pagination
                        defaultCurrent={1}
                        total={record}
                        onChange={nexPageData}
                        defaultPageSize={50}
                        hideOnSinglePage
                        pageSizeOptions={[10, 50, 100, 500]}
                    />
                </div>
            </div>
        </Card>
    );
};

const mapStateToProps = ({ navheaderlist }) => {
    const { loading, message, list } = navheaderlist;
    return { loading, message, list }
  }
  
  const mapDispatchToProps = {
    navheaderListAll
  
  }
  
  export default connect(mapStateToProps, mapDispatchToProps)(CommentList);
//export default CommentList;
