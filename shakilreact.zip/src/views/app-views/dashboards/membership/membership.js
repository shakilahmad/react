import React, { useState, useEffect } from "react";
import {
    Row,
    Col,
    Card,
    Table,
    Input,
    Button,
    Tooltip,
    Tag,
    Modal,
    Form,
    Switch,
    notification,
    Result,
} from "antd";
import {
    DeleteOutlined,
    SearchOutlined,
    PlusCircleOutlined,
    EditOutlined,
    IdcardOutlined
} from "@ant-design/icons";
import Flex from "components/shared-components/Flex";
import { } from "react-router-dom";
import utils from "utils";
//import { getCourseType } from '../../../../services/MasterService';
import masterService from "../../../../services/MasterService";
import { useSelector } from "react-redux";
import SettingService from "services/SettingService";


const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
    return (
        <Modal
            destroyOnClose={true}
            title="Status Name"
            open={visible}
            okText="OK"
            onCancel={onCancelConfirm}
            onOk={() => {
                onOKConfirm();
            }}
        >
            Are you sure want to delete this item?
        </Modal>
    );
};

const Membsership = () => {
    const [list, setList] = useState([]);
    const [modalVisible, setModalVisible] = useState(false);
    const [statusShow, setStatusShow] = useState(false);
    const [initialVal, setInitialVal] = useState({ id: "", name: "" });
    const [modalVisibleConfirmation, setModalVisibleConfirmation] =
        useState(false);
    const [initialId, setInitialId] = useState(0);
    const [listAll, setListAll] = useState([]);
    const [btnShowHide, setBtnShowHide] = useState({ add: 0, edit: 0, delete: 0 });
    const auth_details = JSON.parse(useSelector(state => state.auth.auth_details))

    const listData = () => {
        const reqeustParam = {};
        try {
            const resp = SettingService.checkMembership(reqeustParam);
            resp
                .then((res) => {
                    //console.log(res)
                    setList(res);
                    //setListAll(res.data);
                })
                .catch((err) => { });
        } catch (errors) {
            console.log(errors);
        }
    };

    useEffect(() => {
        listData();

    }, []);



    var i = 1;
    return (
        <Card title="Subscription">

            <Result
                status="warning"
                title={list.message}
                icon={<IdcardOutlined />}
                //subTitle={list.data?.expiry_date}
                //extra={}
            />
        <br></br>
        <br></br>
        <br></br>
        
        </Card>
    );
};

export default Membsership;
