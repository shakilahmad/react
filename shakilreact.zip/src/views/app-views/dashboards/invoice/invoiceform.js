import React, { useState, useEffect } from "react";
import { Button, Input, Row, Col, Card, Form, Select, DatePicker } from "antd";
const { Option } = Select;

const InvoiceForm = (props) => {
  const dateFormat = "DD/MM/YYYY";
  var today = new Date();
  const todayDate = today.getDate() + "/" + (today.getMonth() + 1) + "/" + today.getFullYear();
  const [invoice_type, setInvoiceType] = useState("service-invoice");
  const { inputChange, netAmount, saleDueAmount } = props;
  const { TextArea } = Input;
  return (
    <>
      <Row className="pt-4" gutter={16}>
        <Col xs={24} sm={24} md={12}>
          <Form.Item
            label="Invoice Type"
            name="invoice_type"
            rules={[
              {
                required: true,
                message: "Please select invoice type!",
              },
            ]}
          >
            <Select
              placeholder="Select invoice type"
              onChange={(e) => setInvoiceType(e)}
            >
              <Option key={`invoice_type1`} value="service-invoice">
                Service Invoice
              </Option>
              <Option key={`invoice_type2`} value="university-invoice">
                University Invoice
              </Option>
            </Select>
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={12}>
          <Form.Item
            name="invoice_date"
            label="Invoice Date"
            rules={[
              {
                required: true,
                message: "Please select invoice date!",
              },
            ]}
          >
            <DatePicker format={dateFormat} className="w-100" />
          </Form.Item>
        </Col>

        <Col xs={24} sm={24} md={12}>
          <Form.Item
            name="service_name"
            label="Service Name"
            rules={[
              {
                required: true,
                message: "Please enter service name!",
              },
            ]}
          >
            <Input />
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={12}>
          <Form.Item
            label="Invoice To"
            name="invoice_to"
            rules={[
              {
                required: true,
                message: "Please enter invoice to!",
              },
            ]}
          >
            <Input />
          </Form.Item>
        </Col>

        {invoice_type == "university-invoice" ? (
          <>
            <Col xs={24} sm={24} md={12}>
              <Form.Item name="university_amount" label="University Amount">
                <Input />
              </Form.Item>
            </Col>

            <Col xs={24} sm={24} md={12}>
              <Form.Item
                name="university_percentage"
                label="Commission Percentage"
              >
                <Input />
              </Form.Item>
            </Col>
          </>
        ) : (
          <></>
        )}

        <Col xs={24} sm={24} md={24}>
          <Form.Item name="total_amount" label="Total Amount">
            <Input
              onChange={inputChange("total_amount")}
              rules={[
                {
                  required: true,
                  message: "Please enter total amount!",
                },
              ]}
            />
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={12}>
          <Form.Item name="first_tax_name" label="First Tax Name">
            <Input />
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={12}>
          <Form.Item name="first_tax_amount" label="First Tax Amount">
            <Input onChange={inputChange("first_tax_amount")} />
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={12}>
          <Form.Item name="second_tax_name" label="Second Tax Name">
            <Input />
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={12}>
          <Form.Item name="second_tax_amount" label="Second Tax Amount">
            <Input onChange={inputChange("second_tax_amount")} />
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={12}>
          <Form.Item name="net_amount" label="Net Amount">
            <Input value={netAmount} disabled />{" "}
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={12}>
          <Form.Item name="gst_number" label="Customer GST Number">
            <Input />
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={12}>
          <Form.Item name="due_amount" label="Due Amount">
            <Input onChange={inputChange("due_amount")} />
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={12}>
          <Form.Item name="due_date" label="Due Date">
            <DatePicker format={dateFormat} className="w-100" />
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={12}>
          <Form.Item name="sale_amount" label="Sale Amount">
            <Input value={netAmount} />{" "}
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={12}>
          <Form.Item name="sale_due_amount" label="Sale Due Amount">
            <Input value={saleDueAmount} />
            {""}
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={24}>
          <Form.Item name="comment" label="Invoice Comment">
            <TextArea rows={2} />
          </Form.Item>
        </Col>
        <Col xs={24} sm={24} md={24}>
          <Form.Item name="address" label="Address">
            <TextArea rows={2} />
          </Form.Item>
        </Col>
      </Row>
    </>
  );
};

export default InvoiceForm;
