import React, { useState, useEffect } from "react";
import {
  Card,
  Table,
  Input,
  Button,
  Tooltip,
  Tag,
  Modal,
  Form,
  Switch,
  notification,
  Select,
  DatePicker,
  Row,
  Col,
} from "antd";
import {
  DeleteOutlined,
  SearchOutlined,
  PlusCircleOutlined,
  EditOutlined,
} from "@ant-design/icons";
import Flex from "components/shared-components/Flex";
import { useNavigate } from "react-router-dom";
import utils from "utils";
import dayjs from "dayjs";
import InvoiceService from "services/InvoiceService";
import { useSelector } from "react-redux";
const { Option } = Select;

const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
  return (
    <Modal
      destroyOnClose={true}
      title="Course Type"
      open={visible}
      okText="OK"
      onCancel={onCancelConfirm}
      onOk={() => {
        onOKConfirm();
      }}
    >
      Are you sure want to delete this item?
    </Modal>
  );
};

const Invoice = () => {
  const navigate = useNavigate();
  const [list, setList] = useState([]);
  const [initialVal, setInitialVal] = useState({
    name: "",
    status: "",
    date_from: "",
    date_to: "",
    agent: "",
  });
  const [modalVisibleConfirmation, setModalVisibleConfirmation] =
    useState(false);
  const [initialId, setInitialId] = useState(0);
  const [listAll, setListAll] = useState([]);
  const dateFormat = "YYYY-MM-DD";
  const [btnShowHide, setBtnShowHide] = useState({ add: 0, edit: 0, delete: 0 });
  const auth_details = JSON.parse(useSelector(state => state.auth.auth_details))

  const listData = () => {
    const reqeustParam = initialVal;
    try {
      const resp = InvoiceService.getInvoice(reqeustParam);
      resp
        .then((res) => {
          setList(res.data);
          setListAll(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    listData();
    const addPermission = auth_details.role_permissions.filter((listPer) => listPer.id === 83)
    const editPermission = auth_details.role_permissions.filter((listPer) => listPer.id === 84)
    const delPermission = auth_details.role_permissions.filter((listPer) => listPer.id === 85)
    setBtnShowHide({ add: addPermission.length, edit: editPermission.length, delete: delPermission.length })
  }, []);

  const tableColumns = [
    {
      title: "Sr. No.",
      render: (_, elm, index) => index + 1,
    },
    {
      title: "Invoice To",
      dataIndex: "to_name",
      sorter: (a, b) => utils.antdTableSorter(a, b, "to_name"),
    },
    {
      title: "Invoice Date",
      dataIndex: "invoice_date",

      sorter: (a, b) => utils.antdTableSorter(a, b, "invoice_date"),
    },
    {
      title: "Net Amount",
      dataIndex: "sale_amount",

      sorter: (a, b) => utils.antdTableSorter(a, b, "sale_amount"),
    },
    {
      title: "Due Amount",
      dataIndex: "sale_due_amount",

      sorter: (a, b) => utils.antdTableSorter(a, b, "sale_due_amount"),
    },
    {
      title: "Due Date",
      dataIndex: "due_date",

      sorter: (a, b) => utils.antdTableSorter(a, b, "due_date"),
    },
    {
      title: "Status",
      dataIndex: "status",

      sorter: (a, b) => utils.antdTableSorter(a, b, "status"),
    },
    {
      title: "Action",
      dataIndex: "actions",
      render: (_, elm) => (
        <div className="text-left">
          {btnShowHide.edit > 0 &&
          <Tooltip title="Edit">
            <Button
              type="primary"
              className="mr-2"
              icon={<EditOutlined />}
              onClick={() => {
                showEditVaue(elm);
              }}
              size="small"
            />
          </Tooltip>
    }
          {btnShowHide.delete > 0 &&
          <Tooltip title="Delete">
            <Button
              danger
              icon={<DeleteOutlined />}
              onClick={() => {
                deleteCourse(elm.id);
              }}
              size="small"
            />
          </Tooltip>
    }
        </div>
      ),
    },
  ];

  const showEditVaue = (elm) => {
    let invoice_id = elm.id;
    navigate(`/dashboards/invoice/edit/${invoice_id}`);
  };
  const deleteCourse = (elm) => {
    //console.log(elm)
    setInitialId(elm);
    setModalVisibleConfirmation(true);
  };
  const onCancelConfirm = () => {
    setInitialId(0);
    setModalVisibleConfirmation(false);
  };

  const onOKConfirm = () => {
    const reqeustParam = { invoice_id: initialId };
    const resp = InvoiceService.deleteInvoice(reqeustParam);
    resp
      .then((res) => {
        if (res.status === 200) {
          setModalVisibleConfirmation(false);
          listData();
          notification.success({ message: res.message });
        }
      })
      .catch((err) => {});
  };

  const inputChange = (name) => (e) => {
    let value;
    name === "name" || name === "agent"
      ? (value = e.target.value)
      : (value = e);
    setInitialVal({ ...initialVal, [name]: value });
  };

  const searchData = (e) => {
    listData();
  };

  const addInvoice = () => {
    navigate(`/dashboards/invoice/create`);
  }

  return (
    <Card>
      <h5>
        <u>
          <SearchOutlined /> Filter Invoice
        </u>
      </h5>
      <Row className="pt-3" gutter={16}>
        <Col xs={24} sm={24} md={8} className="mb-3">
          <label>Name</label>
          <Input onChange={inputChange("name")} />
        </Col>
        <Col xs={24} sm={24} md={8} className="mb-3">
          <label>From Date</label>
          <DatePicker
            format={dateFormat}
            className="w-100"
            onChange={inputChange("date_from")}
          />
        </Col>
        <Col xs={24} sm={24} md={8} className="mb-3">
          <label>Date To</label>
          <DatePicker
            format={dateFormat}
            className="w-100"
            onChange={inputChange("date_to")}
          />
        </Col>
        <Col xs={24} sm={24} md={8} className="mb-3">
          <label>Status</label>
          <Select
            placeholder="Status"
            onChange={inputChange("status")}
            className="w-100"
          >
            <Option key={`status1`} value=""></Option>
            <Option key={`status1`} value="paid">
              Paid
            </Option>
            <Option key={`status2`} value="unpaid">
              Unpaid
            </Option>
          </Select>
        </Col>
        <Col xs={24} sm={24} md={8} className="mb-3">
          <label>Agent Name</label>
          <Input onChange={inputChange("agent")} />
        </Col>
        <Col xs={24} sm={24} md={4}>
          <label>.</label>
          <Button
            onClick={searchData}
            type="primary"
            icon={<SearchOutlined />}
            block
          >
            Search
          </Button>
        </Col>
      </Row>
      <div>
      <Button
            onClick={addInvoice}
            type="primary"
            icon={<PlusCircleOutlined />}
          >
            Add Invoice
          </Button>
      </div>
      <hr />
      <Flex
        alignItems="center"
        justifyContent="space-between"
        mobileFlex={false}
      >
        <div>
          <ConfirmationBox
            id={initialId}
            visible={modalVisibleConfirmation}
            onOKConfirm={onOKConfirm}
            onCancelConfirm={onCancelConfirm}
          />
        </div>
      </Flex>
      
      <div className="table-responsive">
        <Table columns={tableColumns} dataSource={list} rowKey="id" />
      </div>
    </Card>
  );
};

export default Invoice;
