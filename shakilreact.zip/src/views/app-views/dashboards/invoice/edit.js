import React, { useState, useEffect } from "react";
import { Button, Input, Row, Col, Card, Form, Select, DatePicker, message } from "antd";
import InvoiceForm from "./invoiceform";
import InvoiceService from "services/InvoiceService";
import { useNavigate } from "react-router-dom";

const { Option } = Select;
const ADD = "Add";
const EDIT = "Edit";
const InvoiceEdit = (props) => {
  const { mode = ADD, userDetail } = props;
  const [form] = Form.useForm();
  const [invoice_type, setInvoiceType] = useState("service-invoice");
  const [submitLoading, setSubmitLoading] = useState(false);
  const [netAmount, setNetAmount] = useState(0);
  const [saleDueAmount, setSaleDueAmount] = useState(0);
  const navigate = useNavigate();
  const [initialValue, setInitialValue] = useState({
    invoice_type: invoice_type,
    invoice_date: "",
    invoice_to: userDetail.name,
    service_name: "",
    gst_number: "",
    university_amount: "",
    university_percentage: "",
    total_amount: "",
    net_amount: "",
    due_amount: "",
    due_date: "",
    sale_amount: "",
    sale_due_amount: "",
    first_tax_name: "",
    first_tax_amount: "",
    second_tax_name: "",
    second_tax_amount: "",
    comment: "",
    address: "",
  });

  const onFinish = () => {
    setSubmitLoading(true);
    form
      .validateFields()
      .then((values) => {
        setTimeout(() => {
          setSubmitLoading(false);
          values.student_id = userDetail.id;
          if (mode === ADD) {
            values.net_amount = netAmount;
            values.sale_amount = netAmount;
            values.sale_due_amount = saleDueAmount;
            const resp = InvoiceService.AddInvoice(values);
            resp
              .then((res) => {
                message.success(res.message);
                navigate(`/dashboards/invoice`);
              })
              .catch((err) => {});
          }
          if (mode === EDIT) {
            const data = {
              ...values,
            };
            const resp = InvoiceService.updateInvoice(data);
            resp
              .then((res) => {
                message.success(res.message);
                navigate(`/dashboards/payouts`);
              })
              .catch((err) => {});
          }
        }, 1500);
      })
      .catch((info) => {
        setSubmitLoading(false);
        message.error("Please enter all required field ");
      });
  };

  const calculation = (data) => {
    var total_amount = parseFloat(
      data.total_amount == "" ? 0 : data.total_amount
    );
    var first_tax_amount = parseFloat(
      data.first_tax_amount == "" ? 0 : data.first_tax_amount
    );
    var second_tax_amount = parseFloat(
      data.second_tax_amount == "" ? 0 : data.second_tax_amount
    );
    var due_amount = parseFloat(data.due_amount == "" ? 0 : data.due_amount);
    var net_amount = total_amount + first_tax_amount + second_tax_amount;
    var sale_amount = due_amount;

    data.net_amount = "" + net_amount;
    data.sale_amount = "" + sale_amount;
    setNetAmount(net_amount);
    setSaleDueAmount(sale_amount);
    setInitialValue(data);
    //console.log("input change ", netAmount);
  };

  const inputChange = (name) => (e) => {
    let value = e.target.value;
    setNetAmount(value);
    const data = { ...initialValue, [name]: value };
    calculation(data);
  };
  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
        initialValues={initialValue}
      >
        <div className="container">
          <Card title="Invoice Edit">
            <hr />
            <InvoiceForm netAmount={netAmount} inputChange={inputChange} saleDueAmount={saleDueAmount} />
            <Row className="mt-4">
              <Col xs={24} sm={24} md={12}>
                <Button
                  className="px-5"
                  type="primary"
                  htmlType="submit"
                  loading={submitLoading}
                  onClick={() => onFinish()}
                >
                  Save
                </Button>
              </Col>
            </Row>
          </Card>
        </div>
      </Form>
    </>
  );
};

export default InvoiceEdit;
