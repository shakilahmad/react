import React, { useState, useEffect } from "react";
import {
  Button,
  message,
  Input,
  Row,
  Col,
  Card,
  Form,
  Select,
  DatePicker,
} from "antd";

import { PlusCircleOutlined, EditOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import InvoiceService from "services/InvoiceService";
const { Option } = Select;
const ADD = "Add";
const EDIT = "Edit";
const InvoiceCreate = (props) => {
  const dateFormat = "DD/MM/YYYY";
  var today = new Date();
  const todayDate =
    today.getDate() + "/" + (today.getMonth() + 1) + "/" + today.getFullYear();
  const { mode = ADD } = props;
  const navigate = useNavigate();
  const [invoice_type, setInvoiceType] = useState("service-invoice");
  const [totalAmount, setTotalAmount] = useState(0);
  const [netAmount, setNetAmount] = useState(0);
  const [saleDueAmount, setSaleDueAmount] = useState(0);
  const [leads, setLeads] = useState([]);
  const [initialValue, setInitialValue] = useState({
    invoice_type: invoice_type,
    invoice_date: "",
    invoice_to: "",
    service_name: "",
    gst_number: "",
    university_amount: "",
    university_percentage: "",
    total_amount: "",
    net_amount: "",
    due_amount: "",
    due_date: "",
    sale_amount: "",
    sale_due_amount: "",
    first_tax_name: "",
    first_tax_amount: "",
    second_tax_name: "",
    second_tax_amount: "",
    comment: "",
    address: "",
  });

  const [form] = Form.useForm();
  const [submitLoading, setSubmitLoading] = useState(false);
  const { TextArea } = Input;

  useEffect(() => {
    if (mode === EDIT) {
      const reqeustParam = {};
      const resp = InvoiceService.editInvoice(reqeustParam);
      resp
        .then((res) => {
          form.setFieldsValue(res.data);
        })
        .catch((err) => {});
    }
  }, []);
  const onFinish = () => {
    setSubmitLoading(true);
    form
      .validateFields()
      .then((values) => {
        setTimeout(() => {
          setSubmitLoading(false);
          if (mode === ADD) {
            values.total_amount = totalAmount;
            values.net_amount = netAmount;
            values.sale_amount = netAmount;
            values.sale_due_amount = saleDueAmount;
            const resp = InvoiceService.AddInvoice(values);
            resp
              .then((res) => {
                message.success(res.message);
                navigate(`/dashboards/invoice`);
              })
              .catch((err) => {});
          }
          if (mode === EDIT) {
            const data = {
              ...values
            };
            const resp = InvoiceService.updateInvoice(data);
            resp
              .then((res) => {
                message.success(res.message);
                navigate(`/dashboards/payouts`);
              })
              .catch((err) => {});
          }
        }, 1500);
      })
      .catch((info) => {
        setSubmitLoading(false);
        message.error("Please enter all required field ");
      });
  };

  const calculation = (data) => {
    var total_amount = parseFloat(
      data.total_amount == "" ? 0 : data.total_amount
    );
    var first_tax_amount = parseFloat(
      data.first_tax_amount == "" ? 0 : data.first_tax_amount
    );
    var second_tax_amount = parseFloat(
      data.second_tax_amount == "" ? 0 : data.second_tax_amount
    );

    var university_amount = parseFloat(
      data.university_amount == "" ? 0 : data.university_amount
    );

    var university_percentage = parseFloat(
      data.university_percentage == "" ? 0 : data.university_percentage
    );

    if(university_amount > 0 && university_percentage > 0 && total_amount == 0){
      total_amount = university_amount * ( university_percentage/100 );
    }
    
    var due_amount = parseFloat(data.due_amount == "" ? 0 : data.due_amount);
    var net_amount = total_amount + first_tax_amount + second_tax_amount;
    var sale_amount = due_amount;

    data.net_amount = "" + net_amount;
    data.sale_amount = "" + sale_amount;
    setTotalAmount(total_amount);
    setNetAmount(net_amount);
    setSaleDueAmount(sale_amount);
    setInitialValue(data);
  };

  const inputChange = (name) => (e) => {
    let value = e.target.value;
    const data = { ...initialValue, [name]: value };
    if(name == "university_amount" || name == "university_percentage")
    {
      data.total_amount = 0;
    }
    calculation(data);
  };

  return (
    <>
      <Form
        layout="vertical"
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
        initialValues={initialValue}
      >
        <div className="container123">
          <Card title={`Invoice ${mode}`}>
            <hr />
            <Row className="pt-4" gutter={16}>
              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  label="Invoice Type"
                  name="invoice_type"
                  rules={[
                    {
                      required: true,
                      message: "Please select invoice type!",
                    },
                  ]}
                >
                  <Select
                    placeholder="Select invoice type"
                    onChange={(e) => setInvoiceType(e)}
                  >
                    <Option key={`invoice_type1`} value="service-invoice">
                      Service Invoice
                    </Option>
                    <Option key={`invoice_type2`} value="university-invoice">
                      University Invoice
                    </Option>
                  </Select>
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="invoice_date"
                  label="Invoice Date"
                  rules={[
                    {
                      required: true,
                      message: "Please select invoice date!",
                    },
                  ]}
                >
                  <DatePicker
                    format={dateFormat}
                    className="w-100"
                    value={todayDate}
                  />
                </Form.Item>
              </Col>

              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="service_name"
                  label="Service Name"
                  rules={[
                    {
                      required: true,
                      message: "Please enter service name!",
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  label="Invoice To"
                  name="invoice_to"
                  rules={[
                    {
                      required: true,
                      message: "Please enter invoice to!",
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
              </Col>

              {invoice_type == "university-invoice" ? (
                <>
                  <Col xs={24} sm={24} md={12}>
                    <Form.Item
                      name="university_amount"
                      label="University Amount"
                      onChange={inputChange("university_amount")}
                    >
                      <Input />
                    </Form.Item>
                  </Col>

                  <Col xs={24} sm={24} md={12}>
                    <Form.Item
                      name="university_percentage"
                      label="Commission Percentage"
                      onChange={inputChange("university_percentage")}
                    >
                      <Input />
                    </Form.Item>
                  </Col>
                </>
              ) : (
                <></>
              )}

              <Col xs={24} sm={24} md={24}>
                <Form.Item name="total_amount" label="Total Amount">
                  <Input
                    onChange={inputChange("total_amount")}
                    rules={[
                      {
                        required: true,
                        message: "Please enter total amount!",
                      },
                    ]}
                    value={totalAmount}
                  />{" "}
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="first_tax_name" label="First Tax Name">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="first_tax_amount" label="First Tax Amount">
                  <Input onChange={inputChange("first_tax_amount")} />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="second_tax_name" label="Second Tax Name">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="second_tax_amount" label="Second Tax Amount">
                  <Input onChange={inputChange("second_tax_amount")} />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="net_amount"
                  label="Net Amount"
                >
                  <Input value={netAmount} disabled />{" "}
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="gst_number" label="Customer GST Number">
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="due_amount" label="Due Amount">
                  <Input onChange={inputChange("due_amount")} />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="due_date" label="Due Date">
                  <DatePicker format={dateFormat} className="w-100" />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="sale_amount"
                  label="Sale Amount"
                >
                  <Input value={netAmount} />{" "}
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item
                  name="sale_due_amount"
                  label="Sale Due Amount"
                >
                  <Input value={saleDueAmount} />
                  {""}
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="comment" label="Invoice Comment">
                  <TextArea rows={2} />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item name="address" label="Address">
                  <TextArea rows={2} />
                </Form.Item>
              </Col>
            </Row>

            <Row className="">
              <Col xs={24} sm={24} md={12}>
                <Button
                  className="px-5"
                  type="primary"
                  htmlType="submit"
                  loading={submitLoading}
                  onClick={() => onFinish()}
                >
                  Save
                </Button>
              </Col>
            </Row>
          </Card>
        </div>
      </Form>
    </>
  );
};

export default InvoiceCreate;
