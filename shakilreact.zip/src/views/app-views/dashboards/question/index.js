import React, { useState, useEffect } from "react";
import {
  Row,
  Col,
  Card,
  Table,
  Input,
  Button,
  Tooltip,
  Tag,
  Modal,
  Form,
  Switch,
  notification,
  Select,
} from "antd";
import {
  DeleteOutlined,
  SearchOutlined,
  PlusCircleOutlined,
  EditOutlined,
} from "@ant-design/icons";
import Flex from "components/shared-components/Flex";
import {} from "react-router-dom";
import utils from "utils";
//import { getCourseType } from '../../../../services/MasterService';
import masterService from "../../../../services/MasterService";
import { useSelector } from "react-redux";
import AddNewCardForm from "./AddNewCardForm";

const ConfirmationBox = ({ id, visible, onOKConfirm, onCancelConfirm }) => {
  return (
    <Modal
      destroyOnClose={true}
      title="Course Type"
      open={visible}
      okText="OK"
      onCancel={onCancelConfirm}
      onOk={() => {
        onOKConfirm();
      }}
    >
      Are you sure want to delete this item?
    </Modal>
  );
};

const QuestionList = () => {
  const [list, setList] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [statusShow, setStatusShow] = useState(false);
  const [initialVal, setInitialVal] = useState({
    id: "",
    name: "",
    is_required: "",
    is_type: "",
    options: "",
    course_type_id: "",
  });
  const [modalVisibleConfirmation, setModalVisibleConfirmation] =
    useState(false);
  const [initialId, setInitialId] = useState(0);
  const [listAll, setListAll] = useState([]);
  const [listCourseAll, setListCourseAll] = useState([]);
  const [showOptions, setShowOptions] = useState(false);
  const [btnShowHide, setBtnShowHide] = useState({
    add: 0,
    edit: 0,
    delete: 0,
  });
  const auth_details = JSON.parse(
    useSelector((state) => state.auth.auth_details)
  );

  const listData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getQuestion(reqeustParam);
      resp
        .then((res) => {
          setList(res.data);
          setListAll(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };
  const listCourseTypeData = () => {
    const reqeustParam = {};
    try {
      const resp = masterService.getCourseType(reqeustParam);
      resp
        .then((res) => {
          //console.log(res.data)
          setListCourseAll(res.data);
        })
        .catch((err) => {});
    } catch (errors) {
      console.log(errors);
    }
  };

  useEffect(() => {
    listData();
    listCourseTypeData();
    const addPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 15
    );
    const editPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 16
    );
    const delPermission = auth_details.role_permissions.filter(
      (listPer) => listPer.id === 17
    );
    setBtnShowHide({
      add: addPermission.length,
      edit: editPermission.length,
      delete: delPermission.length,
    });
  }, []);

  const tableColumns = [
    {
      title: "Sr. No.",
      render: (_, elm, index) => index + 1,
    },
    {
      title: "Question",
      dataIndex: "title",
      sorter: (a, b) => utils.antdTableSorter(a, b, "title"),
    },
    {
      title: "Course Type",
      dataIndex: "course_type",
      sorter: (a, b) => utils.antdTableSorter(a, b, "course_type"),
    },
    {
      title: "Status",
      dataIndex: "is_active",
      render: (status) => (
        <Tag className="text-capitalize" color={status === 1 ? "cyan" : "red"}>
          {status === 1 ? "Active" : "Inactive"}
        </Tag>
      ),
      sorter: (a, b) => utils.antdTableSorter(a, b, "is_active"),
    },
    {
      title: "Action",
      dataIndex: "actions",
      render: (_, elm) => (
        <Flex>
          {btnShowHide.edit > 0 && (
            <Tooltip title="Edit">
              <Button
                type="primary"
                className="mr-2"
                icon={<EditOutlined />}
                onClick={() => {
                  showEditVaue(elm);
                }}
                size="small"
              />
            </Tooltip>
          )}
          {btnShowHide.delete > 0 && (
            <Tooltip title="Delete">
              <Button
                danger
                icon={<DeleteOutlined />}
                onClick={() => {
                  deleteCourse(elm.id);
                }}
                size="small"
              />
            </Tooltip>
          )}
        </Flex>
      ),
    },
  ];

  const onSearch = (e) => {
    const value = e.currentTarget.value;
    const searchArray = e.currentTarget.value ? listAll : listAll;
    const data = utils.wildCardSearch(searchArray, value);
    setList(data);
  };

  const showModal = () => {
    setModalVisible(true);
  };

  const closeModal = () => {
    setInitialVal({
      id: "",
      name: "",
      is_required: "",
      is_type: "",
      options: "",
      course_type_id: "",
    });
    setModalVisible(false);
    setStatusShow(false);
    setShowOptions(false);
  };

  const statusOnChange = (show) => {
    setStatusShow(show);
  };

  const isTypeOnChange = (values) => {
    setInitialVal({ ...initialVal, is_type: values });
    if (values === "Radio Buttons" || values === "Checkbox") {
      setShowOptions(true);
    } else {
      setShowOptions(false);
    }
  };

  const addCourseType = (values) => {
    let coursetype = values.statusName === true ? 1 : 0;
    if (initialVal.id > 0) {
      const reqeustParam = {
        course_form_id: initialVal.id,
        title: values.name,
        course_type_id: values.coursetype,
        is_required: values.is_required,
        is_type: values.is_type,
        options: values.options,
        is_active: coursetype,
      };
      const resp = masterService.editQuestion(reqeustParam);
      resp
        .then((res) => {
          if (res.status === 200) {
            listData();
          }
          notification.success({ message: "Question updated successfully." });
          setInitialVal({
            id: "",
            name: "",
            is_required: "",
            is_type: "",
            options: "",
            course_type_id: "",
          });

          setStatusShow(false);
          setModalVisible(false);
          setShowOptions(false);
        })
        .catch((err) => {});
    } else {
      const reqeustParam = {
        title: values.name,
        course_type_id: values.coursetype,
        is_required: values.is_required,
        is_type: values.is_type,
        options: values.options,
        is_active: coursetype,
      };

      const resp = masterService.addQuestion(reqeustParam);
      resp
        .then((res) => {
          if (res.status === 200) {
            listData();
          }

          notification.success({ message: "Question added successfully." });
          setInitialVal({
            id: "",
            name: "",
            is_required: "",
            is_type: "",
            options: "",
            course_type_id: "",
          });
          setStatusShow(false);
          setModalVisible(false);
          setShowOptions(false);
        })
        .catch((err) => {});
    }
  };
  const showEditVaue = (elm) => {
    let statustype = elm.is_active === 1 ? true : false;
    setInitialVal({
      id: elm.id,
      name: elm.title,
      is_required: elm.is_required,
      is_type: elm.is_type,
      options: elm.options,
      course_type_id: elm.course_type_id,
    });
    setStatusShow(statustype);
    if (elm.is_type === "Radio Buttons" || elm.is_type === "Checkbox") {
      setShowOptions(true);
    } else {
      setShowOptions(false);
    }
    showModal();
  };
  const deleteCourse = (elm) => {
    setInitialId(elm);
    setModalVisibleConfirmation(true);
  };
  const onCancelConfirm = () => {
    setInitialId(0);
    setModalVisibleConfirmation(false);
  };

  const onOKConfirm = () => {
    const reqeustParam = { course_form_id: initialId };
    const resp = masterService.deleteQuestion(reqeustParam);
    resp
      .then((res) => {
        if (res.status === 200) {
          setModalVisibleConfirmation(false);
          listData();
          notification.success({ message: "Question deleted successfully." });
        }
      })
      .catch((err) => {});
  };

  const inputChange = (name) => (e) => {
    let value;
    name === "name" || name === "options"
      ? (value = e.target.value)
      : (value = e);
    setInitialVal({ ...initialVal, [name]: value });
    //console.log(initialVal);
  };

  return (
    <Card>
      <Row gutter={16} className="justify-content-between my-4">
        <Col className="text-end mb-2" xs={24} sm={24} md={6}>
          {btnShowHide.add > 0 && (
            <Button
              onClick={showModal}
              type="primary"
              icon={<PlusCircleOutlined />}
            >
              Add Question
            </Button>
          )}
        </Col>
        <Col className="text-end mb-2" xs={24} sm={24} md={18}>
          <Input
            placeholder="Search"
            prefix={<SearchOutlined />}
            onChange={(e) => onSearch(e)}
          />
        </Col>
      </Row>
      <AddNewCardForm
        visible={modalVisible}
        onCreate={addCourseType}
        onCancel={closeModal}
        statusOnChange={statusOnChange}
        statusShow={statusShow}
        initialVal={initialVal}
        listCourseAll={listCourseAll}
        isTypeOnChange={isTypeOnChange}
        showOptions={showOptions}
        inputChange={inputChange}
      />
      <ConfirmationBox
        id={initialId}
        visible={modalVisibleConfirmation}
        onOKConfirm={onOKConfirm}
        onCancelConfirm={onCancelConfirm}
      />
      <div className="table-responsive">
        <Table columns={tableColumns} dataSource={list} rowKey="id" />
      </div>
    </Card>
  );
};
export default QuestionList;
