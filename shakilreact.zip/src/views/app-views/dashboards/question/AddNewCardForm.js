import React from "react";
import {
  Input,
  Modal,
  Form,
  Switch,
  Select,
} from "antd";

const AddNewCardForm = ({
    visible,
    onCreate,
    onCancel,
    statusOnChange,
    statusShow,
    initialVal,
    listCourseAll,
    isTypeOnChange,
    showOptions,
    inputChange,
  }) => {
    const [form] = Form.useForm();
    const { Option } = Select;
    form.setFieldsValue({
      name: initialVal.name,
      is_required: initialVal.is_required,
      is_type: initialVal.is_type,
      options: initialVal.options,
      statusName: statusShow,
    });
  
    return (
      <Modal
        destroyOnClose={true}
        title="Add New Question"
        open={visible}
        okText="Submit"
        onCancel={onCancel}
        onOk={() => {
          form
            .validateFields()
            .then((values) => {
              form.resetFields();
              onCreate(values);
            })
            .catch((info) => {
              console.log("Validate Failed:", info);
            });
        }}
      >
        <Form
          preserve={false}
          form={form}
          name="addQuestion"
          layout="vertical"
          initialValues={{
            id: initialVal.id,
            name: initialVal.name,
            is_required: initialVal.is_required,
            is_type: initialVal.is_type,
            options: initialVal.options,
            statusName: statusShow,
          }}
        >
          <Form.Item
            label="Question"
            name="name"
            rules={[
              {
                required: true,
                message: "Please enter question!",
              },
            ]}
          >
            <Input placeholder="Question" onChange={inputChange("name")} />
          </Form.Item>
          {initialVal.id > 0 ? (
            ""
          ) : (
            <Form.Item
              label="Course Type"
              name="coursetype"
              rules={[
                {
                  required: true,
                  message: "Please enter course type!",
                },
              ]}
            >
              <Select
                mode="multiple"
                onChange={inputChange("course_type_id")}
                showSearch
                placeholder="Select Course Type"
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children
                    .toLowerCase()
                    .indexOf(input.toLowerCase()) >= 0
                }
              >
                {listCourseAll &&
                  listCourseAll.map((listCType) => {
                    return <Option value={listCType.id}>{listCType.name}</Option>;
                  })}
              </Select>
            </Form.Item>
          )}
          <Form.Item
            label="Question Type"
            name="is_type"
            rules={[
              {
                required: true,
                message: "Please enter question type!",
              },
            ]}
          >
            <Select
              showSearch
              placeholder="Select Question Type"
              optionFilterProp="children"
              onChange={isTypeOnChange}
              filterOption={(input, option) =>
                option.props.children
                  .toLowerCase()
                  .indexOf(input.toLowerCase()) >= 0
              }
            >
              <Option value="Textbox">Textbox</Option>
              <Option value="Radio Buttons">Radio Buttons</Option>
              <Option value="Checkbox">Checkbox(Multiple Options)</Option>
              <Option value="Text Area">Text Area</Option>
              <Option value="Tags Based Option">Tags Based Option</Option>
            </Select>
          </Form.Item>
          {showOptions && (
            <Form.Item
              label="Options(Comma Seprated)"
              name="options"
              rules={[
                {
                  required: false,
                  message: "Please enter options!",
                },
              ]}
            >
              <Input placeholder="Options" onChange={inputChange("options")} />
            </Form.Item>
          )}
          <Form.Item
            label="Required"
            name="is_required"
            rules={[
              {
                required: true,
                message: "Please enter required!",
              },
            ]}
          >
            <Select
              onChange={inputChange("is_required")}
              showSearch
              placeholder="Select Required"
              optionFilterProp="children"
              filterOption={(input, option) =>
                option.props.children
                  .toLowerCase()
                  .indexOf(input.toLowerCase()) >= 0
              }
            >
              <Option value="1">Yes</Option>
              <Option value="2">No</Option>
            </Select>
          </Form.Item>
          <Form.Item label="Status" name="statusName">
            <Switch onChange={statusOnChange} checked={statusShow} />
          </Form.Item>
        </Form>
      </Modal>
    );
  };

  export default AddNewCardForm;