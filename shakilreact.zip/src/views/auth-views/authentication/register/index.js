import React from 'react'
import RegisterForm from '../../components/RegisterForm'
import { Card, Row, Col } from "antd";
import { useSelector } from 'react-redux'
import { BASE_URL_IMAGE } from 'configs/AppConfig';
import { Link } from 'react-router-dom';

const backgroundStyle = {
	backgroundImage: `url(${BASE_URL_IMAGE}/img/others/img-17.jpg)`,
	backgroundRepeat: 'no-repeat',
	backgroundSize: 'cover'
}

const RegisterOne = props => {
	const theme = useSelector(state => state.theme.currentTheme)
	return (
		<>
			<div className={`h-100 ${theme === 'light' ? 'bg-white' : ''}`}>
				<Row justify="center" className="align-items-stretch h-100">
					<Col xs={20} sm={20} md={24} lg={16}>
						<div className="container d-flex flex-column justify-content-center h-100">
							<Row justify="center">
								<Col xs={24} sm={24} md={20} lg={12} xl={16}>
									<h1 className='mb-0'>New Student Registration</h1>
									<p>Already have an account? <Link to="/student/login">Log In</Link></p>
									<div className="">
										<RegisterForm {...props} />
									</div>
								</Col>
							</Row>
						</div>
					</Col>
					<Col xs={0} sm={0} md={0} lg={8}>
						<div className="d-flex flex-column justify-content-between h-100" style={backgroundStyle}>
							<div className="text-right">
								{ /* <img className="" src={`${BASE_URL_IMAGE}/img/${theme === 'light' ? 'color-logo.png': 'color-logo.png'}`} alt="" /> */}

							</div>
							<Row justify="center">
								<Col xs={0} sm={0} md={0} lg={20}>
									<img className="img-fluid mb-5" src="/img/others/img-19.png" alt="" />
									<h1 className="text-white">Welcome to Global Education Talent</h1>

								</Col>
							</Row>
							<div className="d-flex justify-content-end pb-4">
								<div>
									{ /* <a className="text-white" href="/#" onClick={e => e.preventDefault()}>Term & Conditions</a>
								<span className="mx-2 text-white"> | </span>
								<a className="text-white" href="/#" onClick={e => e.preventDefault()}>Privacy & Policy</a>
								*/ }
								</div>
							</div>
						</div>
					</Col>
				</Row>
			</div>
		</>

	)
}

export default RegisterOne
